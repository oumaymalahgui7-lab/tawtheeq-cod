import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// In-memory / Persistent Database for the SaaS Platform
// Stores, Orders, Customers, Messages, Credits, Notifications, Logs
interface DBState {
  users: any[];
  stores: any[];
  orders: any[];
  customers: any[];
  messages: any[];
  transactions: any[];
  plans: any[];
  notifications: any[];
  logs: any[];
  automationSettings: any;
  templates: any[];
  whatsappConfig: any;
}

// Initial realistic data tailored to COD e-commerce in Morocco / Arab world
const db: DBState = {
  messages: [],
  users: [
    {
      id: 'usr_admin',
      name: 'هشام بنجلون',
      email: 'admin@tawtheeq.ma',
      role: 'ADMIN',
      storeName: 'توثيق COD HQ',
      phone: '+212661000000',
      planId: 'plan_business',
      credits: 1500,
      createdAt: new Date().toISOString(),
      onboardingCompleted: true,
    },
    {
      id: 'usr_merchant_1',
      name: 'ياسين العلمي',
      email: 'contact@marocfashion.ma',
      role: 'MERCHANT',
      storeName: 'بوتيك الأناقة المغربية',
      phone: '+212670112233',
      planId: 'plan_pro',
      credits: 0,
      createdAt: '2026-09-01T10:00:00.000Z',
      onboardingCompleted: true,
    }
  ],
  stores: [
    {
      id: 'store_1',
      name: 'بوتيك الأناقة المغربية',
      domain: 'marocfashion.ma',
      platform: 'SHOPIFY',
      currency: 'DH',
      phone: '+212670112233',
      isActive: true,
      webhookSecret: 'sh_sec_99a8b7c6d5e4f3a2b1c0',
      webhookUrl: '/api/webhooks/shopify',
      createdAt: '2026-09-01T10:00:00.000Z',
    },
    {
      id: 'store_2',
      name: 'كازا إلكترونيكس Casa Gadgets',
      domain: 'casagadgets.shop',
      platform: 'WOOCOMMERCE',
      currency: 'DH',
      phone: '+212662998877',
      isActive: true,
      webhookSecret: 'wc_sec_11b22c33d44e55f66a77',
      webhookUrl: '/api/webhooks/woocommerce',
      createdAt: '2026-09-15T14:30:00.000Z',
    }
  ],
  automationSettings: {
    autoSendConfirmation: true,
    firstReminderDelayMinutes: 15,
    enableSecondReminder: true,
    secondReminderDelayMinutes: 120,
    maxAttempts: 2,
    autoCancelAfterHours: 24,
    aiAutoConfirmation: true,
    aiAutoCancellation: true,
    aiSensitivity: 'BALANCED',
  },
  whatsappConfig: {
    phoneNumberId: '109847291823741',
    wabaId: '827364519283746',
    accessToken: 'EAAG...CONFIRMFLOW_META_TOKEN',
    verifyToken: 'confirmflow_meta_verify_2026',
    businessPhoneNumber: '+212611223344',
    isConnected: true,
    provider: 'META_CLOUD_API',
  },
  plans: [
    {
      id: 'plan_starter',
      name: 'STARTER',
      nameAr: 'البداية',
      priceMonthly: 199,
      ordersLimit: 150,
      storesLimit: 1,
      messagesIncluded: 250,
      costPerExtraMessage: 0.45,
      features: ['تأكيد واتساب فوري', 'متجر واحد', 'قوالب أساسية', 'ذكاء اصطناعي للدارجة', 'دعم عبر البريد الإلكتروني'],
    },
    {
      id: 'plan_pro',
      name: 'PRO',
      nameAr: 'المحترف',
      priceMonthly: 399,
      ordersLimit: 600,
      storesLimit: 3,
      messagesIncluded: 1000,
      costPerExtraMessage: 0.35,
      features: ['أتمتة ذكية متقدمة', '3 متاجر', 'تذكيرات تلقائية ذكية', 'فهم الدارجة والعربية والفرنسية', 'CRM متكامل وسجل العملاء', 'ربط شوبيفاي ووكومرس وفوري', 'دعم واتساب مخصص VIP'],
      isPopular: true,
    },
    {
      id: 'plan_business',
      name: 'BUSINESS',
      nameAr: 'الشركات',
      priceMonthly: 799,
      ordersLimit: 2500,
      storesLimit: 10,
      messagesIncluded: 4000,
      costPerExtraMessage: 0.25,
      features: ['طلبات غير محدودة مع كوتا مرنة', '10 متاجر', 'Webhooks مخصصة وخوادم فائقة السرعة', 'أولية التحليل بالذكاء الاصطناعي', 'تصدير شيت وإكسل وPDF أوتوماتيكي', 'مدير حساب خاص وفريق تقني'],
    }
  ],
  transactions: [
    {
      id: 'tx_1',
      type: 'TOPUP',
      amount: 500,
      description: 'شحن رصيد عبر بطاقة بنكية CMI',
      balanceAfter: 500,
      createdAt: '2026-09-01T10:05:00.000Z',
    },
    {
      id: 'tx_2',
      type: 'DEDUCTION',
      amount: 101,
      description: 'استهلاك رسائل تأكيد ومتابعة (252 رسالة)',
      balanceAfter: 399,
      createdAt: '2026-09-28T18:00:00.000Z',
    }
  ],
  notifications: [
    {
      id: 'notif_welcome',
      title: 'مرحباً بك في منصة توثيق COD',
      message: 'تم تفعيل مسارات الربط السحابي ومحرك الذكاء الاصطناعي بنجاح.',
      type: 'SYSTEM',
      read: false,
      createdAt: new Date().toISOString(),
    }
  ],
  templates: [
    {
      id: 'tmpl_1',
      name: 'رسالة التأكيد الفورية (الدارجة/العربية)',
      type: 'CONFIRMATION',
      language: 'darija',
      content: `السلام عليكم {{customer_name}} 👋\n\nتوصلنا بطلبك من متجر {{store_name}}.\n\n📦 المنتج: {{product}}\n🔢 الكمية: {{quantity}}\n💰 المبلغ الإجمالي: {{price}} DH (الدفع عند الاستلام)\n📍 عنوان التوصيل: {{city}} - {{address}}\n\nهل ترغب في تأكيد شحن طلبك؟ اضغط على الزر أدناه 👇`,
      buttons: [
        { text: '✅ نعم، أكّد الطلب', action: 'CONFIRM' },
        { text: '❌ إلغاء الطلب', action: 'CANCEL' }
      ],
      isActive: true,
    },
    {
      id: 'tmpl_2',
      name: 'تذكير أولي بعد 15 دقيقة',
      type: 'REMINDER_1',
      language: 'darija',
      content: `مرحبًا {{customer_name}}، ما زلنا في انتظار تأكيد طلبك {{order_id}} من {{store_name}} حتى نقوم بتجهيزه وإرساله مع شركة التوصيل 🚚.\n\n المرجو الرد لتأكيد طلبيتك قبل نفاد المخزون.`,
      buttons: [
        { text: '✅ تأكيد الآن', action: 'CONFIRM' },
        { text: '❌ إلغاء', action: 'CANCEL' }
      ],
      isActive: true,
    },
    {
      id: 'tmpl_3',
      name: 'إشعار شحن الطلب والتوصيل',
      type: 'SHIPPED',
      language: 'ar',
      content: `أهلاً {{customer_name}} 📦\nتم تسليم طلبك رقم {{order_id}} لشركة التوصيل وسيتصل بك الموزع اليوم أو غداً.\nالمبلغ المطلوب: {{price}} DH. شكراً لثقتكم بنا!`,
      buttons: [],
      isActive: true,
    }
  ],
  customers: [],
  orders: [],
  logs: []
};

// Initialize Gemini Client
let geminiAI: GoogleGenAI | null = null;
try {
  if (process.env.GEMINI_API_KEY) {
    geminiAI = new GoogleGenAI();
  }
} catch (err) {
  console.warn('Gemini client initialized without explicit env key or will load default');
}

// Robust NLP Classification Engine for Moroccan Darija, Standard Arabic, and French
export function ruleBasedDarijaClassifier(text: string) {
  const clean = text.toLowerCase().trim();

  // Confirmation signals in Darija, Arabic, and French
  const confirmPatterns = [
    'نعم', 'أكد', 'اكد', 'ايه', 'إيه', 'اه', 'أه', 'صافي', 'واخا', 'ناضي', 'جيبوه', 
    'صيفطوه', 'صيفطوها', 'بغيتو', 'بغيناه', 'موافق', 'تمام', 'أوكي', 'اوكي', 'اوك', 
    'دير تاكيد', 'كونفيرمي', 'كونفرم', 'oui', 'je confirme', 'confirmer', 'confirme', 
    'c bon', 'c\'est bon', 'd\'accord', 'ok', 'envoyez', 'oui svp'
  ];

  // Cancellation signals
  const cancelPatterns = [
    'لا', 'لغي', 'إلغاء', 'الغاء', 'ما بغيتوش', 'مابغيتوش', 'ما بقيتش بغيتو', 
    'مبقيتش بغيتو', 'سمحليا', 'سمح لي', 'لقيتو رخيص', 'غير صالح', 'بلاش', 
    'ما تصيفطوش', 'ماتصيفطوش', 'non', 'annuler', 'annule', 'pas la peine', 
    'je ne veux plus', 'stop', 'annulez svp'
  ];

  // Question signals
  const questionPatterns = [
    'شحال', 'بشحال', 'فوقاش', 'واش كاين', 'فين', 'وقتاش', 'اللون', 'المقاس', 
    'طاي', 'توصيل', 'لافيزون', 'livraison', 'combien', 'est-ce', 'couleur', 
    'taille', 'quand', 'prix', '?', '؟'
  ];

  // Address change signals
  const addressPatterns = [
    'بدل', 'عنوان', 'بدلو', 'زنقة', 'مدينة', 'كازا', 'الرباط', 'مراكش', 'changer', 'adresse'
  ];

  let isConfirm = confirmPatterns.some(p => clean.includes(p));
  let isCancel = cancelPatterns.some(p => clean.includes(p));
  let isQuestion = questionPatterns.some(p => clean.includes(p));
  let isAddressChange = addressPatterns.some(p => clean.includes(p));

  // Determine intent
  if (isCancel && !isConfirm) {
    return {
      intent: 'CANCELLED' as const,
      confidence: 0.96,
      language: detectLanguage(clean),
      reason: 'العميل طلب إلغاء الطلب صراحة عبر كلمات إلغاء واضحة',
      extractedNotes: 'طلب إلغاء بالدارجة/العربية'
    };
  }

  if (isQuestion) {
    return {
      intent: 'QUESTION' as const,
      confidence: 0.92,
      language: detectLanguage(clean),
      reason: 'العميل يستفسر عن معلومات إضافية (سعر التوصيل، المقاس، اللون، أو وقت الوصول)',
      extractedNotes: 'يحتاج لمراجعة تاجر المتجر والرد على العميل'
    };
  }

  if (isConfirm && !isCancel) {
    return {
      intent: 'CONFIRMED' as const,
      confidence: 0.98,
      language: detectLanguage(clean),
      reason: 'العميل وافق على تأكيد الطلب واستخدم عبارات الموافقة',
      extractedNotes: 'تم التأكيد تلقائياً'
    };
  }

  if (isAddressChange) {
    return {
      intent: 'ADDRESS_CHANGE' as const,
      confidence: 0.88,
      language: detectLanguage(clean),
      reason: 'العميل يرغب بتعديل عنوان الشحن أو وقت التوصيل',
      extractedNotes: 'تعديل العنوان مطلوب'
    };
  }

  return {
    intent: 'UNKNOWN' as const,
    confidence: 0.45,
    language: detectLanguage(clean),
    reason: 'الرسالة غير واضحة المعالم وتحتاج إلى مراجعة يدوية',
    extractedNotes: 'غير مصنف بدقة'
  };
}

function detectLanguage(text: string): 'darija' | 'arabic' | 'french' | 'mixed' {
  const hasLatin = /[a-zA-Z]/.test(text);
  const hasArabic = /[\u0600-\u06FF]/.test(text);
  const isDarijaSpecific = /واخا|صافي|ناضي|دابا|فين|شحال|بشحال|صيفط|جيب|زوين/.test(text);

  if (hasLatin && hasArabic) return 'mixed';
  if (hasLatin) return 'french';
  if (isDarijaSpecific) return 'darija';
  return 'arabic';
}

// ----------------------------------------------------
// 1. API: AI Customer Response Classifier
// ----------------------------------------------------
app.post('/api/ai/classify', async (req: Request, res: Response) => {
  try {
    const { text, orderId } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text message is required' });
    }

    // Try Gemini 3.8-flash for deep Darija semantic reasoning
    if (process.env.GEMINI_API_KEY) {
      try {
        const ai = geminiAI || new GoogleGenAI();
        const prompt = `You are an expert AI classifier for e-commerce Cash on Delivery (COD) WhatsApp customer responses in Morocco and the Arab world.
The customer received a confirmation WhatsApp message for their COD order and responded with the following text:
"${text}"

Analyze their intent strictly and output JSON only with this schema:
{
  "intent": "CONFIRMED" | "CANCELLED" | "QUESTION" | "ADDRESS_CHANGE" | "UNKNOWN",
  "confidence": number between 0 and 1,
  "language": "darija" | "arabic" | "french" | "mixed",
  "reason": "Clear explanation in Arabic",
  "extractedNotes": "Any details like preferred delivery day, color requested, or address change"
}

Guidance:
- "واخا", "صافي", "نعم", "ايه", "جيبوه", "صيفطوها", "oui je confirme", "d'accord" => CONFIRMED
- "لا", "ما بغيتوش", "سمحليا", "لغيو الطلب", "non annulez" => CANCELLED
- "شحال التوصيل", "فوقاش يوصل", "واش كاين كحل", "combien" => QUESTION
- If ambiguous, choose "UNKNOWN" so the system can set status to NEEDS_REVIEW safely.`;

        const aiResponse = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          }
        });

        if (aiResponse.text) {
          const parsed = JSON.parse(aiResponse.text);
          return res.json({ success: true, classification: parsed, source: 'GEMINI_AI' });
        }
      } catch (geminiError) {
        console.warn('Gemini API call failed, falling back to built-in rule classifier:', geminiError);
      }
    }

    // Fallback to high-accuracy deterministic rule classifier
    const classification = ruleBasedDarijaClassifier(text);
    return res.json({ success: true, classification, source: 'RULE_ENGINE' });
  } catch (error: any) {
    console.error('Error in /api/ai/classify:', error);
    return res.status(500).json({ error: 'Failed to classify message' });
  }
});

// ----------------------------------------------------
// 2. API: Orders Management
// ----------------------------------------------------
app.get('/api/orders', (req: Request, res: Response) => {
  const { status, search, storeId, limit = '50', page = '1' } = req.query;

  let filtered = [...db.orders];

  if (status && status !== 'ALL') {
    filtered = filtered.filter(o => o.status === status);
  }

  if (storeId && storeId !== 'ALL') {
    filtered = filtered.filter(o => o.storeId === storeId);
  }

  if (search) {
    const q = String(search).toLowerCase();
    filtered = filtered.filter(o => 
      o.orderNumber.toLowerCase().includes(q) ||
      o.customerName.toLowerCase().includes(q) ||
      o.customerPhone.includes(q) ||
      o.customerCity.toLowerCase().includes(q)
    );
  }

  // Sort newest first
  filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const pageNum = parseInt(page as string) || 1;
  const pageSize = parseInt(limit as string) || 50;
  const total = filtered.length;
  const paginated = filtered.slice((pageNum - 1) * pageSize, pageNum * pageSize);

  res.json({
    orders: paginated,
    pagination: {
      total,
      page: pageNum,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    }
  });
});

app.get('/api/orders/:id', (req: Request, res: Response) => {
  const order = db.orders.find(o => o.id === req.params.id || o.orderNumber === req.params.id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  res.json({ order });
});

app.post('/api/orders', (req: Request, res: Response) => {
  const { customerName, customerPhone, customerCity, customerAddress, items, totalPrice, storeId, notes } = req.body;

  if (!customerName || !customerPhone || !items || items.length === 0) {
    return res.status(400).json({ error: 'Missing required order fields' });
  }

  const store = db.stores.find(s => s.id === storeId) || db.stores[0];
  const newOrderNum = `ORD-${5990 + db.orders.length + 1}`;
  const now = new Date().toISOString();

  const newOrder = {
    id: `ord_${Date.now()}`,
    orderNumber: newOrderNum,
    storeId: store.id,
    storeName: store.name,
    customerName,
    customerPhone,
    customerCity: customerCity || 'الدار البيضاء',
    customerAddress: customerAddress || '',
    items,
    subtotal: totalPrice || 350,
    shippingFee: 35,
    totalPrice: (totalPrice || 350) + 35,
    currency: store.currency || 'DH',
    paymentMethod: 'COD',
    status: 'PENDING_CONFIRMATION',
    source: 'CUSTOM_API',
    notes: notes || '',
    whatsappMessageCount: 1,
    createdAt: now,
    updatedAt: now,
    messages: [
      {
        id: `msg_${Date.now()}`,
        orderId: `ord_${Date.now()}`,
        direction: 'OUTBOUND',
        type: 'CONFIRMATION',
        body: `السلام عليكم ${customerName} 👋 توصلنا بطلبك من ${store.name}. الإجمالي: ${(totalPrice || 350) + 35} DH. هل ترغب في تأكيد الطلب؟`,
        timestamp: now,
        status: 'SENT'
      }
    ],
    timeline: [
      {
        id: `tl_${Date.now()}`,
        orderId: `ord_${Date.now()}`,
        title: 'إنشاء الطلب',
        description: 'تم إنشاء الطلب يدويًا في النظام',
        timestamp: now,
        type: 'CREATED'
      },
      {
        id: `tl_${Date.now() + 1}`,
        orderId: `ord_${Date.now()}`,
        title: 'إرسال تأكيد واتساب',
        description: 'تم إرسال رسالة التأكيد التلقائية للعميل',
        timestamp: now,
        type: 'WHATSAPP_SENT'
      }
    ]
  };

  db.orders.unshift(newOrder);

  // Deduct credits (0.40 DH per confirmation message)
  const cost = 0.40;
  const merchant = db.users[1];
  if (merchant) {
    merchant.credits = Math.max(0, Number((merchant.credits - cost).toFixed(2)));
    db.transactions.unshift({
      id: `tx_${Date.now()}`,
      type: 'DEDUCTION',
      amount: cost,
      description: `إرسال رسالة تأكيد للطلب ${newOrderNum}`,
      orderId: newOrder.id,
      balanceAfter: merchant.credits,
      createdAt: now,
    });
  }

  // Update or add customer in CRM
  let existingCust = db.customers.find(c => c.phone === customerPhone);
  if (existingCust) {
    existingCust.totalOrders += 1;
    existingCust.lastOrderAt = now;
  } else {
    db.customers.unshift({
      id: `cust_${Date.now()}`,
      name: customerName,
      phone: customerPhone,
      city: customerCity || 'الدار البيضاء',
      address: customerAddress || '',
      totalOrders: 1,
      confirmedOrders: 0,
      cancelledOrders: 0,
      deliveredOrders: 0,
      returnedOrders: 0,
      totalSpent: (totalPrice || 350) + 35,
      currency: store.currency || 'DH',
      firstOrderAt: now,
      lastOrderAt: now,
    });
  }

  db.notifications.unshift({
    id: `notif_${Date.now()}`,
    title: 'طلب جديد تم تسجيله',
    message: `وصل طلب جديد ${newOrderNum} للعميل ${customerName} بمبلغ ${newOrder.totalPrice} DH`,
    type: 'ORDER_NEW',
    orderId: newOrder.id,
    read: false,
    createdAt: now,
  });

  res.status(201).json({ success: true, order: newOrder });
});

app.patch('/api/orders/:id/status', (req: Request, res: Response) => {
  const { status, note } = req.body;
  const order = db.orders.find(o => o.id === req.params.id);

  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const now = new Date().toISOString();
  order.status = status;
  order.updatedAt = now;
  if (note) order.notes = note;

  if (status === 'CONFIRMED') order.confirmedAt = now;
  if (status === 'SHIPPED') order.shippedAt = now;
  if (status === 'DELIVERED') order.deliveredAt = now;
  if (status === 'CANCELLED') order.cancelledAt = now;

  order.timeline.push({
    id: `tl_${Date.now()}`,
    orderId: order.id,
    title: `تحديث الحالة إلى ${status}`,
    description: note || `تم تغيير حالة الطلب يدويًا أو عبر النظام إلى ${status}`,
    timestamp: now,
    type: status
  });

  // Update customer stats
  const cust = db.customers.find(c => c.phone === order.customerPhone);
  if (cust) {
    if (status === 'CONFIRMED') cust.confirmedOrders += 1;
    if (status === 'CANCELLED') cust.cancelledOrders += 1;
    if (status === 'DELIVERED') cust.deliveredOrders += 1;
    if (status === 'RETURNED') cust.returnedOrders += 1;
  }

  res.json({ success: true, order });
});

// ----------------------------------------------------
// 3. API: WhatsApp Webhook & Simulator
// ----------------------------------------------------
app.post('/api/whatsapp/simulate-reply', async (req: Request, res: Response) => {
  try {
    const { orderId, replyText } = req.body;
    const order = db.orders.find(o => o.id === orderId || o.orderNumber === orderId);

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const now = new Date().toISOString();

    // 1. Classify with AI
    let classification = ruleBasedDarijaClassifier(replyText);
    if (process.env.GEMINI_API_KEY && geminiAI) {
      try {
        const prompt = `Analyze COD WhatsApp response in Morocco: "${replyText}". Return JSON: { "intent": "CONFIRMED"|"CANCELLED"|"QUESTION"|"ADDRESS_CHANGE"|"UNKNOWN", "confidence": number, "language": "darija"|"arabic"|"french"|"mixed", "reason": string, "extractedNotes": string }`;
        const aiResponse = await geminiAI.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: { responseMimeType: 'application/json' }
        });
        if (aiResponse.text) {
          classification = JSON.parse(aiResponse.text);
        }
      } catch (e) {
        console.warn('AI call error in simulator, using rule engine:', e);
      }
    }

    // 2. Add inbound message to order
    const inboundMsg = {
      id: `msg_${Date.now()}`,
      orderId: order.id,
      direction: 'INBOUND',
      type: 'REPLY',
      body: replyText,
      timestamp: now,
      status: 'DELIVERED',
      aiClassification: classification
    };
    order.messages.push(inboundMsg);
    order.whatsappMessageCount += 1;
    order.updatedAt = now;

    // 3. Apply state transition based on AI classification and automation settings
    let newStatus = order.status;
    let timelineTitle = 'رد العميل عبر واتساب';
    let timelineDesc = `العميل رد: "${replyText}". الذكاء الاصطناعي صنفه: ${classification.intent}`;

    if (classification.intent === 'CONFIRMED') {
      newStatus = 'CONFIRMED';
      order.confirmedAt = now;
      timelineTitle = 'تم تأكيد الطلب بنجاح ✅';
      timelineDesc = `تم التأكيد تلقائيًا بواسطة الذكاء الاصطناعي (نسبة الثقة: ${Math.round(classification.confidence * 100)}%). ${classification.reason}`;
      
      // Update customer
      const cust = db.customers.find(c => c.phone === order.customerPhone);
      if (cust) cust.confirmedOrders += 1;

      db.notifications.unshift({
        id: `notif_${Date.now()}`,
        title: 'طلب مؤكد بنجاح عبر واتساب',
        message: `العميل ${order.customerName} أكد طلبه ${order.orderNumber} عبر واتساب بنجاح.`,
        type: 'ORDER_CONFIRMED',
        orderId: order.id,
        read: false,
        createdAt: now,
      });
    } else if (classification.intent === 'CANCELLED') {
      newStatus = 'CANCELLED';
      order.cancelledAt = now;
      timelineTitle = 'تم إلغاء الطلب ❌';
      timelineDesc = `العميل اختار الإلغاء. السبب: ${classification.reason}`;

      const cust = db.customers.find(c => c.phone === order.customerPhone);
      if (cust) cust.cancelledOrders += 1;

      db.notifications.unshift({
        id: `notif_${Date.now()}`,
        title: 'تم إلغاء الطلب عبر واتساب',
        message: `العميل ${order.customerName} ألغى طلبه ${order.orderNumber}. تم حفظ تكاليف الشحن.`,
        type: 'ORDER_CANCELLED',
        orderId: order.id,
        read: false,
        createdAt: now,
      });
    } else if (classification.intent === 'QUESTION' || classification.intent === 'ADDRESS_CHANGE' || classification.intent === 'UNKNOWN') {
      newStatus = 'NEEDS_REVIEW';
      timelineTitle = 'يحتاج لمراجعة التاجر ⚠️';
      timelineDesc = `العميل لديه استفسار: "${classification.extractedNotes || replyText}"`;

      db.notifications.unshift({
        id: `notif_${Date.now()}`,
        title: 'استفسار عميل بحاجة لرد',
        message: `العميل ${order.customerName} لديه استفسار حول الطلب ${order.orderNumber}.`,
        type: 'QUESTION',
        orderId: order.id,
        read: false,
        createdAt: now,
      });
    }

    order.status = newStatus;
    order.timeline.push({
      id: `tl_${Date.now()}`,
      orderId: order.id,
      title: timelineTitle,
      description: timelineDesc,
      timestamp: now,
      type: newStatus === 'CONFIRMED' ? 'CONFIRMED' : newStatus === 'CANCELLED' ? 'CANCELLED' : 'NOTE'
    });

    db.logs.unshift({
      id: `log_${Date.now()}`,
      level: 'INFO',
      category: 'WHATSAPP',
      message: `Simulated inbound WhatsApp reply on ${order.orderNumber}`,
      payload: { replyText, classification },
      createdAt: now,
    });

    res.json({
      success: true,
      order,
      classification,
      message: inboundMsg
    });
  } catch (err: any) {
    console.error('Error in WhatsApp simulation:', err);
    res.status(500).json({ error: 'Failed to process WhatsApp reply' });
  }
});

// Meta Cloud API Webhook Verification Endpoint (GET)
app.get('/api/webhooks/whatsapp', (req: Request, res: Response) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === db.whatsappConfig.verifyToken) {
    return res.status(200).send(challenge);
  }
  return res.status(403).send('Forbidden verification token');
});

// Meta Cloud API Webhook Event Receiver (POST)
app.post('/api/webhooks/whatsapp', async (req: Request, res: Response) => {
  const body = req.body;
  db.logs.unshift({
    id: `log_${Date.now()}`,
    level: 'INFO',
    category: 'WHATSAPP',
    message: 'Meta WhatsApp webhook event received',
    payload: body,
    createdAt: new Date().toISOString()
  });

  // Always return 200 OK fast to Meta to prevent timeout
  res.status(200).json({ status: 'EVENT_RECEIVED' });
});

// ----------------------------------------------------
// 4. API: Shopify & WooCommerce Webhooks
// ----------------------------------------------------
app.post('/api/webhooks/shopify', (req: Request, res: Response) => {
  try {
    const payload = req.body;
    const store = db.stores.find(s => s.platform === 'SHOPIFY') || db.stores[0];
    const now = new Date().toISOString();

    const customerName = payload.customer?.first_name ? `${payload.customer.first_name} ${payload.customer.last_name || ''}`.trim() : (payload.shipping_address?.name || 'زبون شوبيفاي');
    const customerPhone = payload.shipping_address?.phone || payload.customer?.phone || '+212600000000';
    const city = payload.shipping_address?.city || 'الدار البيضاء';
    const address = payload.shipping_address?.address1 || 'المغرب';
    const totalPrice = parseFloat(payload.total_price || '450');
    const items = (payload.line_items || []).map((it: any, idx: number) => ({
      id: `it_${idx}`,
      name: it.title || 'منتج شوبيفاي',
      quantity: it.quantity || 1,
      price: parseFloat(it.price || '200')
    }));

    // Prevent duplicate orders
    const existing = db.orders.find(o => o.orderNumber === `SHOP-${payload.id || Date.now()}`);
    if (existing) {
      return res.status(200).json({ status: 'DUPLICATE_IGNORED', orderId: existing.id });
    }

    const orderNumber = `ORD-${6000 + db.orders.length}`;
    const newOrder = {
      id: `ord_${Date.now()}`,
      orderNumber,
      storeId: store.id,
      storeName: store.name,
      customerName,
      customerPhone,
      customerCity: city,
      customerAddress: address,
      items: items.length > 0 ? items : [{ id: 'item_sh', name: 'منتج شوبيفاي COD', quantity: 1, price: totalPrice }],
      subtotal: totalPrice - 35 > 0 ? totalPrice - 35 : totalPrice,
      shippingFee: 35,
      totalPrice,
      currency: store.currency || 'DH',
      paymentMethod: 'COD',
      status: 'PENDING_CONFIRMATION',
      source: 'SHOPIFY',
      notes: `تم الاستلام تلقائياً من متجر Shopify عبر Webhook`,
      whatsappMessageCount: 1,
      createdAt: now,
      updatedAt: now,
      messages: [
        {
          id: `msg_${Date.now()}`,
          orderId: `ord_${Date.now()}`,
          direction: 'OUTBOUND',
          type: 'CONFIRMATION',
          body: `السلام عليكم ${customerName} 👋 توصلنا بطلبك من ${store.name}. الإجمالي: ${totalPrice} DH عند الاستلام. هل ترغب في تأكيد الطلب؟`,
          timestamp: now,
          status: 'SENT'
        }
      ],
      timeline: [
        { id: `tl_${Date.now()}`, orderId: `ord_${Date.now()}`, title: 'طلب شوبيفاي جديد', description: `تم استلام الطلب من Webhook شوبيفاي`, timestamp: now, type: 'CREATED' },
        { id: `tl_${Date.now() + 1}`, orderId: `ord_${Date.now()}`, title: 'إرسال تأكيد واتساب تلقائي', description: 'تم إرسال رسالة التأكيد عبر WhatsApp Business', timestamp: now, type: 'WHATSAPP_SENT' }
      ]
    };

    db.orders.unshift(newOrder);

    db.logs.unshift({
      id: `log_${Date.now()}`,
      level: 'INFO',
      category: 'WEBHOOK',
      message: `Shopify Order Webhook processed successfully for ${orderNumber}`,
      createdAt: now,
    });

    res.status(201).json({ success: true, orderId: newOrder.id, orderNumber });
  } catch (error: any) {
    console.error('Shopify Webhook error:', error);
    res.status(500).json({ error: 'Failed to process Shopify webhook' });
  }
});

app.post('/api/webhooks/woocommerce', (req: Request, res: Response) => {
  const payload = req.body;
  const store = db.stores.find(s => s.platform === 'WOOCOMMERCE') || db.stores[1];
  const now = new Date().toISOString();

  const customerName = `${payload.billing?.first_name || ''} ${payload.billing?.last_name || ''}`.trim() || 'زبون ووكومرس';
  const customerPhone = payload.billing?.phone || '+212600000000';
  const totalPrice = parseFloat(payload.total || '380');

  const orderNumber = `ORD-${6000 + db.orders.length}`;
  const newOrder = {
    id: `ord_${Date.now()}`,
    orderNumber,
    storeId: store.id,
    storeName: store.name,
    customerName,
    customerPhone,
    customerCity: payload.billing?.city || 'الرباط',
    customerAddress: payload.billing?.address_1 || 'المغرب',
    items: [{ id: 'it_wc', name: payload.line_items?.[0]?.name || 'طلب ووكومرس', quantity: 1, price: totalPrice }],
    subtotal: totalPrice,
    shippingFee: 0,
    totalPrice,
    currency: 'DH',
    paymentMethod: 'COD',
    status: 'PENDING_CONFIRMATION',
    source: 'WOOCOMMERCE',
    notes: 'وارد من متجر WooCommerce عبر Webhook',
    whatsappMessageCount: 1,
    createdAt: now,
    updatedAt: now,
    messages: [],
    timeline: [
      { id: `tl_${Date.now()}`, orderId: `ord_${Date.now()}`, title: 'طلب ووكومرس جديد', description: 'تم استلام الطلب من Webhook WooCommerce', timestamp: now, type: 'CREATED' }
    ]
  };

  db.orders.unshift(newOrder);
  res.status(201).json({ success: true, orderId: newOrder.id });
});

// ----------------------------------------------------
// 5. API: Customers & CRM
// ----------------------------------------------------
app.get('/api/customers', (req: Request, res: Response) => {
  const { search } = req.query;
  let list = [...db.customers];
  if (search) {
    const q = String(search).toLowerCase();
    list = list.filter(c => c.name.toLowerCase().includes(q) || c.phone.includes(q) || c.city.toLowerCase().includes(q));
  }
  res.json({ customers: list });
});

// ----------------------------------------------------
// 6. API: Analytics & Dashboard KPIs
// ----------------------------------------------------
app.get('/api/analytics', (req: Request, res: Response) => {
  const totalOrders = db.orders.length;
  const confirmed = db.orders.filter(o => o.status === 'CONFIRMED' || o.status === 'SHIPPED' || o.status === 'DELIVERED').length;
  const cancelled = db.orders.filter(o => o.status === 'CANCELLED').length;
  const pending = db.orders.filter(o => o.status === 'PENDING_CONFIRMATION' || o.status === 'NEW').length;
  const delivered = db.orders.filter(o => o.status === 'DELIVERED').length;
  const returned = db.orders.filter(o => o.status === 'RETURNED').length;
  const needsReview = db.orders.filter(o => o.status === 'NEEDS_REVIEW').length;

  const confirmationRate = totalOrders > 0 ? Math.round((confirmed / totalOrders) * 100) : 0;
  const revenue = db.orders
    .filter(o => o.status === 'CONFIRMED' || o.status === 'SHIPPED' || o.status === 'DELIVERED')
    .reduce((sum, o) => sum + (o.totalPrice || 0), 0);

  const credits = db.users[1]?.credits ?? 0;

  // Chart data: daily orders for the last 7 days calculated dynamically from db.orders
  const days = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
  const dayNameMapping: Record<number, string> = {
    6: 'السبت', 0: 'الأحد', 1: 'الإثنين', 2: 'الثلاثاء', 3: 'الأربعاء', 4: 'الخميس', 5: 'الجمعة'
  };

  const chartData = days.map((day) => {
    const dayOrders = db.orders.filter(o => {
      const orderDate = new Date(o.createdAt);
      return dayNameMapping[orderDate.getDay()] === day;
    });
    const total = dayOrders.length;
    const dayConfirmed = dayOrders.filter(o => o.status === 'CONFIRMED' || o.status === 'SHIPPED' || o.status === 'DELIVERED').length;
    const dayCancelled = dayOrders.filter(o => o.status === 'CANCELLED').length;
    const dayRevenue = dayOrders
      .filter(o => o.status === 'CONFIRMED' || o.status === 'SHIPPED' || o.status === 'DELIVERED')
      .reduce((sum, o) => sum + (o.totalPrice || 0), 0);

    return {
      day,
      total,
      confirmed: dayConfirmed,
      cancelled: dayCancelled,
      revenue: dayRevenue
    };
  });

  res.json({
    kpis: {
      totalOrders,
      confirmed,
      cancelled,
      pending,
      delivered,
      returned,
      needsReview,
      confirmationRate,
      revenue,
      credits,
      currency: 'DH'
    },
    chartData,
    statusBreakdown: {
      confirmed,
      cancelled,
      pending,
      delivered,
      returned,
      needsReview
    }
  });
});

// ----------------------------------------------------
// 7. API: Billing & Credits
// ----------------------------------------------------
app.get('/api/billing', (req: Request, res: Response) => {
  const user = db.users[1];
  res.json({
    credits: user.credits,
    currency: 'DH',
    currentPlan: db.plans.find(p => p.id === user.planId) || db.plans[1],
    plans: db.plans,
    transactions: db.transactions
  });
});

app.post('/api/billing/recharge', (req: Request, res: Response) => {
  const { amount } = req.body;
  const rechargeAmount = parseFloat(amount);

  if (isNaN(rechargeAmount) || rechargeAmount <= 0) {
    return res.status(400).json({ error: 'Invalid amount' });
  }

  const user = db.users[1];
  user.credits = Number((user.credits + rechargeAmount).toFixed(2));

  const tx = {
    id: `tx_${Date.now()}`,
    type: 'TOPUP',
    amount: rechargeAmount,
    description: `شحن رصيد إضافي عبر البطاقة البنكية المغربية CMI`,
    balanceAfter: user.credits,
    createdAt: new Date().toISOString(),
  };

  db.transactions.unshift(tx);
  res.json({ success: true, balance: user.credits, transaction: tx });
});

// ----------------------------------------------------
// 8. API: Stores & Settings
// ----------------------------------------------------
app.get('/api/stores', (req: Request, res: Response) => {
  res.json({ stores: db.stores });
});

app.post('/api/stores', (req: Request, res: Response) => {
  const { name, domain, platform, currency, phone } = req.body;
  const newStore = {
    id: `store_${Date.now()}`,
    name: name || 'متجر جديد',
    domain: domain || 'mystore.ma',
    platform: platform || 'SHOPIFY',
    currency: currency || 'DH',
    phone: phone || '+212600000000',
    isActive: true,
    webhookSecret: `sec_${Math.random().toString(36).substring(2, 15)}`,
    webhookUrl: platform === 'SHOPIFY' ? '/api/webhooks/shopify' : '/api/webhooks/woocommerce',
    createdAt: new Date().toISOString()
  };
  db.stores.push(newStore);
  res.status(201).json({ success: true, store: newStore });
});

app.get('/api/settings', (req: Request, res: Response) => {
  res.json({
    automation: db.automationSettings,
    whatsapp: db.whatsappConfig,
    templates: db.templates
  });
});

app.post('/api/settings', (req: Request, res: Response) => {
  const { automation, whatsapp, templates } = req.body;
  if (automation) db.automationSettings = { ...db.automationSettings, ...automation };
  if (whatsapp) db.whatsappConfig = { ...db.whatsappConfig, ...whatsapp };
  if (templates) db.templates = templates;
  res.json({ success: true, message: 'Settings updated' });
});

// ----------------------------------------------------
// 9. API: Notifications
// ----------------------------------------------------
app.get('/api/notifications', (req: Request, res: Response) => {
  res.json({ notifications: db.notifications });
});

app.post('/api/notifications/mark-read', (req: Request, res: Response) => {
  db.notifications.forEach(n => n.read = true);
  res.json({ success: true });
});

// ----------------------------------------------------
// 10. API: Admin Console
// ----------------------------------------------------
app.get('/api/admin/overview', (req: Request, res: Response) => {
  res.json({
    usersCount: db.users.length,
    storesCount: db.stores.length,
    ordersCount: db.orders.length,
    logs: db.logs.slice(0, 30),
    plans: db.plans,
    users: db.users
  });
});

app.post('/api/admin/plans', (req: Request, res: Response) => {
  const { plans } = req.body;
  if (Array.isArray(plans)) {
    db.plans = plans;
    return res.json({ success: true, plans: db.plans });
  }
  res.status(400).json({ error: 'Invalid plans payload' });
});

// Dev & Production Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Tawtheeq COD SaaS running on http://localhost:${PORT}`);
  });
}

startServer();
