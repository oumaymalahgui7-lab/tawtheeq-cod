import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  textClassName?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
  textClassName = '',
}) => {
  const iconDimensions = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-11 h-11',
    xl: 'w-14 h-14'
  }[size];

  const fontSizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl',
    xl: 'text-3xl'
  }[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Original Modern Monogram Hex-Shield Logo */}
      <div className={`relative ${iconDimensions} rounded-xl bg-gradient-to-br from-purple-600 via-indigo-600 to-purple-900 p-[1.5px] shadow-lg shadow-purple-600/30 shrink-0 group`}>
        <div className="w-full h-full rounded-[10px] bg-[#0d0822] flex items-center justify-center relative overflow-hidden">
          {/* Subtle glow orb inside logo */}
          <div className="absolute inset-0 bg-radial from-purple-500/20 to-transparent"></div>
          
          {/* Stylized 'Tawtheeq' Geometric Vector Mark */}
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-5/6 h-5/6 text-purple-300 drop-shadow-[0_0_8px_rgba(168,85,247,0.7)] group-hover:scale-105 transition-transform"
          >
            {/* Hexagonal Shield Perimeter */}
            <path
              d="M12 2L4 6.5V12C4 16.5 7.5 20.7 12 22C16.5 20.7 20 16.5 20 12V6.5L12 2Z"
              className="text-purple-400 stroke-purple-500/60 fill-purple-950/40"
            />
            {/* Verified Pulse Checkmark */}
            <path
              d="M8.5 12.5L11 15L15.5 9.5"
              className="text-cyan-300 stroke-cyan-400 drop-shadow-[0_0_6px_rgba(34,211,238,0.8)]"
              strokeWidth="2.5"
            />
          </svg>
        </div>
      </div>

      {showText && (
        <div className="flex flex-col leading-none">
          <div className="flex items-center gap-1.5">
            <span className={`font-black text-white tracking-tight ${fontSizes} ${textClassName}`}>
              توثيق
            </span>
            <span className="text-[10px] sm:text-xs font-black px-1.5 py-0.5 rounded-md bg-purple-900/80 border border-purple-700/60 text-purple-200 tracking-wider">
              COD
            </span>
          </div>
          <span className="text-[9px] sm:text-[10px] text-purple-300/70 font-medium tracking-wide">
            Tawtheeq Platform
          </span>
        </div>
      )}
    </div>
  );
};
