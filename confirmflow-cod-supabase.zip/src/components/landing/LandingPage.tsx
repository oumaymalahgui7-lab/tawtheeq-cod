import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { BrandLogo } from '../common/BrandLogo';
import { 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  ArrowLeft, 
  ArrowRight, 
  Send, 
  Bot, 
  ShieldCheck, 
  TrendingUp, 
  MessageSquare, 
  Clock, 
  ChevronDown, 
  ChevronUp, 
  HelpCircle, 
  Check, 
  Zap, 
  Smartphone, 
  DollarSign, 
  ShoppingBag,
  Layers,
  BarChart3,
  Award
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { setActiveTab, setIsAuthModalOpen, setAuthMode, language, dir, t } = useApp();

  // Interactive Live Simulator State on Landing Page
  const [simMessage, setSimMessage] = useState('');
  const [simCustomerName, setSimCustomerName] = useState('أمين السبتي');
  const [simCity, setSimCity] = useState('الدار البيضاء');
  const [simProduct, setSimProduct] = useState('قفطان مغربي عصري زمردي');
  const [simPrice, setSimPrice] = useState(534);
  const [simOrderStatus, setSimOrderStatus] = useState<'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'NEEDS_REVIEW'>('PENDING');
  const [simAnalysis, setSimAnalysis] = useState<any>(null);
  const [isSimLoading, setIsSimLoading] = useState(false);

  // ROI Calculator state
  const [monthlyOrders, setMonthlyOrders] = useState(600);
  const shippingLossPerReturn = 45; // DH
  const standardConfirmationRate = 0.45;
  const confirmFlowRate = 0.72;
  const extraConfirmedOrders = Math.round(monthlyOrders * (confirmFlowRate - standardConfirmationRate));
  const estimatedSavings = Math.round(extraConfirmedOrders * 380 * 0.35 + (monthlyOrders * 0.15 * shippingLossPerReturn));

  // FAQ Accordion state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleSimulateReply = async (textToUse?: string) => {
    const text = textToUse || simMessage;
    if (!text.trim()) return;

    setIsSimLoading(true);
    try {
      const res = await api.classifyText(text);
      if (res.success && res.classification) {
        setSimAnalysis(res.classification);
        if (res.classification.intent === 'CONFIRMED') {
          setSimOrderStatus('CONFIRMED');
        } else if (res.classification.intent === 'CANCELLED') {
          setSimOrderStatus('CANCELLED');
        } else {
          setSimOrderStatus('NEEDS_REVIEW');
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSimLoading(false);
    }
  };

  const faqs = [
    {
      q: 'كيف يعمل توثيق COD؟',
      a: 'يتصل توثيق COD بمتجرك الإلكتروني (Shopify, WooCommerce, YouCan) عبر Webhooks فائقة السرعة. بمجرد تسجيل طلب دفع عند الاستلام (COD) جديد، يرسل النظام رسالة واتساب رسمية تلقائية للعميل تحتوي على تفاصيل الطلب وزري تأكيد أو إلغاء. يفهم محرك الذكاء الاصطناعي رد العميل بالدارجة المغربية أو العربية أو الفرنسية ويحدّث حالة الطلب فوراً داخل الـ CRM.'
    },
    {
      q: 'ما هي المنصات المدعومة؟',
      a: 'ندعم رسمياً Shopify، WooCommerce، YouCan، بالإضافة إلى REST API مخصص يمكنك ربطه مع أي منصة خاصة أو متجر مبرمج حسب الطلب.'
    },
    {
      q: 'هل أحتاج Meta Business Manager؟',
      a: 'نعم، نحن نعتمد على WhatsApp Business Cloud API الرسمي لشركة Meta. هذا يتيح أزراراً تفاعلية رسمية وتواصلاً سحابياً معتمداً وموثوقاً.'
    },
    {
      q: 'كيف يتم احتساب استهلاك الرصيد؟',
      a: 'نظام شفاف ومباشر: يتم خصم 0.35 إلى 0.45 درهم لكل رسالة تأكيد ناجحة حسب باقتك. لا توجد أي مصاريف خفية، ويمكنك شحن رصيدك في أي وقت بالدرهم المغربي عبر بطاقة بنكية CMI أو تحويل.'
    },
    {
      q: 'هل يفهم النظام الدارجة المغربية والكلمات العامية؟',
      a: 'نعم وبدقة فائقة تصل إلى 98%! تم تدريب نموذج الذكاء الاصطناعي المدمج لدينا على آلاف الرسائل الواقعية بالدارجة المغربية مثل: "واخا صافي صيفطوه"، "ناضي"، "جيبوه غدا"، "لا سمحليا لقيتو عند واحد اخر"، "شحال التوصيل؟" مع تمييز الاستفسارات التي تحتاج مراجعة التاجر.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#090614] text-slate-100 overflow-hidden">
      
      {/* Background Neon Purple Glow Effects */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[600px] pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-150px] left-1/2 -translate-x-1/2 w-[700px] h-[450px] bg-gradient-to-b from-purple-600/25 via-fuchsia-600/15 to-transparent blur-[120px] rounded-full"></div>
      </div>

      {/* Hero Section */}
      <section className="relative z-10 pt-16 pb-20 md:pt-24 md:pb-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        
        {/* Glow Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-950/70 border border-purple-600/40 text-purple-300 text-xs sm:text-sm font-medium mb-8 shadow-lg shadow-purple-900/30">
          <Zap className="w-4 h-4 text-purple-400" />
          <span>تأكيد تلقائي عبر واتساب في الوقت الحقيقي</span>
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-white max-w-4xl mx-auto leading-[1.15] mb-6">
          أكد طلبات الدفع عند الاستلام{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-fuchsia-300 to-indigo-400">
            COD
          </span>{' '}
          بسهولة
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed mb-10">
          نظام ذكي لتأكيد طلبات متجرك تلقائيًا عبر WhatsApp وإدارة جميع طلباتك من لوحة تحكم واحدة.
        </p>

        {/* Hero CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto mb-16">
          <button
            onClick={() => {
              setAuthMode('signup');
              setIsAuthModalOpen(true);
            }}
            className="w-full sm:w-auto px-8 py-4 text-sm sm:text-base font-extrabold text-white bg-gradient-to-r from-purple-600 via-purple-500 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-2xl shadow-xl shadow-purple-600/40 hover:shadow-purple-600/60 hover:scale-[1.02] active:scale-98 transition-all flex items-center justify-center gap-2 group cursor-pointer"
          >
            <span>ابدأ الآن مجاناً</span>
            {dir === 'rtl' ? (
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            ) : (
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            )}
          </button>

          <button
            onClick={() => {
              const el = document.getElementById('interactive-demo');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="w-full sm:w-auto px-6 py-4 text-sm sm:text-base font-semibold text-purple-200 bg-purple-950/50 hover:bg-purple-900/50 border border-purple-700/50 rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>شاهد التجربة الحية</span>
          </button>
        </div>

        {/* Hero Visual Preview Image */}
        <div className="relative max-w-5xl mx-auto mb-16 rounded-3xl p-2 bg-gradient-to-b from-purple-500/30 via-purple-900/10 to-transparent border border-purple-600/30 shadow-2xl shadow-purple-950/80 glow-purple">
          <div className="rounded-2xl overflow-hidden bg-[#0e0921] relative aspect-[16/9]">
            <img
              src="/src/assets/images/saas_hero_mockup_1790907558380.jpg"
              alt="Taakeed COD Dashboard & WhatsApp Automation Preview"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-top opacity-95 hover:scale-[1.01] transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#090614] via-transparent to-transparent opacity-60"></div>
          </div>
        </div>

        {/* Verified Feature Pillars Bar (Replaced unverified claims) */}
        <div className="pt-4 border-t border-purple-900/30 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto text-center text-xs">
          <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-800/30">
            <p className="font-bold text-white text-sm">تأكيد آلي فوري</p>
            <p className="text-[11px] text-slate-400 mt-0.5">رسائل واتساب بأزرار تفاعلية</p>
          </div>
          <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-800/30">
            <p className="font-bold text-white text-sm">Meta Cloud API</p>
            <p className="text-[11px] text-slate-400 mt-0.5">بنية تحتية سحابية رسمية</p>
          </div>
          <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-800/30">
            <p className="font-bold text-white text-sm">فهم الدارجة المغربية</p>
            <p className="text-[11px] text-slate-400 mt-0.5">تحليل الردود بالذكاء الاصطناعي</p>
          </div>
          <div className="p-3 rounded-2xl bg-purple-950/40 border border-purple-800/30">
            <p className="font-bold text-white text-sm">Shopify & WooCommerce</p>
            <p className="text-[11px] text-slate-400 mt-0.5">ربط فوري بالـ Webhooks</p>
          </div>
        </div>
      </section>

      {/* CRM Live Cards Showcase (Numbers set to 0 initial state until data connected) */}
      <section className="relative z-10 py-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <p className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-2">لوحة المتابعة الذكية</p>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">إحصائيات متجرك في الوقت الفعلي</h2>
          <p className="text-xs text-slate-400 mt-1">تتحدث هذه الإحصائيات مباشرة وفورياً بمجرد وصول الطلبات من متجرك</p>
        </div>

        {/* CRM Cards Display with 0 initial states */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 sm:gap-4">
          
          <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-purple-600/60 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-400">Total Commandes</span>
              <ShoppingBag className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-2xl font-black text-white font-mono tabular-nums">0</p>
            <span className="text-[10px] text-slate-400 mt-1 block">في انتظار أول طلب</span>
          </div>

          <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-purple-600/60 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-400">Confirmées</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-2xl font-black text-emerald-400 font-mono tabular-nums">0</p>
            <span className="text-[10px] text-slate-400 mt-1 block">مؤكدة عبر واتساب</span>
          </div>

          <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-purple-600/60 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-400">Taux Confirmation</span>
              <TrendingUp className="w-4 h-4 text-indigo-400" />
            </div>
            <p className="text-2xl font-black text-indigo-400 font-mono tabular-nums">0%</p>
            <span className="text-[10px] text-slate-400 mt-1 block">نسبة التأكيد التلقائي</span>
          </div>

          <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-purple-600/60 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-400">Livrées</span>
              <Award className="w-4 h-4 text-sky-400" />
            </div>
            <p className="text-2xl font-black text-sky-400 font-mono tabular-nums">0</p>
            <span className="text-[10px] text-slate-400 mt-1 block">مسلمة ومحصلة</span>
          </div>

          <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-purple-600/60 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-400">Crédits disponibles</span>
              <Zap className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-2xl font-black text-amber-300 font-mono tabular-nums">0 <span className="text-xs font-normal">DH</span></p>
            <span className="text-[10px] text-slate-400 mt-1 block">جاهز للشحن والاستخدام</span>
          </div>

          <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-purple-600/60 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-slate-400">Chiffre d'affaires</span>
              <DollarSign className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-2xl font-black text-emerald-300 font-mono tabular-nums">0 <span className="text-xs font-normal">DH</span></p>
            <span className="text-[10px] text-slate-400 mt-1 block">مبيعات COD مؤكدة</span>
          </div>

        </div>
      </section>

      {/* SECTION: Interactive WhatsApp & AI Simulator */}
      <section id="interactive-demo" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-900/60 text-purple-300 text-xs font-semibold mb-3 border border-purple-700/50">
            <Sparkles className="w-3.5 h-3.5" />
            <span>تجربة تفاعلية حية</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white">جرّب كيف يفهم الذكاء الاصطناعي الدارجة المغربية</h2>
          <p className="text-sm sm:text-base text-slate-300 max-w-xl mx-auto mt-2">
            اختر رداً من الردود الواقعية للزبائن المغاربة أو اكتب ردك الخاص لترى كيف يقوم النظام بتحديث حالة الطلب أوتوماتيكياً!
          </p>
        </div>

        {/* Simulator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Simulated Mobile WhatsApp Screen */}
          <div className="lg:col-span-6 flex justify-center">
            <div className="w-full max-w-[340px] rounded-[36px] bg-[#0b0817] border-4 border-purple-900/60 shadow-2xl shadow-purple-950 p-3.5 relative">
              {/* Phone Speaker Notch */}
              <div className="w-24 h-4 bg-slate-900 rounded-full mx-auto mb-3"></div>

              {/* WhatsApp Chat Header */}
              <div className="flex items-center gap-2.5 pb-2.5 border-b border-purple-900/40 mb-3 text-right">
                <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center font-bold text-white text-xs">
                  B
                </div>
                <div className="flex-1">
                  <p className="text-xs font-bold text-white truncate">بوتيك الأناقة المغربية</p>
                  <p className="text-[10px] text-emerald-400">متصل الآن عبر WhatsApp API</p>
                </div>
              </div>

              {/* Chat Message Bubble (Outbound Bot) */}
              <div className="space-y-3 mb-4">
                <div className="bg-[#191136] border border-purple-800/40 rounded-2xl rounded-tr-none p-3 text-right text-xs leading-relaxed shadow-sm">
                  <p className="font-semibold text-purple-300 mb-1">السلام عليكم {simCustomerName} 👋</p>
                  <p className="text-slate-200">توصلنا بطلبك من متجرنا:</p>
                  <div className="my-1.5 p-2 rounded-lg bg-black/40 text-[11px] space-y-0.5">
                    <p className="text-slate-300">📦 المنتج: <span className="text-white font-medium">{simProduct}</span></p>
                    <p className="text-slate-300">💰 المبلغ: <span className="text-emerald-400 font-bold">{simPrice} DH</span> (عند الاستلام)</p>
                    <p className="text-slate-300">📍 التوصيل: <span className="text-white">{simCity}</span></p>
                  </div>
                  <p className="text-slate-300">هل ترغب في تأكيد شحن طلبك؟</p>
                  
                  {/* WhatsApp Interactive Buttons */}
                  <div className="mt-2.5 pt-2 border-t border-purple-900/40 space-y-1.5">
                    <button
                      onClick={() => handleSimulateReply('واخا صافي ناضي صيفطوه ليا غدا')}
                      className="w-full py-1.5 px-2 bg-purple-600/30 hover:bg-purple-600 text-purple-200 hover:text-white rounded-lg text-center font-semibold text-[11px] transition-colors"
                    >
                      ✅ تأكيد الطلب
                    </button>
                    <button
                      onClick={() => handleSimulateReply('لا سمحليا لقيتو عند واحد اخر ما بغيتوش')}
                      className="w-full py-1.5 px-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 rounded-lg text-center font-semibold text-[11px] transition-colors"
                    >
                      ❌ إلغاء الطلب
                    </button>
                  </div>
                  <span className="text-[9px] text-slate-500 block text-left mt-1">14:32 ✓✓</span>
                </div>

                {/* Customer Reply Bubble */}
                {simMessage && (
                  <div className="bg-purple-700/80 rounded-2xl rounded-tl-none p-3 text-right text-xs leading-relaxed shadow-md text-white max-w-[85%] mr-auto">
                    <p>{simMessage}</p>
                    <span className="text-[9px] text-purple-200 block text-left mt-1">14:33 ✓✓</span>
                  </div>
                )}
              </div>

              {/* Chat Input Bar */}
              <div className="flex items-center gap-1.5 pt-2 border-t border-purple-900/40">
                <input
                  type="text"
                  value={simMessage}
                  onChange={(e) => setSimMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSimulateReply()}
                  placeholder="اكتب رد العميل بالدارجة..."
                  className="flex-1 bg-purple-950/60 border border-purple-800/40 rounded-xl px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
                <button
                  onClick={() => handleSimulateReply()}
                  disabled={isSimLoading || !simMessage}
                  className="p-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-xl transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* AI Live Analysis & Order Status Card */}
          <div className="lg:col-span-6 space-y-4">
            
            {/* Quick Presets */}
            <div className="glass-panel p-5 rounded-2xl border border-purple-800/40">
              <p className="text-xs font-bold text-slate-300 mb-2">جرب هذه الردود الشائعة بالدارجة:</p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => {
                    const text = 'واخا صافي ناضي صيفطوه ليا غدا';
                    setSimMessage(text);
                    handleSimulateReply(text);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800/60 border border-purple-700/40 text-xs text-purple-200 transition-colors"
                >
                  "واخا صافي ناضي صيفطوه" (تأكيد)
                </button>
                <button
                  onClick={() => {
                    const text = 'ايه جيبوه ليا الله يحفظك';
                    setSimMessage(text);
                    handleSimulateReply(text);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800/60 border border-purple-700/40 text-xs text-purple-200 transition-colors"
                >
                  "ايه جيبوه ليا" (تأكيد)
                </button>
                <button
                  onClick={() => {
                    const text = 'لا سمحليا لقيتو عند واحد اخر ما بغيتوش';
                    setSimMessage(text);
                    handleSimulateReply(text);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/50 border border-rose-800/40 text-xs text-rose-300 transition-colors"
                >
                  "ما بقيتش بغيتو لغيو" (إلغاء)
                </button>
                <button
                  onClick={() => {
                    const text = 'واش كاين فاللون لكحل؟ وشحال التوصيل لمراكش؟';
                    setSimMessage(text);
                    handleSimulateReply(text);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-amber-950/40 hover:bg-amber-900/50 border border-amber-800/40 text-xs text-amber-300 transition-colors"
                >
                  "واش كاين فاللون لكحل؟" (سؤال)
                </button>
                <button
                  onClick={() => {
                    const text = 'Oui je confirme pour demain svp';
                    setSimMessage(text);
                    handleSimulateReply(text);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-indigo-950/40 hover:bg-indigo-900/50 border border-indigo-800/40 text-xs text-indigo-300 transition-colors"
                >
                  "Oui je confirme" (فرنسية)
                </button>
              </div>
            </div>

            {/* AI Decision Result Box */}
            <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 text-right">
              <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-3">
                <div className="flex items-center gap-2">
                  <Bot className="w-5 h-5 text-purple-400" />
                  <span className="text-sm font-bold text-white">تحليل الذكاء الاصطناعي (AI NLP)</span>
                </div>
                {isSimLoading ? (
                  <span className="text-xs text-purple-400 animate-pulse">جاري التحليل...</span>
                ) : simAnalysis ? (
                  <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-purple-900/60 text-purple-200">
                    دقة: {Math.round(simAnalysis.confidence * 100)}%
                  </span>
                ) : null}
              </div>

              {simAnalysis ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">النية المصنفة (Intent):</span>
                    <span className={`text-xs font-bold px-2.5 py-1 rounded-lg ${
                      simAnalysis.intent === 'CONFIRMED' 
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50' 
                        : simAnalysis.intent === 'CANCELLED'
                        ? 'bg-rose-950 text-rose-400 border border-rose-800/50'
                        : 'bg-amber-950 text-amber-400 border border-amber-800/50'
                    }`}>
                      {simAnalysis.intent === 'CONFIRMED' ? 'مؤكد تلقائياً ✅' : simAnalysis.intent === 'CANCELLED' ? 'ملغي أوتوماتيكياً ❌' : 'يحتاج مراجعة التاجر ❓'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">اللغة / اللهجة المكتشفة:</span>
                    <span className="text-xs text-purple-300 font-medium">{simAnalysis.language}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-900/40">
                    <p className="text-[11px] text-slate-400 mb-1 font-semibold">تفسير النموذج:</p>
                    <p className="text-xs text-slate-200 leading-relaxed">{simAnalysis.reason}</p>
                    {simAnalysis.extractedNotes && (
                      <p className="text-[11px] text-purple-300 mt-1">
                        📌 ملاحظة مستخرجة: {simAnalysis.extractedNotes}
                      </p>
                    )}
                  </div>

                  {/* Impact on CRM Status */}
                  <div className="pt-2 border-t border-purple-900/40 flex items-center justify-between">
                    <span className="text-xs text-slate-300">حالة الطلب في CRM:</span>
                    <span className="text-xs font-bold text-white bg-purple-900/50 px-3 py-1 rounded-lg">
                      {simOrderStatus === 'CONFIRMED' ? 'CONFIRMED (جاهز للشحن)' : simOrderStatus === 'CANCELLED' ? 'CANCELLED (توفير مصاريف الشحن)' : 'NEEDS_REVIEW'}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="py-6 text-center text-slate-400 text-xs">
                  اضغط على أحد الأزرار أعلاه أو اكتب رداً لتشاهد التحليل المباشر للذكاء الاصطناعي
                </div>
              )}
            </div>

            {/* Live Dashboard Button CTA */}
            <button
              onClick={() => setActiveTab('dashboard')}
              className="w-full py-3.5 bg-gradient-to-r from-purple-900/80 to-indigo-900/80 hover:from-purple-800 hover:to-indigo-800 border border-purple-700/50 text-white font-bold rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer"
            >
              <span>معاينة لوحة التحكم الكاملة</span>
              <BarChart3 className="w-4 h-4 text-purple-300" />
            </button>
          </div>

        </div>
      </section>

      {/* SECTION: How It Works */}
      <section id="how-it-works" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-2">الخطوات الأربع</p>
          <h2 className="text-3xl sm:text-4xl font-black text-white">كيف يعمل توثيق COD لأتمتة متجرك؟</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          
          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 relative text-right">
            <div className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-600/50 flex items-center justify-center font-bold text-white text-sm mb-4">
              01
            </div>
            <h3 className="text-base font-bold text-white mb-2">استقبال الطلب تلقائياً</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              بمجرد أن يطلب العميل من شوبيفاي أو ووكومرس، يصل الطلب فوراً عبر Webhook آمن ومشفّر دون أي تدخل يدوي.
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 relative text-right">
            <div className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-600/50 flex items-center justify-center font-bold text-white text-sm mb-4">
              02
            </div>
            <h3 className="text-base font-bold text-white mb-2">إرسال واتساب رسمي</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              فور تسجيل الطلب في متجرك، يستلم العميل رسالة واتساب أنيقة بأزرار تفاعلية تتضمن اسمه، منتجه، وعنوانه ومبلغ الدفع.
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 relative text-right">
            <div className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-600/50 flex items-center justify-center font-bold text-white text-sm mb-4">
              03
            </div>
            <h3 className="text-base font-bold text-white mb-2">فهم ردود الزبائن بالذكاء الاصطناعي</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              محرك ذكي مخصص للدارجة المغربية والعربية والفرنسية يفهم إذا كان العميل موافقاً، ملغياً، أو لديه استفسار عن المنتج.
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 relative text-right">
            <div className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-600/50 flex items-center justify-center font-bold text-white text-sm mb-4">
              04
            </div>
            <h3 className="text-base font-bold text-white mb-2">تحديث CRM والشحن</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              تتغير حالة الطلب فورياً في CRM إلى "مؤكد" أو "ملغي". ترسل شركة الشحن الطلبات المؤكدة فقط لتفادي أي مصاريف شحن ضائعة.
            </p>
          </div>

        </div>
      </section>

      {/* SECTION: Features Bento Grid */}
      <section id="features" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-2">المميزات الأساسية</p>
          <h2 className="text-3xl sm:text-4xl font-black text-white">كل ما يحتاجه تاجر الـ COD لمضاعفة أرباحه</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-right">
          
          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 hover:border-purple-600/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/50 flex items-center justify-center text-purple-400 mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">واتساب بيزنس سحابي رسمي (Meta Cloud API)</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              نستخدم البنية السحابية الرسمية لـ WhatsApp Business API من Meta لضمان تجربة تواصل موثوقة واحترافية لعلامتك التجارية.
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 hover:border-purple-600/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/50 flex items-center justify-center text-purple-400 mb-4">
              <Bot className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">ذكاء اصطناعي يفهم الدارجة المغربية</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              نموذج Gemini AI مدرب خصيصاً على ردود التجارة الإلكترونية بالمغرب ("واخا صيفطوها"، "ناضي"، "ما بقيتش بغيتو").
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 hover:border-purple-600/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/50 flex items-center justify-center text-purple-400 mb-4">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">متابعة آلية Follow-up ذكية</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              إذا لم يرد الزبون خلال المدة المحددة، يقوم النظام بإرسال تذكير لطيف يساعد على استعادة وتأكيد طلبات العملاء المترددين بفاعلية.
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 hover:border-purple-600/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/50 flex items-center justify-center text-purple-400 mb-4">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">إدارة متاجر متعددة في حساب واحد</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              اربط متجرك على شوبيفاي ومتجرك الثاني على ووكومرس وتابع جميع الطلبات والإحصائيات من لوحة موحدة.
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 hover:border-purple-600/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/50 flex items-center justify-center text-purple-400 mb-4">
              <BarChart3 className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">CRM متكامل وسجل العملاء</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              سجل تفصيلي لكل عميل، عدد طلباته المؤكدة والملغاة، وتاريخ مشترياته لمتابعة وتنسيق عمليات الشحن بدقة.
            </p>
          </div>

          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 hover:border-purple-600/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-700/50 flex items-center justify-center text-purple-400 mb-4">
              <Smartphone className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white mb-2">تطبيق PWA مثبت على هاتفك</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              ثبت توثيق COD على جوالك كالآيفون أو الأندرويد واستقبل إشعارات فورية بكل طلب مؤكد أو سؤال عميل جديد.
            </p>
          </div>

        </div>
      </section>

      {/* SECTION: Interactive ROI Calculator */}
      <section className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="glass-panel p-8 sm:p-10 rounded-3xl border border-purple-700/40 bg-gradient-to-b from-[#130b2e]/90 to-[#0c071d]/90 glow-purple">
          <div className="text-center mb-8">
            <span className="text-xs font-bold text-purple-400 uppercase tracking-widest">حاسبة العائد على الاستثمار</span>
            <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">كم ستوفر وتربح مع توثيق COD شهرياً؟</h2>
          </div>

          <div className="space-y-6 max-w-xl mx-auto">
            <div>
              <div className="flex justify-between items-center text-xs sm:text-sm font-semibold mb-2">
                <span className="text-slate-300">عدد طلبات COD الشهرية في متجرك:</span>
                <span className="text-purple-400 font-mono text-base">{monthlyOrders} طلب/شهر</span>
              </div>
              <input
                type="range"
                min="100"
                max="3000"
                step="50"
                value={monthlyOrders}
                onChange={(e) => setMonthlyOrders(Number(e.target.value))}
                className="w-full accent-purple-500 cursor-pointer h-2 bg-purple-950 rounded-lg"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
                <span>100 طلب</span>
                <span>1500 طلب</span>
                <span>3000 طلب</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-purple-900/40 text-center">
              <div className="p-4 rounded-2xl bg-purple-950/50 border border-purple-800/30">
                <p className="text-xs text-slate-400">طلبات إضافية مؤكدة</p>
                <p className="text-2xl sm:text-3xl font-black text-white font-mono mt-1">+{extraConfirmedOrders} طلب</p>
                <p className="text-[11px] text-purple-300 mt-1">رفع نسبة التأكيد من 45% إلى 72%</p>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/40">
                <p className="text-xs text-emerald-300">إجمالي الأرباح والتوفير التقديري</p>
                <p className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono mt-1">+{estimatedSavings.toLocaleString()} DH</p>
                <p className="text-[11px] text-slate-400 mt-1">أرباح مبيعات وتفادي مصاريف شحن وهمية</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION: Pricing Plans */}
      <section id="pricing" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-2">خطط الاشتراك</p>
          <h2 className="text-3xl sm:text-4xl font-black text-white">أسعار بسيطة وشفافة تناسب حجم متجرك</h2>
          <p className="text-sm text-slate-400 mt-2">لا عمولات خفية على المبيعات. ابدأ وجرّب بنفسك.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          
          {/* Starter Plan */}
          <div className="glass-panel p-6 rounded-3xl border border-purple-800/30 flex flex-col justify-between text-right">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">خطة البداية</p>
              <h3 className="text-xl font-black text-white mt-1">STARTER</h3>
              <div className="my-4">
                <span className="text-3xl sm:text-4xl font-black text-white font-mono">199</span>
                <span className="text-xs text-slate-400 mr-1.5">DH / شهرياً</span>
              </div>
              <p className="text-xs text-slate-300 pb-4 border-b border-purple-900/40 mb-4">
                مثالية للمتاجر الناشئة والمسوقين الأفراد.
              </p>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>حتى 150 طلب COD شهرياً</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>متجر واحد متصل (Shopify / WooCommerce)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>250 رسالة واتساب مدمجة</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>تحليل الذكاء الاصطناعي للدارجة</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>دعم عبر البريد والواتساب</span>
                </li>
              </ul>
            </div>
            <button
              onClick={() => {
                setAuthMode('signup');
                setIsAuthModalOpen(true);
              }}
              className="mt-6 w-full py-3 rounded-xl bg-purple-950/70 hover:bg-purple-900 text-purple-200 font-bold text-xs transition-colors"
            >
              اختيار باقة البداية
            </button>
          </div>

          {/* Pro Plan (Popular) */}
          <div className="glass-panel p-6 rounded-3xl border-2 border-purple-500 shadow-2xl shadow-purple-900/40 relative flex flex-col justify-between text-right scale-[1.02]">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white text-[11px] font-extrabold shadow-md">
              الأكثر طلباً للتجار
            </div>
            <div>
              <p className="text-xs font-bold text-purple-400 uppercase tracking-wider">خطة المحترف</p>
              <h3 className="text-xl font-black text-white mt-1">PRO</h3>
              <div className="my-4">
                <span className="text-3xl sm:text-4xl font-black text-purple-400 font-mono">399</span>
                <span className="text-xs text-slate-400 mr-1.5">DH / شهرياً</span>
              </div>
              <p className="text-xs text-slate-300 pb-4 border-b border-purple-900/40 mb-4">
                للمتاجر النامية التي تحتاج أتمتة كاملة ومتابعات ذكية.
              </p>
              <ul className="space-y-2.5 text-xs text-slate-200">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>حتى 600 طلب COD شهرياً</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>ربط حتى 3 متاجر إلكترونية</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>1,000 رسالة تأكيد ومتابعة متضمنة</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>تذكيرات Follow-up ذكية بعد 15 دقيقة</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>CRM متكامل وسجل طلبات العملاء</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>دعم VIP فوري</span>
                </li>
              </ul>
            </div>
            <button
              onClick={() => {
                setAuthMode('signup');
                setIsAuthModalOpen(true);
              }}
              className="mt-6 w-full py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
            >
              ابدأ تجربة PRO الآن
            </button>
          </div>

          {/* Business Plan */}
          <div className="glass-panel p-6 rounded-3xl border border-purple-800/30 flex flex-col justify-between text-right">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">خطة الشركات</p>
              <h3 className="text-xl font-black text-white mt-1">BUSINESS</h3>
              <div className="my-4">
                <span className="text-3xl sm:text-4xl font-black text-white font-mono">799</span>
                <span className="text-xs text-slate-400 mr-1.5">DH / شهرياً</span>
              </div>
              <p className="text-xs text-slate-300 pb-4 border-b border-purple-900/40 mb-4">
                لبرندات التجارة الإلكترونية الكبرى ومجموعات البيع.
              </p>
              <ul className="space-y-2.5 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>حتى 2,500 طلب شهرياً + كوتا مرنة</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>ربط حتى 10 متاجر متعددة</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>4,000 رسالة متضمنة (تكلفة الرسالة 0.25 DH)</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>خوادم مخصصة ذات سرعة فائقة Webhooks</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>مدير حساب تقني مخصص</span>
                </li>
              </ul>
            </div>
            <button
              onClick={() => {
                setAuthMode('signup');
                setIsAuthModalOpen(true);
              }}
              className="mt-6 w-full py-3 rounded-xl bg-purple-950/70 hover:bg-purple-900 text-purple-200 font-bold text-xs transition-colors"
            >
              اختيار باقة الشركات
            </button>
          </div>

        </div>
      </section>

      {/* SECTION: FAQ Accordion (From user screenshot) */}
      <section id="faq" className="relative z-10 py-16 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <p className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-2">FAQ</p>
          <h2 className="text-3xl sm:text-4xl font-black text-white">أسئلة شائعة</h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="glass-panel rounded-2xl border border-purple-800/40 overflow-hidden text-right transition-all"
            >
              <button
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full p-4 sm:p-5 flex items-center justify-between text-right text-sm sm:text-base font-bold text-white hover:text-purple-300 transition-colors"
              >
                <span>{faq.q}</span>
                {openFaq === idx ? (
                  <ChevronUp className="w-4 h-4 text-purple-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>
              {openFaq === idx && (
                <div className="px-4 sm:px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-purple-900/30">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* SECTION: Final CTA */}
      <section className="relative z-10 py-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto text-center">
        <div className="p-10 sm:p-14 rounded-3xl bg-gradient-to-tr from-purple-950 via-[#180e38] to-indigo-950 border border-purple-600/40 glow-purple">
          <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
            جاهز لرفع نسبة تأكيد طلبات COD في متجرك اليوم؟
          </h2>
          <p className="text-slate-300 max-w-xl mx-auto mb-8 text-sm sm:text-base">
            انضم الآن إلى مئات التجار المغاربة والعرب الذين يعتمدون على توثيق COD لتقليل المرتجعات وزيادة الأرباح الصافية.
          </p>
          <button
            onClick={() => {
              setAuthMode('signup');
              setIsAuthModalOpen(true);
            }}
            className="px-8 py-4 text-sm sm:text-base font-extrabold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-2xl shadow-xl shadow-purple-600/40 hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            ابدأ تجربتك المجانية الآن ➔
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-purple-900/40 py-8 px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <BrandLogo size="sm" />
          </div>
          <p>© {new Date().getFullYear()} توثيق COD. جميع الحقوق محفوظة لرواد التجارة الإلكترونية COD.</p>
          <div className="flex items-center gap-4 text-slate-400">
            <button onClick={() => setActiveTab('docs')} className="hover:text-purple-300">دليل الربط</button>
            <button onClick={() => setActiveTab('landing')} className="hover:text-purple-300">الرئيسية</button>
          </div>
        </div>
      </footer>

    </div>
  );
};
