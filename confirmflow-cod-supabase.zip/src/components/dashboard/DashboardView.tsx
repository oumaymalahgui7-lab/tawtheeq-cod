import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { 
  ShoppingBag, 
  CheckCircle2, 
  XCircle, 
  TrendingUp, 
  DollarSign, 
  Zap, 
  Clock, 
  Truck, 
  RotateCcw, 
  AlertCircle,
  Plus,
  Send,
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  Calendar,
  Sparkles,
  Bot
} from 'lucide-react';
import { Order } from '../../types';

export const DashboardView: React.FC = () => {
  const { user, t, setSelectedOrderId, setActiveTab, showToast, language, dir } = useApp();

  const [timeFilter, setTimeFilter] = useState<'today' | '7days' | '30days' | 'month'>('7days');
  const [analytics, setAnalytics] = useState<any>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSimulatingShopify, setIsSimulatingShopify] = useState(false);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [analyticsRes, ordersRes] = await Promise.all([
        api.getAnalytics(),
        api.getOrders({ limit: 6 })
      ]);
      setAnalytics(analyticsRes);
      setRecentOrders(ordersRes.orders || []);
    } catch (e) {
      console.error('Error loading dashboard:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, [timeFilter]);

  const handleSimulateShopifyOrder = async () => {
    setIsSimulatingShopify(true);
    try {
      const cities = ['الدار البيضاء', 'الرباط', 'مراكش', 'طنجة', 'فاس', 'أكادير'];
      const names = ['سعيد المرابط', 'منى التازي', 'عمر البقالي', 'حنان الصقلي', 'طارق العلمي'];
      const products = ['قفطان مغربي مطرز ملكي', 'سيروم العناية بالبشرة أرجان طبيعي', 'حذاء رياضي أنيق مريح', 'طقم أواني نحاسية تقليدية'];
      
      const randomCity = cities[Math.floor(Math.random() * cities.length)];
      const randomName = names[Math.floor(Math.random() * names.length)];
      const randomProduct = products[Math.floor(Math.random() * products.length)];
      const randomPrice = Math.floor(Math.random() * 400) + 250;

      const payload = {
        id: Date.now(),
        customer: {
          first_name: randomName.split(' ')[0],
          last_name: randomName.split(' ')[1] || ''
        },
        shipping_address: {
          name: randomName,
          phone: `+2126${Math.floor(10000000 + Math.random() * 90000000)}`,
          city: randomCity,
          address1: 'شارع الحسن الثاني، عمارة 12'
        },
        total_price: String(randomPrice),
        line_items: [
          { title: randomProduct, quantity: 1, price: String(randomPrice - 35) }
        ]
      };

      const res = await api.simulateShopifyWebhook(payload);
      if (res.success) {
        showToast(`تم استقبال طلب جديد ${res.orderNumber} من شوبيفاي وإرسال واتساب تلقائياً!`, 'success');
        loadDashboardData();
      }
    } catch (e) {
      showToast('تعذر استقبال الطلب التجريبي', 'error');
    } finally {
      setIsSimulatingShopify(false);
    }
  };

  const kpis = analytics?.kpis || {
    totalOrders: 0,
    confirmed: 0,
    cancelled: 0,
    pending: 0,
    delivered: 0,
    returned: 0,
    needsReview: 0,
    confirmationRate: 0,
    revenue: 0,
    credits: user?.credits ?? 0,
    currency: 'DH'
  };

  const chartData = analytics?.chartData || [
    { day: 'السبت', total: 0, confirmed: 0, cancelled: 0, revenue: 0 },
    { day: 'الأحد', total: 0, confirmed: 0, cancelled: 0, revenue: 0 },
    { day: 'الإثنين', total: 0, confirmed: 0, cancelled: 0, revenue: 0 },
    { day: 'الثلاثاء', total: 0, confirmed: 0, cancelled: 0, revenue: 0 },
    { day: 'الأربعاء', total: 0, confirmed: 0, cancelled: 0, revenue: 0 },
    { day: 'الخميس', total: 0, confirmed: 0, cancelled: 0, revenue: 0 },
    { day: 'الجمعة', total: 0, confirmed: 0, cancelled: 0, revenue: 0 },
  ];

  const confirmedPct = kpis.totalOrders > 0 ? Math.round((kpis.confirmed / kpis.totalOrders) * 100) : 0;
  const pendingPct = kpis.totalOrders > 0 ? Math.round((kpis.pending / kpis.totalOrders) * 100) : 0;
  const cancelledPct = kpis.totalOrders > 0 ? Math.round((kpis.cancelled / kpis.totalOrders) * 100) : 0;
  const needsReviewPct = kpis.totalOrders > 0 ? Math.round((kpis.needsReview / kpis.totalOrders) * 100) : 0;
  const returnedPct = kpis.totalOrders > 0 ? Math.round((kpis.returned / kpis.totalOrders) * 100) : 0;

  const maxChartTotal = Math.max(...chartData.map((d: any) => d.total), 1);

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Quick Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>لوحة التحكم الرئيسية</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
              Live COD CRM
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            متابعة فورية لطلبات الدفع عند الاستلام، نسبة التأكيد، والمبيعات المحققة.
          </p>
        </div>

        {/* Filters and Actions */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Time Filter Tabs */}
          <div className="flex items-center bg-[#130d2a] p-1 rounded-xl border border-purple-900/40 text-xs">
            <button
              onClick={() => setTimeFilter('today')}
              className={`px-3 py-1.5 rounded-lg transition-colors font-semibold ${timeFilter === 'today' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              {t('filterToday')}
            </button>
            <button
              onClick={() => setTimeFilter('7days')}
              className={`px-3 py-1.5 rounded-lg transition-colors font-semibold ${timeFilter === '7days' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              {t('filter7Days')}
            </button>
            <button
              onClick={() => setTimeFilter('30days')}
              className={`px-3 py-1.5 rounded-lg transition-colors font-semibold ${timeFilter === '30days' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              {t('filter30Days')}
            </button>
            <button
              onClick={() => setTimeFilter('month')}
              className={`px-3 py-1.5 rounded-lg transition-colors font-semibold ${timeFilter === 'month' ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
            >
              {t('filterMonth')}
            </button>
          </div>

          {/* Quick Action: Simulate Shopify Order */}
          <button
            onClick={handleSimulateShopifyOrder}
            disabled={isSimulatingShopify}
            className="flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-purple-800 to-indigo-800 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer disabled:opacity-50"
            title="إرسال طلب جديد كما لو جاء من شوبيفاي"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-300" />
            <span>{isSimulatingShopify ? 'جاري الاستقبال...' : t('simulateShopify')}</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Row (Based directly on user screenshots) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3.5 sm:gap-4">
        
        {/* Total Orders */}
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-purple-600/50 transition-all">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400">{t('totalOrders')}</span>
            <ShoppingBag className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-black text-white font-mono tabular-nums">{kpis.totalOrders}</p>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-purple-300">
            <span>واردة من المتاجر</span>
          </div>
        </div>

        {/* Confirmed */}
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-emerald-600/50 transition-all">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400">{t('confirmed')}</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-400 font-mono tabular-nums">{kpis.confirmed}</p>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-400">
            <span>جاهزة للشحن</span>
          </div>
        </div>

        {/* Confirmation Rate */}
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-indigo-600/50 transition-all">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400">{t('confirmationRate')}</span>
            <TrendingUp className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-2xl font-black text-indigo-400 font-mono tabular-nums">{kpis.confirmationRate}%</p>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-slate-400">
            <span>معدل التأكيد العام</span>
          </div>
        </div>

        {/* Cancelled */}
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-rose-600/50 transition-all">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400">{t('cancelled')}</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-black text-rose-400 font-mono tabular-nums">{kpis.cancelled}</p>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-rose-300">
            <span>تم تفادي الشحن الوهمي</span>
          </div>
        </div>

        {/* Delivered */}
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-sky-600/50 transition-all">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400">{t('delivered')}</span>
            <Truck className="w-4 h-4 text-sky-400" />
          </div>
          <p className="text-2xl font-black text-sky-400 font-mono tabular-nums">{kpis.delivered}</p>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-sky-300">
            <span>تم التحصيل بنجاح</span>
          </div>
        </div>

        {/* Revenue */}
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 relative overflow-hidden group hover:border-emerald-500/50 transition-all">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400">{t('revenue')}</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-300 font-mono tabular-nums">
            {kpis.revenue.toLocaleString()} <span className="text-xs font-normal">DH</span>
          </p>
          <div className="mt-1 flex items-center gap-1 text-[10px] text-emerald-400">
            <span>قيمة الطلبات المؤكدة</span>
          </div>
        </div>

      </div>

      {/* Main Charts & Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Weekly Trend Bar Chart */}
        <div className="lg:col-span-8 glass-panel p-5 rounded-2xl border border-purple-800/40">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-sm font-bold text-white">نشاط الطلبات والتأكيد اليومي</h2>
              <p className="text-[11px] text-slate-400">توزيع الطلبات الواردة والمؤكدة خلال الفترة</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-purple-300">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span> إجمالي الطلبات
              </span>
              <span className="flex items-center gap-1.5 text-emerald-300">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> المؤكدة
              </span>
            </div>
          </div>

          {/* Clean Tabular / Bar Visualization */}
          <div className="h-64 flex items-end justify-between gap-3 pt-6 pb-2 px-2 border-b border-purple-900/40">
            {chartData.map((d: any, idx: number) => {
              const heightPercentTotal = Math.round((d.total / maxChartTotal) * 100);
              const heightPercentConfirmed = Math.round((d.confirmed / maxChartTotal) * 100);

              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-2 group relative">
                  {/* Tooltip on Hover */}
                  <div className="absolute -top-10 opacity-0 group-hover:opacity-100 transition-opacity bg-purple-950 text-white text-[10px] py-1 px-2 rounded-lg border border-purple-700 pointer-events-none whitespace-nowrap z-20 shadow-lg">
                    {d.total} طلب | {d.confirmed} مؤكد ({Math.round((d.confirmed / d.total) * 100)}%)
                  </div>

                  {/* Dual Bars */}
                  <div className="w-full max-w-[28px] h-full flex items-end justify-center gap-1">
                    <div 
                      style={{ height: `${heightPercentTotal}%` }} 
                      className="w-1/2 bg-purple-600/70 group-hover:bg-purple-500 rounded-t transition-all"
                    ></div>
                    <div 
                      style={{ height: `${heightPercentConfirmed}%` }} 
                      className="w-1/2 bg-emerald-500/80 group-hover:bg-emerald-400 rounded-t transition-all"
                    ></div>
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium truncate max-w-full">
                    {d.day}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-slate-400 pt-1">
            <span>معدل سرعة استجابة واتساب: <strong className="text-white font-mono">1.2 ثانية</strong></span>
            <span>نسبة خفض الإلغاءات: <strong className="text-emerald-400 font-mono">+42%</strong></span>
          </div>
        </div>

        {/* Orders Breakdown Status Circle & AI Insights */}
        <div className="lg:col-span-4 glass-panel p-5 rounded-2xl border border-purple-800/40 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-bold text-white">توزيع حالات الطلبات</h2>
              <span className="text-xs text-purple-400 font-mono">COD Flow</span>
            </div>

            {/* Status Breakdown Progress Bars */}
            <div className="space-y-3.5">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">مؤكدة (Confirmed)</span>
                  <span className="font-bold text-emerald-400 font-mono">{kpis.confirmed} طلب ({confirmedPct}%)</span>
                </div>
                <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full transition-all duration-500" style={{ width: `${confirmedPct}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">بانتظار التأكيد (Pending)</span>
                  <span className="font-bold text-amber-400 font-mono">{kpis.pending} طلب ({pendingPct}%)</span>
                </div>
                <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400 rounded-full transition-all duration-500" style={{ width: `${pendingPct}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">ملغاة (Cancelled)</span>
                  <span className="font-bold text-rose-400 font-mono">{kpis.cancelled} طلب ({cancelledPct}%)</span>
                </div>
                <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full transition-all duration-500" style={{ width: `${cancelledPct}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">تحتاج مراجعة AI (Needs Review)</span>
                  <span className="font-bold text-indigo-400 font-mono">{kpis.needsReview} طلب ({needsReviewPct}%)</span>
                </div>
                <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-500 rounded-full transition-all duration-500" style={{ width: `${needsReviewPct}%` }}></div>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">مرتجعات (Returned)</span>
                  <span className="font-bold text-slate-400 font-mono">{kpis.returned} طلب ({returnedPct}%)</span>
                </div>
                <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                  <div className="h-full bg-slate-500 rounded-full transition-all duration-500" style={{ width: `${returnedPct}%` }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* AI Automated Efficiency Note */}
          <div className="mt-6 p-3.5 rounded-xl bg-purple-950/50 border border-purple-800/40 text-xs text-slate-300 flex items-start gap-2.5">
            <Bot className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              {kpis.cancelled > 0 ? (
                <>وفّر نظام <strong className="text-purple-300">توثيق COD</strong> مصاريف شحن ضائعة عبر إلغاء <strong className="text-rose-400 font-mono">{kpis.cancelled}</strong> طلبات غير مؤكدة تلقائياً.</>
              ) : (
                <>محرك <strong className="text-purple-300">توثيق COD</strong> الذكي جاهز لأتمتة وتأكيد كافة طلبات متجرك فور وصولها عبر الواتساب.</>
              )}
            </p>
          </div>
        </div>

      </div>

      {/* Recent Orders Feed Section */}
      <div className="glass-panel p-5 rounded-2xl border border-purple-800/40">
        <div className="flex items-center justify-between pb-4 border-b border-purple-900/30 mb-4">
          <div>
            <h2 className="text-base font-bold text-white">أحدث طلبات COD الواردة</h2>
            <p className="text-xs text-slate-400">آخر التحديثات التلقائية عبر الواتساب وCRM</p>
          </div>
          <button
            onClick={() => setActiveTab('orders')}
            className="text-xs font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors"
          >
            <span>عرض كل الطلبات</span>
            {dir === 'rtl' ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>

        {/* Responsive Table / Cards */}
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-purple-900/40 text-slate-400 font-semibold">
                <th className="pb-3 pr-2">رقم الطلب</th>
                <th className="pb-3">العميل</th>
                <th className="pb-3">الهاتف والمدينة</th>
                <th className="pb-3">المبلغ (COD)</th>
                <th className="pb-3">الحالة</th>
                <th className="pb-3">واتساب AI</th>
                <th className="pb-3 pl-2 text-center">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-900/20">
              {recentOrders.map((order) => (
                <tr 
                  key={order.id} 
                  className="hover:bg-purple-950/30 transition-colors group cursor-pointer"
                  onClick={() => {
                    setSelectedOrderId(order.id);
                    setActiveTab('orders');
                  }}
                >
                  <td className="py-3 pr-2 font-mono font-bold text-purple-300">
                    {order.orderNumber}
                  </td>
                  <td className="py-3 font-semibold text-white">
                    {order.customerName}
                  </td>
                  <td className="py-3 text-slate-300">
                    <div>{order.customerCity}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{order.customerPhone}</div>
                  </td>
                  <td className="py-3 font-mono font-bold text-emerald-400">
                    {order.totalPrice} DH
                  </td>
                  <td className="py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      order.status === 'CONFIRMED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                        : order.status === 'CANCELLED'
                        ? 'bg-rose-950 text-rose-400 border border-rose-800/40'
                        : order.status === 'NEEDS_REVIEW'
                        ? 'bg-amber-950 text-amber-400 border border-amber-800/40'
                        : 'bg-purple-950 text-purple-300 border border-purple-800/40'
                    }`}>
                      {t(`status_${order.status}`)}
                    </span>
                  </td>
                  <td className="py-3 text-slate-300">
                    {order.messages.length > 1 ? (
                      <span className="text-[11px] text-purple-300 flex items-center gap-1">
                        <Bot className="w-3 h-3 text-purple-400" />
                        تم الرد والتحليل
                      </span>
                    ) : (
                      <span className="text-[11px] text-slate-400">
                        مرسلة ({order.messages[0]?.status || 'SENT'})
                      </span>
                    )}
                  </td>
                  <td className="py-3 pl-2 text-center">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedOrderId(order.id);
                        setActiveTab('orders');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-purple-900/40 hover:bg-purple-800 text-purple-200 text-[11px] transition-colors"
                    >
                      التفاصيل
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
