import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Store, PlatformType } from '../../types';
import { 
  Store as StoreIcon, 
  Plus, 
  Copy, 
  Check, 
  ExternalLink, 
  Sparkles, 
  CheckCircle2, 
  Zap, 
  Globe, 
  ShieldCheck, 
  Layers,
  Code
} from 'lucide-react';

export const StoresView: React.FC = () => {
  const { stores, setActiveStore, showToast, t, refreshData } = useApp();

  const [isAddStoreModalOpen, setIsAddStoreModalOpen] = useState(false);
  const [storeName, setStoreName] = useState('');
  const [storeDomain, setStoreDomain] = useState('');
  const [storePlatform, setStorePlatform] = useState<PlatformType>('SHOPIFY');
  const [storePhone, setStorePhone] = useState('+212600000000');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [simulatingWebhook, setSimulatingWebhook] = useState(false);

  const handleCreateStore = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName || !storeDomain) {
      showToast('يرجى كتابة اسم المتجر ورابط النطاق', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await api.createStore({
        name: storeName,
        domain: storeDomain,
        platform: storePlatform,
        currency: 'DH',
        phone: storePhone,
        isActive: true
      });
      if (res.success) {
        showToast('تمت إضافة المتجر بنجاح وتوليد رابط Webhook الخاص به ✅', 'success');
        setIsAddStoreModalOpen(false);
        setStoreName('');
        setStoreDomain('');
        refreshData();
      }
    } catch (e) {
      showToast('فشل إضافة المتجر', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = (text: string, title: string) => {
    navigator.clipboard.writeText(text);
    showToast(`تم نسخ ${title} بنجاح`, 'success');
  };

  const handleSimulateWebhook = async (store: Store) => {
    setSimulatingWebhook(true);
    try {
      const payload = {
        id: Date.now(),
        customer: { first_name: 'كريم', last_name: 'الفاسي' },
        shipping_address: {
          name: 'كريم الفاسي',
          phone: '+212678990011',
          city: 'الرباط',
          address1: 'شارع النخيل، حي الرياض'
        },
        total_price: '420',
        line_items: [{ title: 'ساعة يد كلاسيكية رجالية مقاومة للماء', quantity: 1, price: '385' }]
      };

      const res = await api.simulateShopifyWebhook(payload);
      if (res.success) {
        showToast(`تم استقبال Webhook بنجاح من متجر ${store.name} وإنشاء الطلب ${res.orderNumber}!`, 'success');
        refreshData();
      }
    } catch (e) {
      showToast('فشل استقبال الـ Webhook التجريبي', 'error');
    } finally {
      setSimulatingWebhook(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>المتاجر المتصلة وروابط Webhooks</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
              {stores.length} متاجر
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            اربط متاجرك الإلكترونية على Shopify وWooCommerce لاستقبال طلبات الدفع عند الاستلام فورياً.
          </p>
        </div>

        <button
          onClick={() => setIsAddStoreModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-600/30 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة متجر جديد</span>
        </button>
      </div>

      {/* Stores Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {stores.map((store) => (
          <div
            key={store.id}
            className="glass-panel p-5 rounded-2xl border border-purple-800/40 space-y-4 text-right"
          >
            <div className="flex items-start justify-between pb-3 border-b border-purple-900/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-900/60 border border-purple-600/50 flex items-center justify-center text-purple-300">
                  <StoreIcon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">{store.name}</h3>
                  <a
                    href={`https://${store.domain}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1 font-mono"
                  >
                    <span>{store.domain}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              <span className="text-[10px] px-2 py-0.5 rounded bg-black/40 text-purple-300 font-mono uppercase font-bold border border-purple-800/50">
                {store.platform}
              </span>
            </div>

            {/* Webhook Endpoint Box */}
            <div className="space-y-2 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">رابط Webhook المخصص للطلبات الجديدة:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}${store.webhookUrl}`}
                    className="flex-1 bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white font-mono text-[11px] focus:outline-none"
                  />
                  <button
                    onClick={() => copyToClipboard(`${window.location.origin}${store.webhookUrl}`, 'رابط Webhook')}
                    className="p-2 bg-purple-900/50 hover:bg-purple-800 text-slate-300 rounded-xl transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Webhook Secret Key (للتوقيع والتحقق):</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={store.webhookSecret}
                    className="flex-1 bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-purple-300 font-mono text-[11px] focus:outline-none"
                  />
                  <button
                    onClick={() => copyToClipboard(store.webhookSecret, 'Webhook Secret')}
                    className="p-2 bg-purple-900/50 hover:bg-purple-800 text-slate-300 rounded-xl transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Webhook Test Simulator Button */}
            <div className="pt-3 border-t border-purple-900/40 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Webhook نشط ومتصل
              </span>

              <button
                onClick={() => handleSimulateWebhook(store)}
                disabled={simulatingWebhook}
                className="px-3 py-1.5 rounded-xl bg-purple-900/50 hover:bg-purple-800 text-purple-200 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-300" />
                <span>{simulatingWebhook ? 'جاري الاختبار...' : 'تجربة إرسال طلب (Test Ping)'}</span>
              </button>
            </div>

          </div>
        ))}
      </div>

      {/* Step-by-Step Shopify & WooCommerce Setup Guide */}
      <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 text-right space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Code className="w-4 h-4 text-purple-400" />
          <span>طريقة ربط Webhook في منصة Shopify بـ 3 خطوات فقط:</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-300">
          <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/30">
            <span className="font-bold text-purple-400 block mb-1">1. إعدادات الإشعارات</span>
            <p className="leading-relaxed">
              ادخل إلى لوحة تحكم Shopify الخاصة بك، ثم اذهب إلى <strong>Settings</strong> ➔ <strong>Notifications</strong> وانزل إلى أسفل الصفحة حتى تجد قسم <strong>Webhooks</strong>.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/30">
            <span className="font-bold text-purple-400 block mb-1">2. إنشاء Webhook جديد</span>
            <p className="leading-relaxed">
              اضغط على <strong>Create webhook</strong> واختر الحدث (Event): <strong>Order creation</strong> والتنسيق: <strong>JSON</strong>.
            </p>
          </div>
          <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/30">
            <span className="font-bold text-purple-400 block mb-1">3. لصق الرابط والحفظ</span>
            <p className="leading-relaxed">
              الصق رابط الـ Webhook الموضح أعلاه في خانة <strong>URL</strong> واضغط <strong>Save</strong>. ستبدأ جميع طلبات COD بالوصول تلقائياً!
            </p>
          </div>
        </div>
      </div>

      {/* Add Store Modal */}
      {isAddStoreModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#100a26] border border-purple-800/60 shadow-2xl p-6 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-4">
              <h2 className="text-base font-bold text-white">إضافة متجر إلكتروني جديد</h2>
              <button
                onClick={() => setIsAddStoreModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateStore} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">اسم المتجر *</label>
                <input
                  type="text"
                  required
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="مثال: متجر الموضة المغربية"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">رابط النطاق (Domain) *</label>
                <input
                  type="text"
                  required
                  value={storeDomain}
                  onChange={(e) => setStoreDomain(e.target.value)}
                  placeholder="mystore.ma أو mystore.myshopify.com"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">منصة المتجر</label>
                <select
                  value={storePlatform}
                  onChange={(e) => setStorePlatform(e.target.value as PlatformType)}
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="SHOPIFY">Shopify</option>
                  <option value="WOOCOMMERCE">WooCommerce (WordPress)</option>
                  <option value="YOUCAN">YouCan</option>
                  <option value="CUSTOM_API">Custom Store / REST API</option>
                </select>
              </div>

              <div className="pt-3 border-t border-purple-900/40 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddStoreModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-purple-950 hover:bg-purple-900 text-slate-300 text-xs font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-purple-600/30"
                >
                  {isSubmitting ? 'جاري الإضافة...' : 'إضافة المتجر'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
