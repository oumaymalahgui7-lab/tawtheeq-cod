import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import { supabase, getArabicAuthErrorMessage } from '../../lib/supabase';
import { 
  X, 
  Mail, 
  Lock, 
  User as UserIcon, 
  Phone, 
  Store, 
  Loader2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { 
    isAuthModalOpen, 
    setIsAuthModalOpen, 
    authMode, 
    setAuthMode, 
    setActiveTab, 
    showToast, 
  } = useApp();

  const [name, setName] = useState('');
  const [storeName, setStoreName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotEmail, setForgotEmail] = useState('');
  const [error, setError] = useState('');
  const [successNotice, setSuccessNotice] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAuthModalOpen) return null;

  const resetMessages = () => {
    setError('');
    setSuccessNotice('');
  };

  const handleSwitchMode = (mode: 'login' | 'signup' | 'forgot') => {
    resetMessages();
    setAuthMode(mode);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!email.trim() || !password) {
      setError('يرجى إدخال البريد الإلكتروني وكلمة المرور');
      return;
    }

    setIsSubmitting(true);
    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (signInError) {
        setError(getArabicAuthErrorMessage(signInError));
        return;
      }

      if (data?.user) {
        setIsAuthModalOpen(false);
        setActiveTab('dashboard');
        showToast('تم تسجيل الدخول بنجاح! مرحباً بك في توثيق COD', 'success');
      }
    } catch (err: any) {
      setError(getArabicAuthErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!name.trim() || !storeName.trim() || !email.trim() || !phone.trim() || !password) {
      setError('جميع الحقول مطلوبة لإنشاء الحساب');
      return;
    }

    if (password.length < 8) {
      setError('يجب أن تتكون كلمة المرور من 8 أحرف على الأقل');
      return;
    }

    if (password !== confirmPassword) {
      setError('كلمتا المرور غير متطابقتين');
      return;
    }

    setIsSubmitting(true);
    try {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: {
            full_name: name.trim(),
            phone: phone.trim(),
            store_name: storeName.trim(),
          },
        },
      });

      if (signUpError) {
        setError(getArabicAuthErrorMessage(signUpError));
        return;
      }

      if (data?.session) {
        setIsAuthModalOpen(false);
        setActiveTab('dashboard');
        showToast('تم إنشاء الحساب وتسجيل الدخول بنجاح! مرحباً بك 🚀', 'success');
      } else if (data?.user) {
        setSuccessNotice('تم إنشاء الحساب بنجاح! يرجى مراجعة بريدك الإلكتروني لتأكيد الحساب وتفعيله.');
        showToast('تم إنشاء الحساب بنجاح! تفقد بريدك الإلكتروني للتفعيل.', 'success');
        setAuthMode('login');
      }
    } catch (err: any) {
      setError(getArabicAuthErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!forgotEmail.trim()) {
      setError('يرجى إدخال البريد الإلكتروني لاستعادة كلمة المرور');
      return;
    }

    setIsSubmitting(true);
    try {
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(forgotEmail.trim(), {
        redirectTo: window.location.origin,
      });

      if (resetError) {
        setError(getArabicAuthErrorMessage(resetError));
        return;
      }

      setSuccessNotice('تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني، يرجى فحص صندوق الوارد.');
      showToast('تم إرسال رابط استعادة كلمة المرور بنجاح', 'success');
      setForgotEmail('');
    } catch (err: any) {
      setError(getArabicAuthErrorMessage(err));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="w-full max-w-md rounded-3xl bg-[#100a26] border border-purple-800/60 shadow-2xl p-6 sm:p-7 text-right relative">
        
        {/* Close Button */}
        <button
          onClick={() => {
            setIsAuthModalOpen(false);
            resetMessages();
          }}
          className="absolute top-5 left-5 p-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Title */}
        <div className="mb-6">
          <div className="mb-3">
            <BrandLogo size="lg" />
          </div>
          <h2 className="text-xl font-black text-white">
            {authMode === 'login' ? 'تسجيل الدخول إلى حسابك' : authMode === 'signup' ? 'إنشاء حساب تاجر جديد' : 'استعادة كلمة المرور'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {authMode === 'login' 
              ? 'أدخل بياناتك المسجلة للوصول إلى لوحة التحكم'
              : authMode === 'signup'
              ? 'أنشئ حسابك الحقيقي واربط متجرك بواتساب للبدء في تأكيد الطلبات'
              : 'أدخل بريدك الإلكتروني لإعادة تعيين كلمة المرور الخاصة بك'}
          </p>
        </div>

        {/* Error Banner */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/70 border border-rose-800/60 text-rose-300 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Success Notice Banner */}
        {successNotice && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-950/70 border border-emerald-800/60 text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* Login Form */}
        {authMode === 'login' && (
          <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">البريد الإلكتروني</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="contact@store.ma"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl pr-9 pl-3 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
                <Mail className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">كلمة المرور</label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl pr-9 pl-3 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
                <Lock className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
              </div>
            </div>

            <div className="flex items-center justify-end text-[11px] pt-1">
              <button
                type="button"
                onClick={() => handleSwitchMode('forgot')}
                className="text-purple-400 hover:text-purple-300 font-semibold cursor-pointer"
              >
                نسيت كلمة المرور؟
              </button>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-lg shadow-purple-600/30 transition-all cursor-pointer mt-2 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جاري تسجيل الدخول...</span>
                </>
              ) : (
                <span>تسجيل الدخول</span>
              )}
            </button>
          </form>
        )}

        {/* Sign Up Form */}
        {authMode === 'signup' && (
          <form onSubmit={handleSignUp} className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">الاسم الكامل *</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="ياسين العلمي"
                    className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl pr-8 pl-2.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                  <UserIcon className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-2.5" />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم المتجر *</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={storeName}
                    onChange={(e) => setStoreName(e.target.value)}
                    placeholder="متجري الإلكتروني"
                    className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl pr-8 pl-2.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                  <Store className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-2.5" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">البريد الإلكتروني *</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="contact@store.ma"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl pr-9 pl-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
                <Mail className="w-4 h-4 text-slate-500 absolute right-3 top-2.5" />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">رقم هاتف واتساب *</label>
              <div className="relative">
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+2126XXXXXXXX"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl pr-9 pl-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 font-mono"
                />
                <Phone className="w-4 h-4 text-slate-500 absolute right-3 top-2.5" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">كلمة المرور (8 أحرف+) *</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="8 أحرف على الأقل"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">تأكيد كلمة المرور *</label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white rounded-xl font-bold shadow-lg shadow-purple-600/30 transition-all cursor-pointer mt-2 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جاري إنشاء الحساب...</span>
                </>
              ) : (
                <span>إنشاء الحساب والمتابعة ➔</span>
              )}
            </button>
          </form>
        )}

        {/* Forgot Password */}
        {authMode === 'forgot' && (
          <form onSubmit={handleForgotPassword} className="space-y-4 text-xs">
            <p className="text-slate-300 leading-relaxed">
              أدخل بريدك الإلكتروني المسجل، وسنرسل لك رابط إعادة تعيين كلمة المرور فوراً:
            </p>
            <div className="relative">
              <input
                type="email"
                required
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="contact@store.ma"
                className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl pr-9 pl-3 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
              <Mail className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-xl font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>جاري إرسال الرابط...</span>
                </>
              ) : (
                <span>إرسال رابط استعادة كلمة المرور</span>
              )}
            </button>
            <button
              type="button"
              onClick={() => handleSwitchMode('login')}
              className="w-full text-center text-purple-400 hover:text-purple-300 py-1 font-semibold cursor-pointer"
            >
              العودة إلى تسجيل الدخول
            </button>
          </form>
        )}

        {/* Switch modes */}
        <div className="mt-5 pt-4 border-t border-purple-900/40 text-center text-xs text-slate-400">
          {authMode === 'login' ? (
            <p>
              ليس لديك حساب بعد؟{' '}
              <button
                type="button"
                onClick={() => handleSwitchMode('signup')}
                className="text-purple-400 hover:text-purple-300 font-bold cursor-pointer"
              >
                أنشئ حسابك مجاناً
              </button>
            </p>
          ) : authMode === 'signup' ? (
            <p>
              لديك حساب بالفعل؟{' '}
              <button
                type="button"
                onClick={() => handleSwitchMode('login')}
                className="text-purple-400 hover:text-purple-300 font-bold cursor-pointer"
              >
                تسجيل الدخول
              </button>
            </p>
          ) : null}
        </div>

      </div>
    </div>
  );
};
