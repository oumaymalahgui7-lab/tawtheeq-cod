import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BrandLogo } from '../common/BrandLogo';
import { 
  Bell, 
  Store as StoreIcon, 
  Globe, 
  ChevronDown, 
  User as UserIcon, 
  CheckCircle2, 
  AlertCircle, 
  Shield, 
  Menu, 
  X,
  Sparkles,
  ArrowRight,
  LogOut,
  HelpCircle,
  Smartphone
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    user, 
    setUser,
    logout,
    language, 
    setLanguage, 
    activeTab, 
    setActiveTab, 
    stores, 
    activeStore, 
    setActiveStore, 
    notifications, 
    unreadNotificationsCount, 
    markNotificationsAsRead, 
    setSelectedOrderId,
    setIsAuthModalOpen, 
    setAuthMode,
    t, 
    dir 
  } = useApp();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isStoreOpen, setIsStoreOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-purple-900/30 bg-[#090614]/90 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setActiveTab('landing')}
            className="flex items-center text-left focus:outline-none group cursor-pointer"
          >
            <BrandLogo size="md" />
          </button>

          {/* Store Switcher for authenticated merchant */}
          {user && stores.length > 0 && activeTab !== 'landing' && (
            <div className="relative hidden md:block">
              <button
                onClick={() => setIsStoreOpen(!isStoreOpen)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-300 bg-purple-950/40 hover:bg-purple-900/40 border border-purple-800/40 rounded-lg transition-colors"
              >
                <StoreIcon className="w-3.5 h-3.5 text-purple-400" />
                <span className="truncate max-w-[140px]">{activeStore?.name || 'اختر المتجر'}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              {isStoreOpen && (
                <div className={`absolute top-full mt-2 w-56 rounded-xl bg-[#140e2b] border border-purple-800/50 shadow-2xl p-1.5 z-50 ${dir === 'rtl' ? 'right-0' : 'left-0'}`}>
                  <div className="px-3 py-1 text-[11px] font-semibold text-purple-300 uppercase tracking-wider">
                    {language === 'ar' ? 'متاجرك المتصلة' : 'Vos Boutiques'}
                  </div>
                  {stores.map(s => (
                    <button
                      key={s.id}
                      onClick={() => {
                        setActiveStore(s);
                        setIsStoreOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-colors text-right ${activeStore?.id === s.id ? 'bg-purple-600 text-white font-medium' : 'text-slate-300 hover:bg-purple-900/50'}`}
                    >
                      <span className="truncate">{s.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/30 text-purple-200 uppercase">{s.platform}</span>
                    </button>
                  ))}
                  <div className="border-t border-purple-900/40 mt-1 pt-1">
                    <button
                      onClick={() => {
                        setActiveTab('stores');
                        setIsStoreOpen(false);
                      }}
                      className="w-full text-center px-3 py-1.5 text-xs text-purple-300 hover:text-white font-medium hover:bg-purple-900/40 rounded-lg transition-colors"
                    >
                      {language === 'ar' ? '+ إضافة متجر جديد' : '+ Ajouter une boutique'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Zone 2: Navigation Links (Clean text with hover effects) */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-300">
          {activeTab === 'landing' ? (
            <>
              <button 
                onClick={() => {
                  const el = document.getElementById('how-it-works');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="hover:text-purple-300 transition-colors whitespace-nowrap"
              >
                {language === 'ar' ? 'طريقة العمل' : language === 'fr' ? 'Comment ça marche' : 'How it works'}
              </button>
              <button 
                onClick={() => {
                  const el = document.getElementById('features');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="hover:text-purple-300 transition-colors whitespace-nowrap"
              >
                {language === 'ar' ? 'المميزات' : language === 'fr' ? 'Fonctionnalités' : 'Features'}
              </button>
              <button 
                onClick={() => {
                  const el = document.getElementById('interactive-demo');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="hover:text-purple-300 transition-colors whitespace-nowrap flex items-center gap-1.5 text-purple-300"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
                {language === 'ar' ? 'المحاكي التفاعلي' : language === 'fr' ? 'Simulateur' : 'Live Simulator'}
              </button>
              <button 
                onClick={() => {
                  const el = document.getElementById('pricing');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="hover:text-purple-300 transition-colors whitespace-nowrap"
              >
                {language === 'ar' ? 'الأسعار' : language === 'fr' ? 'Tarifs' : 'Pricing'}
              </button>
              <button 
                onClick={() => {
                  const el = document.getElementById('faq');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }} 
                className="hover:text-purple-300 transition-colors whitespace-nowrap"
              >
                {language === 'ar' ? 'الأسئلة الشائعة' : language === 'fr' ? 'FAQ' : 'FAQ'}
              </button>
            </>
          ) : (
            <>
              <button 
                onClick={() => setActiveTab('dashboard')} 
                className={`transition-colors whitespace-nowrap ${activeTab === 'dashboard' ? 'text-purple-400 font-semibold' : 'hover:text-white'}`}
              >
                {t('navDashboard')}
              </button>
              <button 
                onClick={() => setActiveTab('orders')} 
                className={`transition-colors whitespace-nowrap ${activeTab === 'orders' ? 'text-purple-400 font-semibold' : 'hover:text-white'}`}
              >
                {t('navOrders')}
              </button>
              <button 
                onClick={() => setActiveTab('whatsapp')} 
                className={`transition-colors whitespace-nowrap ${activeTab === 'whatsapp' ? 'text-purple-400 font-semibold' : 'hover:text-white'}`}
              >
                {t('navWhatsApp')}
              </button>
              <button 
                onClick={() => setActiveTab('customers')} 
                className={`transition-colors whitespace-nowrap ${activeTab === 'customers' ? 'text-purple-400 font-semibold' : 'hover:text-white'}`}
              >
                {t('navCustomers')}
              </button>
              <button 
                onClick={() => setActiveTab('billing')} 
                className={`transition-colors whitespace-nowrap ${activeTab === 'billing' ? 'text-purple-400 font-semibold' : 'hover:text-white'}`}
              >
                {t('navBilling')}
              </button>
            </>
          )}
        </nav>

        {/* Zone 3: Primary Actions, Language Switcher, User Dropdown */}
        <div className="flex items-center gap-3">
          
          {/* Language Switcher */}
          <div className="relative">
            <button
              onClick={() => {
                if (language === 'ar') setLanguage('fr');
                else if (language === 'fr') setLanguage('en');
                else setLanguage('ar');
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-purple-950/40 hover:bg-purple-900/50 border border-purple-800/40 rounded-lg transition-colors"
              title="تغيير اللغة / Changer de langue"
            >
              <Globe className="w-3.5 h-3.5 text-purple-400" />
              <span>{language === 'ar' ? 'العربية' : language === 'fr' ? 'Français' : 'English'}</span>
            </button>
          </div>

          {/* Notifications Dropdown (for authenticated user) */}
          {user && (
            <div className="relative">
              <button
                onClick={() => {
                  setIsNotifOpen(!isNotifOpen);
                  if (!isNotifOpen) markNotificationsAsRead();
                }}
                className="relative p-2 text-slate-300 hover:text-white bg-purple-950/40 hover:bg-purple-900/50 border border-purple-800/40 rounded-lg transition-colors"
              >
                <Bell className="w-4 h-4 text-purple-300" />
                {unreadNotificationsCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-pink-500 text-[9px] font-bold text-white shadow-lg shadow-pink-500/50 animate-pulse">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>

              {isNotifOpen && (
                <div className={`absolute top-full mt-2 w-80 rounded-2xl bg-[#140e2b] border border-purple-800/60 shadow-2xl p-3 z-50 ${dir === 'rtl' ? 'left-0 sm:right-0 sm:left-auto' : 'right-0'}`}>
                  <div className="flex items-center justify-between pb-2 border-b border-purple-900/40 mb-2">
                    <span className="text-xs font-bold text-white">
                      {language === 'ar' ? 'التنبيهات والإشعارات' : 'Notifications'}
                    </span>
                    <span className="text-[11px] text-purple-400 font-mono">
                      {notifications.length}
                    </span>
                  </div>
                  <div className="max-h-72 overflow-y-auto space-y-2">
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-400 text-center py-4">لا توجد إشعارات جديدة</p>
                    ) : (
                      notifications.map(n => (
                        <div 
                          key={n.id}
                          onClick={() => {
                            if (n.orderId) {
                              setSelectedOrderId(n.orderId);
                              setActiveTab('orders');
                            }
                            setIsNotifOpen(false);
                          }}
                          className="p-2.5 rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-800/30 cursor-pointer transition-colors text-right"
                        >
                          <div className="flex items-start gap-2">
                            {n.type === 'ORDER_CONFIRMED' ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                            ) : n.type === 'QUESTION' ? (
                              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                            ) : (
                              <Sparkles className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-semibold text-white truncate">{n.title}</p>
                              <p className="text-[11px] text-slate-300 line-clamp-2 mt-0.5">{n.message}</p>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* User Profile or Get Started CTA */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setIsProfileOpen(!isProfileOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 bg-gradient-to-r from-purple-900/60 to-indigo-900/60 hover:from-purple-800/70 hover:to-indigo-800/70 border border-purple-700/50 rounded-xl transition-all shadow-md shadow-purple-900/30"
              >
                <div className="w-6 h-6 rounded-full bg-purple-500/30 flex items-center justify-center border border-purple-400/50 text-white font-bold text-xs">
                  {user.name.charAt(0)}
                </div>
                <div className="hidden sm:flex flex-col text-right">
                  <span className="text-xs font-bold text-white truncate max-w-[100px]">{user.name}</span>
                  <span className="text-[10px] text-purple-300 font-mono">
                    {user.credits} DH
                  </span>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-300 hidden sm:block" />
              </button>

              {isProfileOpen && (
                <div className={`absolute top-full mt-2 w-64 rounded-2xl bg-[#140e2b] border border-purple-800/60 shadow-2xl p-2 z-50 ${dir === 'rtl' ? 'left-0' : 'right-0'}`}>
                  <div className="p-3 border-b border-purple-900/40 text-right">
                    <p className="text-xs font-bold text-white">{user.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                    <div className="mt-2 flex items-center justify-between text-xs bg-purple-950/60 p-2 rounded-lg border border-purple-800/40">
                      <span className="text-slate-300">{t('availableCredits')}:</span>
                      <span className="font-bold text-emerald-400 font-mono">{user.credits} DH</span>
                    </div>
                  </div>

                  <div className="py-1">
                    {user.role === 'ADMIN' && (
                      <button
                        onClick={() => {
                          setActiveTab('admin');
                          setIsProfileOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs text-purple-300 hover:text-white hover:bg-purple-900/40 rounded-xl transition-colors text-right"
                      >
                        <Shield className="w-3.5 h-3.5 text-purple-400" />
                        <span>{t('navAdmin')}</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setActiveTab('dashboard');
                        setIsProfileOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-purple-900/40 rounded-xl transition-colors text-right"
                    >
                      <StoreIcon className="w-3.5 h-3.5 text-purple-400" />
                      {t('navDashboard')}
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('billing');
                        setIsProfileOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-purple-900/40 rounded-xl transition-colors text-right"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      {t('navBilling')}
                    </button>

                    <button
                      onClick={() => {
                        setActiveTab('docs');
                        setIsProfileOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-purple-900/40 rounded-xl transition-colors text-right"
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-sky-400" />
                      {t('navDocs')}
                    </button>

                    <div className="border-t border-purple-900/40 my-1"></div>

                    <button
                      onClick={() => {
                        setIsProfileOpen(false);
                        logout();
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-400 hover:bg-rose-950/40 rounded-xl transition-colors text-right cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      {t('logout')}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setAuthMode('login');
                  setIsAuthModalOpen(true);
                }}
                className="px-3.5 py-2 text-xs font-semibold text-slate-200 hover:text-white transition-colors"
              >
                {t('login')}
              </button>
              <button
                onClick={() => {
                  setAuthMode('signup');
                  setIsAuthModalOpen(true);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-xl shadow-lg shadow-purple-600/30 hover:shadow-purple-600/50 hover:scale-[1.02] active:scale-95 transition-all whitespace-nowrap"
              >
                {t('startNow')}
              </button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 text-slate-300 hover:text-white hover:bg-purple-900/40 rounded-lg transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#110b24] border-b border-purple-900/50 px-4 pt-3 pb-5 space-y-2">
          {activeTab === 'landing' ? (
            <>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full text-right py-2 text-sm text-slate-300 hover:text-white"
              >
                {language === 'ar' ? 'طريقة العمل' : 'Comment ça marche'}
              </button>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full text-right py-2 text-sm text-slate-300 hover:text-white"
              >
                {language === 'ar' ? 'المميزات' : 'Fonctionnalités'}
              </button>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  document.getElementById('interactive-demo')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full text-right py-2 text-sm text-purple-400 font-semibold"
              >
                {language === 'ar' ? 'المحاكي التفاعلي' : 'Simulateur'}
              </button>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full text-right py-2 text-sm text-slate-300 hover:text-white"
              >
                {language === 'ar' ? 'الأسعار والخطط' : 'Tarifs'}
              </button>
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  document.getElementById('faq')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full text-right py-2 text-sm text-slate-300 hover:text-white"
              >
                {language === 'ar' ? 'الأسئلة الشائعة' : 'FAQ'}
              </button>
              <div className="pt-2 border-t border-purple-900/40 flex gap-2">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setAuthMode('login');
                    setIsAuthModalOpen(true);
                  }}
                  className="w-1/2 py-2.5 text-xs font-semibold text-center text-slate-200 bg-purple-950/60 rounded-xl"
                >
                  {t('login')}
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setAuthMode('signup');
                    setIsAuthModalOpen(true);
                  }}
                  className="w-1/2 py-2.5 text-xs font-bold text-center text-white bg-purple-600 rounded-xl"
                >
                  {t('startNow')}
                </button>
              </div>
            </>
          ) : (
            <>
              <button
                onClick={() => {
                  setActiveTab('dashboard');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 text-sm text-slate-200"
              >
                {t('navDashboard')}
              </button>
              <button
                onClick={() => {
                  setActiveTab('orders');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 text-sm text-slate-200"
              >
                {t('navOrders')}
              </button>
              <button
                onClick={() => {
                  setActiveTab('whatsapp');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 text-sm text-purple-400 font-medium"
              >
                {t('navWhatsApp')}
              </button>
              <button
                onClick={() => {
                  setActiveTab('customers');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 text-sm text-slate-200"
              >
                {t('navCustomers')}
              </button>
              <button
                onClick={() => {
                  setActiveTab('stores');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 text-sm text-slate-200"
              >
                {t('navStores')}
              </button>
              <button
                onClick={() => {
                  setActiveTab('billing');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 text-sm text-slate-200"
              >
                {t('navBilling')}
              </button>
            </>
          )}
        </div>
      )}
    </header>
  );
};
