import React from 'react';
import { useApp, ActiveTab } from '../../context/AppContext';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  Users, 
  Store, 
  Bot, 
  FileText, 
  BarChart3, 
  CreditCard, 
  ShieldAlert, 
  Settings, 
  HelpCircle, 
  PlusCircle, 
  Zap, 
  Download, 
  Smartphone,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, user, t, dir, language, showToast } = useApp();

  const navItems: Array<{ id: ActiveTab; label: string; icon: any; badge?: string; adminOnly?: boolean }> = [
    { id: 'dashboard', label: t('navDashboard'), icon: LayoutDashboard },
    { id: 'orders', label: t('navOrders'), icon: ShoppingBag },
    { id: 'whatsapp', label: t('navWhatsApp'), icon: Bot, badge: 'AI' },
    { id: 'templates', label: t('navTemplates'), icon: FileText },
    { id: 'customers', label: t('navCustomers'), icon: Users },
    { id: 'stores', label: t('navStores'), icon: Store },
    { id: 'analytics', label: t('navAnalytics'), icon: BarChart3 },
    { id: 'billing', label: t('navBilling'), icon: CreditCard },
    { id: 'admin', label: t('navAdmin'), icon: ShieldAlert, adminOnly: true },
    { id: 'settings', label: t('navSettings'), icon: Settings },
    { id: 'docs', label: t('navDocs'), icon: HelpCircle },
  ];

  return (
    <aside className="w-64 bg-[#0d081f] border-r border-purple-900/30 min-h-[calc(100vh-4rem)] p-3.5 flex flex-col justify-between shrink-0 hidden md:flex">
      
      {/* Navigation Links */}
      <div className="space-y-1">
        
        {/* Quick New Order Action */}
        <button
          onClick={() => setActiveTab('orders')}
          className="w-full mb-3 py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{t('newOrder')}</span>
        </button>

        <div className="space-y-0.5">
          {navItems.map((item) => {
            if (item.adminOnly && user?.role !== 'ADMIN') return null;
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-purple-900/30'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-purple-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                    isActive ? 'bg-black/30 text-white' : 'bg-purple-950 text-purple-300 border border-purple-700/50'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Credits Widget & PWA */}
      <div className="space-y-2 pt-3 border-t border-purple-900/30">
        
        {/* Credits Card */}
        <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 text-right">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] text-slate-300">{t('availableCredits')}</span>
            <Zap className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-lg font-black text-amber-300 font-mono">
              {user?.credits ?? 0} <span className="text-xs font-normal">DH</span>
            </span>
            <button
              onClick={() => setActiveTab('billing')}
              className="text-[11px] text-purple-400 hover:text-purple-300 font-bold underline cursor-pointer"
            >
              شحن الرصيد
            </button>
          </div>
        </div>

        {/* PWA Badge / Trigger */}
        <button
          onClick={() => {
            showToast(language === 'ar' ? 'لتثبيت التطبيق: اضغط على خيارات المتصفح (⋮) ثم اختر "إضافة إلى الشاشة الرئيسية".' : "Pour installer : menu du navigateur -> 'Ajouter à l'écran d'accueil'.", 'info');
          }}
          className="w-full flex items-center justify-center gap-2 py-2 px-2.5 rounded-xl bg-[#140e2b] hover:bg-purple-900/40 border border-purple-800/30 text-[11px] text-purple-300 hover:text-white transition-colors"
        >
          <Smartphone className="w-3.5 h-3.5 text-purple-400" />
          <span>{t('installPwa')}</span>
        </button>

      </div>

    </aside>
  );
};
