import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Customer } from '../../types';
import { 
  Users, 
  Search, 
  Phone, 
  MapPin, 
  ShoppingBag, 
  CheckCircle2, 
  XCircle, 
  Truck, 
  Sparkles, 
  MessageCircle,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  UserCheck
} from 'lucide-react';

export const CustomersView: React.FC = () => {
  const { t, showToast } = useApp();

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const loadCustomers = async () => {
    try {
      setLoading(true);
      const res = await api.getCustomers(search);
      setCustomers(res.customers || []);
    } catch (e) {
      console.error(e);
      showToast('تعذر تحميل بيانات العملاء', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadCustomers();
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>سجل العملاء وإدارة الزبائن (CRM)</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
              {customers.length} عميل
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            ملفات الزبائن، سجل المشتريات، وتاريخ الطلبات لإدارتها ومتابعتها بسهولة.
          </p>
        </div>

        {/* Search */}
        <form onSubmit={handleSearchSubmit} className="sm:w-72 relative">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالاسم، الهاتف، أو المدينة..."
            className="w-full bg-purple-950/50 border border-purple-800/40 rounded-xl pr-10 pl-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-2.5 pointer-events-none" />
        </form>
      </div>

      {/* Customers Table */}
      <div className="glass-panel rounded-2xl border border-purple-800/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-purple-900/40 bg-purple-950/40 text-slate-400 font-semibold">
                <th className="py-3.5 pr-4">العميل</th>
                <th className="py-3.5">الهاتف والمدينة</th>
                <th className="py-3.5 text-center">الطلبات الكلية</th>
                <th className="py-3.5 text-center">مؤكدة</th>
                <th className="py-3.5 text-center">ملغاة</th>
                <th className="py-3.5 text-center">مسلمة</th>
                <th className="py-3.5">إجمالي المشتريات</th>
                <th className="py-3.5">آخر طلب</th>
                <th className="py-3.5 pl-4 text-center">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-900/20">
              {loading ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Sparkles className="w-6 h-6 text-purple-400 animate-spin mx-auto mb-2" />
                    جاري تحميل سجل العملاء...
                  </td>
                </tr>
              ) : customers.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    لا يوجد عملاء يطابقون البحث
                  </td>
                </tr>
              ) : (
                customers.map((cust) => (
                  <tr
                    key={cust.id}
                    onClick={() => setSelectedCustomer(cust)}
                    className="hover:bg-purple-950/30 transition-colors group cursor-pointer"
                  >
                    <td className="py-3.5 pr-4">
                      <div className="font-bold text-white flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-purple-900/60 border border-purple-700/50 flex items-center justify-center text-purple-200 text-xs">
                          {cust.name.charAt(0)}
                        </div>
                        <span>{cust.name}</span>
                      </div>
                    </td>

                    <td className="py-3.5">
                      <div className="font-mono text-purple-300">{cust.phone}</div>
                      <div className="text-[11px] text-slate-400">{cust.city}</div>
                    </td>

                    <td className="py-3.5 text-center font-bold text-white font-mono">
                      {cust.totalOrders}
                    </td>

                    <td className="py-3.5 text-center font-bold text-emerald-400 font-mono">
                      {cust.confirmedOrders}
                    </td>

                    <td className="py-3.5 text-center font-bold text-rose-400 font-mono">
                      {cust.cancelledOrders}
                    </td>

                    <td className="py-3.5 text-center font-bold text-sky-400 font-mono">
                      {cust.deliveredOrders}
                    </td>

                    <td className="py-3.5 font-bold text-emerald-300 font-mono tabular-nums">
                      {cust.totalSpent.toLocaleString()} DH
                    </td>

                    <td className="py-3.5 font-mono text-slate-400 text-[11px]">
                      {new Date(cust.lastOrderAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                    </td>

                    <td className="py-3.5 pl-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedCustomer(cust);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-purple-900/40 hover:bg-purple-800 text-purple-200 text-xs transition-colors"
                      >
                        الملف
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Profile Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-3xl bg-[#100a26] border border-purple-800/60 shadow-2xl p-6 text-right">
            
            <div className="flex items-center justify-between pb-4 border-b border-purple-900/40 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-600 flex items-center justify-center text-white font-black text-sm">
                  {selectedCustomer.name.charAt(0)}
                </div>
                <div>
                  <h2 className="text-base font-bold text-white">{selectedCustomer.name}</h2>
                  <p className="text-xs text-purple-300 font-mono">{selectedCustomer.phone}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-1.5 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              
              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-800/40">
                  <span className="text-[10px] text-slate-400">إجمالي الطلبات</span>
                  <p className="text-lg font-black text-white font-mono mt-0.5">{selectedCustomer.totalOrders}</p>
                </div>
                <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-800/40">
                  <span className="text-[10px] text-emerald-400">مؤكدة ومسلمة</span>
                  <p className="text-lg font-black text-emerald-400 font-mono mt-0.5">{selectedCustomer.confirmedOrders + selectedCustomer.deliveredOrders}</p>
                </div>
                <div className="p-3 rounded-xl bg-purple-950/50 border border-purple-800/40">
                  <span className="text-[10px] text-slate-400">المبيعات الإجمالية</span>
                  <p className="text-lg font-black text-emerald-300 font-mono mt-0.5">{selectedCustomer.totalSpent} DH</p>
                </div>
              </div>

              {/* Details Box */}
              <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/40 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">المدينة:</span>
                  <span className="text-white font-semibold">{selectedCustomer.city}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">العنوان:</span>
                  <span className="text-slate-200">{selectedCustomer.address}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">أول طلب:</span>
                  <span className="font-mono text-slate-300">{new Date(selectedCustomer.firstOrderAt).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">آخر طلب:</span>
                  <span className="font-mono text-slate-300">{new Date(selectedCustomer.lastOrderAt).toLocaleDateString()}</span>
                </div>
              </div>

              {/* WhatsApp Direct Action */}
              <a
                href={`https://wa.me/${selectedCustomer.phone.replace('+', '')}`}
                target="_blank"
                rel="noreferrer"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>محادثة العميل عبر واتساب</span>
              </a>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
