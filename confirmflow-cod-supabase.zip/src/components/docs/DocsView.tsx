import React, { useState } from 'react';
import { 
  HelpCircle, 
  Code, 
  Terminal, 
  Server, 
  Bot, 
  ShieldCheck, 
  Copy, 
  Check, 
  ExternalLink,
  BookOpen,
  Cpu
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const DocsView: React.FC = () => {
  const { showToast } = useApp();
  const [activeDocSection, setActiveDocSection] = useState<'quickstart' | 'whatsapp' | 'webhooks' | 'env' | 'deploy'>('quickstart');

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    showToast('تم نسخ الكود البرمجي', 'success');
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-purple-400" />
            <span>دليل التشغيل والتوثيق البرمجي (Documentation)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            دليل إعداد بيئة العمل، ربط WhatsApp Cloud API، إعداد Webhooks شوبيفاي ووكومرس، والنشر Production.
          </p>
        </div>
      </div>

      {/* Docs Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 text-xs border-b border-purple-900/30">
        {[
          { id: 'quickstart', label: 'بدء التشغيل السريع' },
          { id: 'whatsapp', label: 'ربط WhatsApp Cloud API' },
          { id: 'webhooks', label: 'إعداد Webhooks شوبيفاي ووكومرس' },
          { id: 'env', label: 'المتغيرات (Environment Variables)' },
          { id: 'deploy', label: 'النشر الإنتاجي (Production)' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveDocSection(tab.id as any)}
            className={`px-4 py-2 rounded-xl font-bold whitespace-nowrap transition-all ${
              activeDocSection === tab.id
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-purple-950/40 text-slate-300 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content based on tab */}
      {activeDocSection === 'quickstart' && (
        <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4 text-xs text-slate-300 leading-relaxed">
          <h2 className="text-base font-bold text-white">طريقة تشغيل المشروع محلياً أو على الخادم</h2>
          <p>
            تطبيق <strong>توثيق COD</strong> مبني كـ Full-Stack SaaS عصري يجمع بين خادم <strong>Node.js / Express</strong> مع محرك الذكاء الاصطناعي <strong>@google/genai</strong> وواجهة <strong>React 19 / Tailwind CSS</strong> فائقة السرعة مع دعم كامل لـ RTL و PWA.
          </p>

          <div className="p-4 rounded-xl bg-black/60 border border-purple-900/60 font-mono text-[11px] text-purple-200 space-y-2 relative">
            <button
              onClick={() => copyCode(`npm install\nnpm run dev`)}
              className="absolute top-3 left-3 p-1.5 bg-purple-900/40 hover:bg-purple-800 text-slate-300 rounded-lg"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
            <p className="text-slate-500"># 1. تثبيت الحزم والمكتبات</p>
            <p>npm install</p>
            <p className="text-slate-500 mt-2"># 2. تشغيل السيرفر الموحد (Express + Vite)</p>
            <p>npm run dev</p>
          </div>

          <p>
            سيعمل التطبيق مباشرة على المنفذ <strong>http://localhost:3000</strong> مع مسارات الـ API التلقائية.
          </p>
        </div>
      )}

      {activeDocSection === 'whatsapp' && (
        <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4 text-xs text-slate-300 leading-relaxed">
          <h2 className="text-base font-bold text-white">طريقة ربط WhatsApp Cloud API الرسمي من Meta</h2>
          <ol className="list-decimal list-inside space-y-3 pr-2">
            <li>
              أنشئ حساباً على <strong>Meta for Developers</strong> (<a href="https://developers.facebook.com" target="_blank" className="text-purple-400 underline">developers.facebook.com</a>).
            </li>
            <li>
              أنشئ تطبيقاً من نوع <strong>Business</strong> ثم أضف منتج <strong>WhatsApp</strong>.
            </li>
            <li>
              في لوحة WhatsApp ➔ Getting Started، ستجد:
              <ul className="list-disc list-inside mr-4 mt-1 space-y-1 text-slate-400">
                <li><strong>Phone Number ID</strong> (معرف رقم الهاتف)</li>
                <li><strong>WhatsApp Business Account ID</strong> (معرف حساب واتساب للأعمال)</li>
                <li><strong>Permanent Access Token</strong> (رمز الوصول الدائم)</li>
              </ul>
            </li>
            <li>
              ضع هذه القيم في صفحة <strong>أتمتة واتساب & AI</strong> داخل التطبيق.
            </li>
            <li>
              في إعدادات Webhook الخاصة بـ Meta، أدخل الرابط:
              <div className="my-2 p-2.5 rounded-lg bg-black/60 font-mono text-purple-300">
                https://your-domain.com/api/webhooks/whatsapp
              </div>
              واختر الاشتراك في أحداث <strong>messages</strong> لتستقبل ردود الزبائن في اللحظة نفسها!
            </li>
          </ol>
        </div>
      )}

      {activeDocSection === 'webhooks' && (
        <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4 text-xs text-slate-300 leading-relaxed">
          <h2 className="text-base font-bold text-white">طريقة ربط شوبيفاي ووكومرس عبر Webhooks</h2>
          <p>
            يدعم توثيق COD استقبال إشعارات إنشاء الطلبات تلقائياً عبر مسارات مؤمنة ومحمية من التكرار (Anti-duplicate verification):
          </p>

          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/40">
              <p className="font-bold text-white mb-1">منصة Shopify:</p>
              <p className="text-slate-400 mb-2">اذهب إلى Settings ➔ Notifications ➔ Webhooks ➔ Create Webhook</p>
              <p className="font-mono text-purple-300 bg-black/40 p-2 rounded">
                URL: https://your-domain.com/api/webhooks/shopify (Event: Order creation)
              </p>
            </div>

            <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-800/40">
              <p className="font-bold text-white mb-1">منصة WooCommerce:</p>
              <p className="text-slate-400 mb-2">اذهب إلى WooCommerce ➔ Settings ➔ Advanced ➔ Webhooks ➔ Add webhook</p>
              <p className="font-mono text-purple-300 bg-black/40 p-2 rounded">
                Delivery URL: https://your-domain.com/api/webhooks/woocommerce (Topic: Order created)
              </p>
            </div>
          </div>
        </div>
      )}

      {activeDocSection === 'env' && (
        <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4 text-xs text-slate-300 leading-relaxed">
          <h2 className="text-base font-bold text-white">ملف المتغيرات البيئية (.env)</h2>
          <p>
            قم بنسخ هذه المتغيرات في ملف <code className="text-purple-300">.env</code> على الخادم:
          </p>

          <div className="p-4 rounded-xl bg-black/60 border border-purple-900/60 font-mono text-[11px] text-purple-200 space-y-1 relative">
            <p>PORT=3000</p>
            <p>NODE_ENV=production</p>
            <p className="text-slate-500 mt-2"># Gemini AI API Key لتحليل الدارجة المغربية</p>
            <p>GEMINI_API_KEY="AIzaSy..."</p>
            <p className="text-slate-500 mt-2"># رابط النطاق الأساسي للتطبيق</p>
            <p>APP_URL="https://your-domain.com"</p>
          </div>
        </div>
      )}

      {activeDocSection === 'deploy' && (
        <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4 text-xs text-slate-300 leading-relaxed">
          <h2 className="text-base font-bold text-white">إرشادات النشر على خوادم الإنتاج (Production Deployment)</h2>
          <ol className="list-decimal list-inside space-y-2 pr-2">
            <li>قم ببناء الـ Frontend الإنتاجي: <code className="text-purple-300 font-mono">npm run build</code></li>
            <li>شغل الخادم الموحد: <code className="text-purple-300 font-mono">npm start</code> (يقوم بتشغيل node server.ts)</li>
            <li>يمكنك استخدام <strong>PM2</strong> أو <strong>Docker</strong> أو <strong>Google Cloud Run</strong> لتشغيل الخادم بدون توقف.</li>
            <li>اربط شهادة SSL (HTTPS) لضمان قبول Webhook من طرف Meta وشوبيفاي.</li>
          </ol>
        </div>
      )}

    </div>
  );
};
