import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Order, OrderStatus } from '../../types';
import { OrderDetailsModal } from './OrderDetailsModal';
import { 
  Search, 
  Filter, 
  Download, 
  Plus, 
  FileSpreadsheet, 
  FileText, 
  Printer, 
  MessageCircle, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Truck, 
  RotateCcw, 
  Bot, 
  ChevronLeft, 
  ChevronRight,
  Sparkles,
  ShoppingBag
} from 'lucide-react';

export const OrdersView: React.FC = () => {
  const { 
    t, 
    stores, 
    selectedOrderId, 
    setSelectedOrderId, 
    showToast, 
    dir 
  } = useApp();

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [storeFilter, setStoreFilter] = useState<string>('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // New Order Modal State
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newCustomerPhone, setNewCustomerPhone] = useState('');
  const [newCustomerCity, setNewCustomerCity] = useState('الدار البيضاء');
  const [newCustomerAddress, setNewCustomerAddress] = useState('');
  const [newProductName, setNewProductName] = useState('');
  const [newProductPrice, setNewProductPrice] = useState(350);
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const res = await api.getOrders({
        status: statusFilter,
        search: searchTerm,
        storeId: storeFilter,
        page: currentPage,
        limit: 15
      });
      setOrders(res.orders || []);
      if (res.pagination) {
        setTotalPages(res.pagination.totalPages || 1);
        setTotalCount(res.pagination.total || 0);
      }
    } catch (e) {
      console.error('Failed to load orders:', e);
      showToast('تعذر جلب الطلبات', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, [statusFilter, storeFilter, currentPage]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1);
    loadOrders();
  };

  const handleCreateManualOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerName || !newCustomerPhone || !newProductName) {
      showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
      return;
    }

    setIsSubmittingOrder(true);
    try {
      const res = await api.createOrder({
        customerName: newCustomerName,
        customerPhone: newCustomerPhone,
        customerCity: newCustomerCity,
        customerAddress: newCustomerAddress,
        items: [{ id: 'it_manual', name: newProductName, quantity: 1, price: newProductPrice }],
        totalPrice: newProductPrice,
        storeId: stores[0]?.id || 'store_1'
      });

      if (res.success) {
        showToast('تم إنشاء الطلب وإرسال رسالة واتساب للعميل بنجاح ✅', 'success');
        setIsNewOrderModalOpen(false);
        setNewCustomerName('');
        setNewCustomerPhone('');
        setNewCustomerAddress('');
        setNewProductName('');
        loadOrders();
      }
    } catch (err) {
      showToast('فشل إنشاء الطلب', 'error');
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  // Export CSV Handler
  const handleExportCSV = () => {
    if (orders.length === 0) return;
    const headers = ['Order Number,Customer Name,Phone,City,Address,Total Price (DH),Status,Source,Date'];
    const rows = orders.map(o => 
      `"${o.orderNumber}","${o.customerName}","${o.customerPhone}","${o.customerCity}","${o.customerAddress.replace(/"/g, '""')}","${o.totalPrice}","${o.status}","${o.source}","${o.createdAt}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Tawtheeq_COD_Orders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('تم تصدير ملف CSV بنجاح', 'success');
  };

  // Status Filter Tabs
  const statusTabs: Array<{ id: string; label: string; count?: number }> = [
    { id: 'ALL', label: 'جميع الطلبات' },
    { id: 'PENDING_CONFIRMATION', label: 'في انتظار التأكيد' },
    { id: 'CONFIRMED', label: 'مؤكدة ✅' },
    { id: 'NEEDS_REVIEW', label: 'تحتاج مراجعة ⚠️' },
    { id: 'CANCELLED', label: 'ملغاة ❌' },
    { id: 'SHIPPED', label: 'تم الشحن 🚚' },
    { id: 'DELIVERED', label: 'مسلمة 💰' },
    { id: 'RETURNED', label: 'مرتجعة' },
  ];

  return (
    <div className="space-y-6">
      
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>إدارة وتأكيد الطلبات (CRM)</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
              {totalCount} طلب
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            تابع ردود واتساب التلقائية، حدّث حالات الشحن، وصدّر البيانات لإدارتها بسهولة.
          </p>
        </div>

        {/* Buttons: Export & New Order */}
        <div className="flex flex-wrap items-center gap-2">
          
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-purple-950/60 hover:bg-purple-900/70 border border-purple-800/40 text-purple-200 hover:text-white rounded-xl text-xs font-semibold transition-all cursor-pointer"
            title="تصدير جدول الطلبات بتنسيق CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير CSV</span>
          </button>

          <button
            onClick={() => window.print()}
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-purple-950/60 hover:bg-purple-900/70 border border-purple-800/40 text-slate-300 hover:text-white rounded-xl text-xs font-semibold transition-all cursor-pointer"
            title="طباعة بوالص الشحن"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>طباعة البوالص</span>
          </button>

          <button
            onClick={() => setIsNewOrderModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-600/30 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t('newOrder')}</span>
          </button>

        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          
          {/* Search Form */}
          <form onSubmit={handleSearchSubmit} className="flex-1 relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث برقم الطلب (ORD-5991)، اسم العميل، الهاتف، أو المدينة..."
              className="w-full bg-purple-950/50 border border-purple-800/40 rounded-xl pr-10 pl-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors"
            />
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-2.5 pointer-events-none" />
          </form>

          {/* Store Filter */}
          <div className="sm:w-56">
            <select
              value={storeFilter}
              onChange={(e) => setStoreFilter(e.target.value)}
              className="w-full bg-purple-950/50 border border-purple-800/40 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
            >
              <option value="ALL">جميع المتاجر ({stores.length})</option>
              {stores.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.platform})</option>
              ))}
            </select>
          </div>

        </div>

        {/* Status Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs">
          {statusTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setStatusFilter(tab.id);
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors font-medium ${
                statusFilter === tab.id
                  ? 'bg-purple-600 text-white font-bold shadow-md shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-purple-900/30'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Orders Table */}
      <div className="glass-panel rounded-2xl border border-purple-800/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-purple-900/40 bg-purple-950/40 text-slate-400 font-semibold">
                <th className="py-3.5 pr-4">رقم الطلب</th>
                <th className="py-3.5">العميل والموقع</th>
                <th className="py-3.5">المنتجات</th>
                <th className="py-3.5">المبلغ (COD)</th>
                <th className="py-3.5">المصدر</th>
                <th className="py-3.5">حالة الطلب</th>
                <th className="py-3.5">واتساب AI</th>
                <th className="py-3.5">التاريخ</th>
                <th className="py-3.5 pl-4 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-900/20">
              {loading ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Sparkles className="w-6 h-6 text-purple-400 animate-spin mx-auto mb-2" />
                    جاري تحميل الطلبات...
                  </td>
                </tr>
              ) : orders.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    لا توجد طلبات تطابق الفلتر المختار
                  </td>
                </tr>
              ) : (
                orders.map((order) => (
                  <tr
                    key={order.id}
                    onClick={() => setSelectedOrderId(order.id)}
                    className="hover:bg-purple-950/40 transition-colors group cursor-pointer"
                  >
                    <td className="py-3.5 pr-4 font-mono font-bold text-purple-300">
                      {order.orderNumber}
                    </td>

                    <td className="py-3.5">
                      <div className="font-semibold text-white">{order.customerName}</div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <span className="font-mono text-purple-200">{order.customerPhone}</span>
                        <span>·</span>
                        <span>{order.customerCity}</span>
                      </div>
                    </td>

                    <td className="py-3.5 max-w-[180px] truncate text-slate-300">
                      {order.items.map(it => `${it.name} (x${it.quantity})`).join(', ')}
                    </td>

                    <td className="py-3.5 font-mono font-bold text-emerald-400 tabular-nums">
                      {order.totalPrice} DH
                    </td>

                    <td className="py-3.5">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-black/40 text-purple-200 font-mono">
                        {order.source}
                      </span>
                    </td>

                    <td className="py-3.5">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                        order.status === 'CONFIRMED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                          : order.status === 'CANCELLED'
                          ? 'bg-rose-950 text-rose-400 border border-rose-800/40'
                          : order.status === 'NEEDS_REVIEW'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800/40'
                          : order.status === 'SHIPPED'
                          ? 'bg-indigo-950 text-indigo-300 border border-indigo-800/40'
                          : order.status === 'DELIVERED'
                          ? 'bg-sky-950 text-sky-400 border border-sky-800/40'
                          : 'bg-purple-950 text-purple-300 border border-purple-800/40'
                      }`}>
                        {t(`status_${order.status}`)}
                      </span>
                    </td>

                    <td className="py-3.5 text-slate-300">
                      {order.messages.length > 1 ? (
                        <span className="text-[11px] text-purple-300 flex items-center gap-1 font-medium">
                          <Bot className="w-3.5 h-3.5 text-purple-400" />
                          رد العميل (AI)
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400">
                          مرسلة ({order.messages[0]?.status || 'SENT'})
                        </span>
                      )}
                    </td>

                    <td className="py-3.5 text-slate-400 font-mono text-[11px]">
                      {new Date(order.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </td>

                    <td className="py-3.5 pl-4 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedOrderId(order.id);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-purple-900/40 hover:bg-purple-800 text-purple-200 text-xs font-semibold transition-colors"
                      >
                        معاينة
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-purple-900/30 text-xs text-slate-400">
            <span>
              عرض الصفحة <strong className="text-white font-mono">{currentPage}</strong> من <strong className="text-white font-mono">{totalPages}</strong>
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg bg-purple-950/60 hover:bg-purple-900 disabled:opacity-40 text-slate-300"
              >
                {dir === 'rtl' ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </button>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg bg-purple-950/60 hover:bg-purple-900 disabled:opacity-40 text-slate-300"
              >
                {dir === 'rtl' ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Order Details Modal */}
      {selectedOrderId && (
        <OrderDetailsModal
          orderId={selectedOrderId}
          onClose={() => setSelectedOrderId(null)}
          onOrderUpdated={loadOrders}
        />
      )}

      {/* Manual New Order Modal */}
      {isNewOrderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg rounded-3xl bg-[#100a26] border border-purple-800/60 shadow-2xl p-6 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-4">
              <h2 className="text-lg font-bold text-white">إضافة طلب يدوي جديد (COD)</h2>
              <button
                onClick={() => setIsNewOrderModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateManualOrder} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">اسم العميل *</label>
                <input
                  type="text"
                  required
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  placeholder="مثال: يوسف المنصوري"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">رقم هاتف واتساب *</label>
                <input
                  type="tel"
                  required
                  value={newCustomerPhone}
                  onChange={(e) => setNewCustomerPhone(e.target.value)}
                  placeholder="+2126XXXXXXXX"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">المدينة</label>
                  <input
                    type="text"
                    value={newCustomerCity}
                    onChange={(e) => setNewCustomerCity(e.target.value)}
                    placeholder="الدار البيضاء"
                    className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">المبلغ الإجمالي (DH)</label>
                  <input
                    type="number"
                    value={newProductPrice}
                    onChange={(e) => setNewProductPrice(Number(e.target.value))}
                    className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">العنوان التفصيلي</label>
                <input
                  type="text"
                  value={newCustomerAddress}
                  onChange={(e) => setNewCustomerAddress(e.target.value)}
                  placeholder="الحي، الشارع، رقم البناية"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">المنتج *</label>
                <input
                  type="text"
                  required
                  value={newProductName}
                  onChange={(e) => setNewProductName(e.target.value)}
                  placeholder="اسم المنتج المطلوب"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="pt-3 border-t border-purple-900/40 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewOrderModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-purple-950 hover:bg-purple-900 text-slate-300 text-xs font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingOrder}
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-purple-600/30"
                >
                  {isSubmittingOrder ? 'جاري الحفظ...' : 'حفظ وإرسال واتساب فوراً'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
