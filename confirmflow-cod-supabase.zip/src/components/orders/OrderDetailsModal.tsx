import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Order, OrderStatus } from '../../types';
import { 
  X, 
  CheckCircle2, 
  XCircle, 
  Send, 
  Bot, 
  Truck, 
  Package, 
  Clock, 
  Phone, 
  MapPin, 
  ExternalLink,
  MessageCircle,
  Sparkles,
  AlertTriangle,
  RotateCcw,
  Printer
} from 'lucide-react';

interface Props {
  orderId: string;
  onClose: () => void;
  onOrderUpdated: () => void;
}

export const OrderDetailsModal: React.FC<Props> = ({ orderId, onClose, onOrderUpdated }) => {
  const { t, showToast } = useApp();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [replyInput, setReplyInput] = useState('');
  const [isProcessingReply, setIsProcessingReply] = useState(false);
  const [manualNote, setManualNote] = useState('');

  const loadOrder = async () => {
    try {
      setLoading(true);
      const res = await api.getOrder(orderId);
      if (res.order) {
        setOrder(res.order);
        setManualNote(res.order.notes || '');
      }
    } catch (e) {
      console.error(e);
      showToast('تعذر تحميل تفاصيل الطلب', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrder();
  }, [orderId]);

  const handleUpdateStatus = async (status: OrderStatus) => {
    if (!order) return;
    try {
      const res = await api.updateOrderStatus(order.id, status, manualNote);
      if (res.success) {
        setOrder(res.order);
        showToast(`تم تحديث حالة الطلب إلى ${t(`status_${status}`)} بنجاح`, 'success');
        onOrderUpdated();
      }
    } catch (e) {
      showToast('فشل تحديث حالة الطلب', 'error');
    }
  };

  const handleSimulateInboundReply = async (textToUse?: string) => {
    const text = textToUse || replyInput;
    if (!text.trim() || !order) return;

    setIsProcessingReply(true);
    try {
      const res = await api.simulateWhatsAppReply(order.id, text);
      if (res.success) {
        setOrder(res.order);
        setReplyInput('');
        const intent = res.classification?.intent;
        showToast(
          intent === 'CONFIRMED' 
            ? 'الذكاء الاصطناعي أكد الطلب بنجاح ✅' 
            : intent === 'CANCELLED' 
            ? 'الذكاء الاصطناعي ألغى الطلب ❌' 
            : 'الذكاء الاصطناعي صنّف الرد كاستفسار يحتاج مراجعة ⚠️',
          intent === 'CANCELLED' ? 'info' : 'success'
        );
        onOrderUpdated();
      }
    } catch (e) {
      showToast('تعذر معالجة رد الواتساب', 'error');
    } finally {
      setIsProcessingReply(false);
    }
  };

  const handlePrintPackingSlip = () => {
    window.print();
  };

  if (loading || !order) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
        <div className="glass-panel p-8 rounded-3xl text-center">
          <Sparkles className="w-8 h-8 text-purple-400 animate-spin mx-auto mb-3" />
          <p className="text-sm font-semibold text-white">جاري تحميل تفاصيل الطلب...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#100a26] border border-purple-800/60 shadow-2xl p-5 sm:p-7 text-right my-auto">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-purple-900/40 mb-6">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white font-mono">{order.orderNumber}</h2>
                <span className={`px-2.5 py-0.5 rounded-md text-xs font-bold ${
                  order.status === 'CONFIRMED'
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                    : order.status === 'CANCELLED'
                    ? 'bg-rose-950 text-rose-400 border border-rose-800/50'
                    : order.status === 'NEEDS_REVIEW'
                    ? 'bg-amber-950 text-amber-400 border border-amber-800/50'
                    : 'bg-purple-950 text-purple-300 border border-purple-800/50'
                }`}>
                  {t(`status_${order.status}`)}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                المتجر: <strong className="text-purple-300">{order.storeName}</strong> ({order.source})
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintPackingSlip}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/60 hover:bg-purple-900 text-xs text-slate-300 hover:text-white border border-purple-800/40 transition-colors"
              title="طباعة بوليصة الشحن"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة البوليصة</span>
            </button>

            <a
              href={`https://wa.me/${order.customerPhone.replace('+', '')}?text=${encodeURIComponent(`السلام عليكم ${order.customerName}، بخصوص طلبك ${order.orderNumber} من ${order.storeName}`)}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 border border-emerald-500/50 text-xs text-emerald-200 hover:text-white transition-all font-semibold"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>فتح WhatsApp</span>
            </a>
          </div>
        </div>

        {/* 2-Column Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column: Customer & Financial details */}
          <div className="lg:col-span-6 space-y-5">
            
            {/* Customer Box */}
            <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">بيانات الزبون والتوصيل</h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">اسم العميل:</span>
                  <span className="font-bold text-white">{order.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">رقم الهاتف:</span>
                  <span className="font-mono text-purple-300 font-bold">{order.customerPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">المدينة:</span>
                  <span className="text-white">{order.customerCity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">عنوان التوصيل:</span>
                  <span className="text-slate-200 truncate max-w-[200px]">{order.customerAddress || 'غير محدد'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">طريقة الدفع:</span>
                  <span className="font-bold text-amber-400">الدفع عند الاستلام (COD)</span>
                </div>
              </div>
            </div>

            {/* Items & Finance Box */}
            <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">المنتجات والحساب المالي</h3>
              <div className="space-y-2.5 mb-3">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs pb-2 border-b border-purple-900/30">
                    <div>
                      <p className="font-semibold text-white">{item.name}</p>
                      <p className="text-[11px] text-slate-400">الكمية: {item.quantity}</p>
                    </div>
                    <span className="font-mono font-bold text-purple-200">{item.price} DH</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1.5 text-xs pt-1">
                <div className="flex justify-between text-slate-400">
                  <span>المجموع الفرعي:</span>
                  <span className="font-mono">{order.subtotal} DH</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>مصاريف الشحن والتوصيل:</span>
                  <span className="font-mono">{order.shippingFee} DH</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-emerald-400 pt-2 border-t border-purple-900/40">
                  <span>المبلغ المطلوب عند الاستلام:</span>
                  <span className="font-mono">{order.totalPrice} DH</span>
                </div>
              </div>
            </div>

            {/* Manual Status Transition Buttons */}
            <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">تغيير حالة الطلب يدوياً</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <button
                  onClick={() => handleUpdateStatus('CONFIRMED')}
                  className="py-2 px-2.5 rounded-xl bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-800/50 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>تأكيد الطلب</span>
                </button>
                <button
                  onClick={() => handleUpdateStatus('CANCELLED')}
                  className="py-2 px-2.5 rounded-xl bg-rose-950/70 hover:bg-rose-900/80 border border-rose-800/50 text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>إلغاء الطلب</span>
                </button>
                <button
                  onClick={() => handleUpdateStatus('SHIPPED')}
                  className="py-2 px-2.5 rounded-xl bg-purple-950/70 hover:bg-purple-900/80 border border-purple-800/50 text-purple-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>تم الشحن</span>
                </button>
                <button
                  onClick={() => handleUpdateStatus('DELIVERED')}
                  className="py-2 px-2.5 rounded-xl bg-sky-950/70 hover:bg-sky-900/80 border border-sky-800/50 text-sky-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Package className="w-3.5 h-3.5" />
                  <span>تم التسليم</span>
                </button>
                <button
                  onClick={() => handleUpdateStatus('RETURNED')}
                  className="py-2 px-2.5 rounded-xl bg-amber-950/70 hover:bg-amber-900/80 border border-amber-800/50 text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>مرتجع</span>
                </button>
                <button
                  onClick={() => handleUpdateStatus('NEEDS_REVIEW')}
                  className="py-2 px-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>مراجعة</span>
                </button>
              </div>
            </div>

          </div>

          {/* Right Column: WhatsApp Transcript & AI Reply Simulator */}
          <div className="lg:col-span-6 space-y-5">
            
            {/* WhatsApp Chat Log Box */}
            <div className="glass-panel p-4 rounded-2xl border border-purple-800/40 flex flex-col h-[340px]">
              <div className="flex items-center justify-between pb-2.5 border-b border-purple-900/30 mb-3">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Bot className="w-4 h-4 text-purple-400" />
                  سجل رسائل الواتساب والردود
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {order.messages.length} رسالة
                </span>
              </div>

              {/* Chat bubbles */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
                {order.messages.length === 0 ? (
                  <p className="text-center text-slate-500 py-10">لم يتم إرسال أي رسائل حتى الآن</p>
                ) : (
                  order.messages.map((msg) => (
                    <div 
                      key={msg.id}
                      className={`flex flex-col ${msg.direction === 'OUTBOUND' ? 'items-start' : 'items-end'}`}
                    >
                      <div className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                        msg.direction === 'OUTBOUND'
                          ? 'bg-[#1a1236] border border-purple-800/40 text-slate-200 rounded-tr-none'
                          : 'bg-purple-700/80 text-white rounded-tl-none shadow-md'
                      }`}>
                        <p className="whitespace-pre-line">{msg.body}</p>
                        
                        {/* AI Classification Tag */}
                        {msg.aiClassification && (
                          <div className="mt-2 pt-2 border-t border-white/20 text-[11px] space-y-0.5">
                            <span className="font-bold text-purple-200 flex items-center gap-1">
                              <Sparkles className="w-3 h-3" />
                              تصنيف الذكاء الاصطناعي: {msg.aiClassification.intent} ({Math.round(msg.aiClassification.confidence * 100)}%)
                            </span>
                            <p className="text-purple-100 text-[10px]">{msg.aiClassification.reason}</p>
                          </div>
                        )}

                        <span className="text-[9px] text-slate-400 block text-left mt-1">
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ✓✓
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Inbound Simulator Input */}
              <div className="pt-3 border-t border-purple-900/30">
                <p className="text-[11px] font-semibold text-purple-300 mb-1.5">
                  ⚡ محاكاة رد العميل بالدارجة / العربية لاختبار الذكاء الاصطناعي:
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={replyInput}
                    onChange={(e) => setReplyInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSimulateInboundReply()}
                    placeholder="مثال: واخا صافي صيفطوه ليا، أو: لا لغيوه..."
                    className="flex-1 bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                  <button
                    onClick={() => handleSimulateInboundReply()}
                    disabled={isProcessingReply || !replyInput.trim()}
                    className="px-3 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isProcessingReply ? 'تحليل...' : 'إرسال'}</span>
                  </button>
                </div>

                {/* Quick Darija Presets */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <button
                    onClick={() => handleSimulateInboundReply('واخا صافي ناضي صيفطوه ليا')}
                    className="px-2 py-0.5 rounded-md bg-emerald-950/60 hover:bg-emerald-900 text-[10px] text-emerald-300 border border-emerald-800/40"
                  >
                    "واخا صيفطوه" (تأكيد)
                  </button>
                  <button
                    onClick={() => handleSimulateInboundReply('لا سمحليا لقيتو عند واحد اخر لغيو الطلب')}
                    className="px-2 py-0.5 rounded-md bg-rose-950/60 hover:bg-rose-900 text-[10px] text-rose-300 border border-rose-800/40"
                  >
                    "ما بقيتش بغيتو" (إلغاء)
                  </button>
                  <button
                    onClick={() => handleSimulateInboundReply('واش كاين فاللون لكحل؟ وشحال التوصيل؟')}
                    className="px-2 py-0.5 rounded-md bg-amber-950/60 hover:bg-amber-900 text-[10px] text-amber-300 border border-amber-800/40"
                  >
                    "شحال التوصيل؟" (سؤال)
                  </button>
                </div>
              </div>
            </div>

            {/* Timeline */}
            <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">مسار الطلب (Order Timeline)</h3>
              <div className="space-y-3 relative before:absolute before:inset-0 before:right-2.5 before:w-0.5 before:bg-purple-900/50">
                {order.timeline.map((evt) => (
                  <div key={evt.id} className="flex items-start gap-3 relative pr-6">
                    <div className="w-2.5 h-2.5 rounded-full bg-purple-500 absolute right-1.5 mt-1"></div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{evt.title}</span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-0.5">{evt.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
