import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { PlatformType } from '../../types';
import { 
  Check, 
  Store as StoreIcon, 
  Layers, 
  Link as LinkIcon, 
  Bot, 
  Send, 
  Sparkles, 
  CheckCircle2, 
  ArrowLeft, 
  ArrowRight,
  ShieldCheck,
  Smartphone
} from 'lucide-react';

export const OnboardingWizard: React.FC = () => {
  const { isOnboardingOpen, setIsOnboardingOpen, setActiveTab, showToast, refreshData, dir } = useApp();

  const [currentStep, setCurrentStep] = useState(1);
  const [storeName, setStoreName] = useState('بوتيك الأناقة المغربية');
  const [storeDomain, setStoreDomain] = useState('marocfashion.ma');
  const [currency, setCurrency] = useState('DH');
  const [platform, setPlatform] = useState<PlatformType>('SHOPIFY');
  const [whatsappPhone, setWhatsappPhone] = useState('+212611223344');
  const [testPhoneNumber, setTestPhoneNumber] = useState('+212661234567');
  const [testSent, setTestSent] = useState(false);
  const [isSendingTest, setIsSendingTest] = useState(false);

  if (!isOnboardingOpen) return null;

  const totalSteps = 6;

  const handleNextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else {
      setIsOnboardingOpen(false);
      setActiveTab('dashboard');
      showToast('تهانينا! تم إعداد متجرك ونظام تأكيد الطلبات بنجاح 🚀', 'success');
      refreshData();
    }
  };

  const handleSendTestMessage = async () => {
    if (!testPhoneNumber) return;
    setIsSendingTest(true);
    setTimeout(() => {
      setIsSendingTest(false);
      setTestSent(true);
      showToast('تم إرسال رسالة التجربة إلى رقمك بنجاح عبر WhatsApp Business API ✅', 'success');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="w-full max-w-2xl rounded-3xl bg-[#100a26] border border-purple-800/60 shadow-2xl p-6 sm:p-8 text-right relative overflow-hidden">
        
        {/* Step Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs font-semibold text-purple-300 mb-2">
            <span>الخطوة {currentStep} من {totalSteps}</span>
            <span className="font-mono">{Math.round((currentStep / totalSteps) * 100)}%</span>
          </div>
          <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-purple-600 to-indigo-500 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / totalSteps) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Step 1: Store Info */}
        {currentStep === 1 && (
          <div className="space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 mb-3">
              <StoreIcon className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black text-white">معلومات متجرك الإلكتروني</h2>
            <p className="text-xs text-slate-400">
              أدخل اسم متجرك وعملة المبيعات لربط الطلبات بدقة.
            </p>

            <div className="space-y-3 pt-2 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم المتجر</label>
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3.5 py-2.5 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">رابط المتجر (Domain)</label>
                <input
                  type="text"
                  value={storeDomain}
                  onChange={(e) => setStoreDomain(e.target.value)}
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3.5 py-2.5 text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">العملة</label>
                <input
                  type="text"
                  readOnly
                  value="الدرهم المغربي (DH)"
                  className="w-full bg-purple-950/40 border border-purple-800/40 rounded-xl px-3.5 py-2.5 text-purple-300"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Select Platform */}
        {currentStep === 2 && (
          <div className="space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 mb-3">
              <Layers className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black text-white">اختر منصة متجرك الإلكتروني</h2>
            <p className="text-xs text-slate-400">
              حدد المنصة التي تستخدمها لتوليد طريقة الربط التلقائية.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2">
              {[
                { id: 'SHOPIFY' as PlatformType, name: 'Shopify', desc: 'ربط مباشر عبر Webhooks الرسمية' },
                { id: 'WOOCOMMERCE' as PlatformType, name: 'WooCommerce', desc: 'WordPress REST API & Webhooks' },
                { id: 'YOUCAN' as PlatformType, name: 'YouCan Shop', desc: 'تكامل كامل لطلبات الدفع عند الاستلام' },
                { id: 'CUSTOM_API' as PlatformType, name: 'Custom Store / API', desc: 'ربط أي منصة مخصصة عبر REST API' }
              ].map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPlatform(p.id)}
                  className={`p-4 rounded-2xl border text-right transition-all cursor-pointer ${
                    platform === p.id
                      ? 'bg-purple-600/40 border-purple-400 shadow-lg shadow-purple-600/30'
                      : 'bg-purple-950/40 border-purple-800/40 hover:bg-purple-900/40'
                  }`}
                >
                  <p className="font-bold text-white text-sm">{p.name}</p>
                  <p className="text-[11px] text-slate-400 mt-1">{p.desc}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Connect Store */}
        {currentStep === 3 && (
          <div className="space-y-4 text-xs">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 mb-3">
              <LinkIcon className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black text-white">ربط المتجر عبر Webhook</h2>
            <p className="text-slate-400">
              انسخ هذا الرابط وألصقه في لوحة تحكم متجرك {platform}:
            </p>

            <div className="p-4 rounded-2xl bg-purple-950/60 border border-purple-800/50 space-y-2">
              <span className="text-slate-400 font-semibold">رابط الاستقبال التلقائي (Webhook URL):</span>
              <p className="font-mono text-purple-300 break-all bg-black/40 p-2.5 rounded-xl border border-purple-900/50">
                https://your-domain.com/api/webhooks/{platform.toLowerCase()}
              </p>
              <div className="flex items-center gap-1.5 text-emerald-400 text-[11px] pt-1 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>تم التحقق من جاهزية نقطة النهاية (Ready to receive orders)</span>
              </div>
            </div>
          </div>
        )}

        {/* Step 4: WhatsApp Connection */}
        {currentStep === 4 && (
          <div className="space-y-4 text-xs">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-emerald-400 mb-3">
              <Bot className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black text-white">ربط WhatsApp Business API</h2>
            <p className="text-slate-400">
              اربط رقم هاتفك التجاري المعتمد لإرسال رسائل التأكيد الرسمية بأزرار تفاعلية:
            </p>

            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">رقم هاتف متجرك للواتساب</label>
                <input
                  type="text"
                  value={whatsappPhone}
                  onChange={(e) => setWhatsappPhone(e.target.value)}
                  placeholder="+212611223344"
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3.5 py-2.5 text-white font-mono"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-800/30 text-slate-300 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  ربط سحابي عبر خوادم Meta Cloud API الرسمية لضمان تواصل آمن وموثوق لمتجرك.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Step 5: Test Send Message */}
        {currentStep === 5 && (
          <div className="space-y-4 text-xs">
            <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 mb-3">
              <Send className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-black text-white">اختبار إرسال رسالة تجريبية</h2>
            <p className="text-slate-400">
              أدخل رقم هاتفك الشخصي لنرسل لك رسالة تجريبية تحاكي طلب شراء لتجربتها بنفسك:
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex gap-2">
                <input
                  type="tel"
                  value={testPhoneNumber}
                  onChange={(e) => setTestPhoneNumber(e.target.value)}
                  placeholder="+2126XXXXXXXX"
                  className="flex-1 bg-purple-950/60 border border-purple-800/50 rounded-xl px-3.5 py-2.5 text-white font-mono"
                />
                <button
                  type="button"
                  onClick={handleSendTestMessage}
                  disabled={isSendingTest}
                  className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingTest ? 'جاري الإرسال...' : 'إرسال الرسالة'}</span>
                </button>
              </div>

              {testSent && (
                <div className="p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-800/50 text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تم إرسال الرسالة بنجاح! يمكنك الآن تجربة الرد عليها لمعاينة الذكاء الاصطناعي.</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Step 6: Complete Setup */}
        {currentStep === 6 && (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400 mx-auto">
              <Check className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-white">كل شيء جاهز للعمل!</h2>
            <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
              متجرك <strong>{storeName}</strong> متصل الآن بنجاح مع توثيق COD. جميع الطلبات الجديدة ستتم أتمتتها وتأكيدها تلقائياً عبر واتساب.
            </p>
          </div>
        )}

        {/* Wizard Footer Controls */}
        <div className="mt-8 pt-4 border-t border-purple-900/40 flex items-center justify-between">
          {currentStep > 1 && currentStep < 6 ? (
            <button
              onClick={() => setCurrentStep(currentStep - 1)}
              className="px-4 py-2 rounded-xl bg-purple-950/60 hover:bg-purple-900 text-slate-300 text-xs font-semibold"
            >
              السابق
            </button>
          ) : (
            <div></div>
          )}

          <button
            onClick={handleNextStep}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-purple-600/30 flex items-center gap-1.5 cursor-pointer"
          >
            <span>{currentStep === 6 ? 'الدخول إلى لوحة التحكم' : 'المتابعة'}</span>
            {dir === 'rtl' ? <ArrowLeft className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
          </button>
        </div>

      </div>
    </div>
  );
};
