import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { 
  BarChart3, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  Truck, 
  RotateCcw, 
  DollarSign, 
  Calendar,
  Sparkles
} from 'lucide-react';

export const AnalyticsView: React.FC = () => {
  const { t } = useApp();
  const [period, setPeriod] = useState<'today' | '7days' | '30days' | 'month'>('30days');
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        const res = await api.getAnalytics();
        setAnalytics(res);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, [period]);

  const kpis = analytics?.kpis || {
    totalOrders: 0,
    confirmed: 0,
    cancelled: 0,
    pending: 0,
    delivered: 0,
    returned: 0,
    confirmationRate: 0,
    revenue: 0
  };

  const deliveryRate = kpis.confirmed > 0 ? Math.round((kpis.delivered / kpis.confirmed) * 100) : 0;
  const cancellationRate = kpis.totalOrders > 0 ? Math.round((kpis.cancelled / kpis.totalOrders) * 100) : 0;
  const returnRate = kpis.delivered + kpis.returned > 0 ? Math.round((kpis.returned / (kpis.delivered + kpis.returned)) * 100) : 0;

  return (
    <div className="space-y-6 text-right">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>التقارير والتحليلات المتقدمة</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
              COD Insights
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            مؤشرات أداء تأكيد طلبات الدفع عند الاستلام، نسب التحصيل، والعائد المالي.
          </p>
        </div>

        {/* Time Filter */}
        <div className="flex items-center bg-[#130d2a] p-1 rounded-xl border border-purple-900/40 text-xs">
          {(['today', '7days', '30days', 'month'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1.5 rounded-lg transition-colors font-semibold ${
                period === p ? 'bg-purple-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              {p === 'today' ? 'اليوم' : p === '7days' ? 'آخر 7 أيام' : p === '30days' ? 'آخر 30 يوم' : 'هذا الشهر'}
            </button>
          ))}
        </div>
      </div>

      {/* Ratios & Key Percentages Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="glass-panel p-5 rounded-2xl border border-purple-800/40">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-400">نسبة التأكيد (Confirmation Rate)</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-black text-emerald-400 font-mono">{kpis.confirmationRate}%</p>
          <p className="text-[11px] text-slate-400 mt-1">محسوبة من إجمالي الطلبات المسجلة</p>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-purple-800/40">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-400">نسبة الإلغاء (Cancellation Rate)</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-3xl font-black text-rose-400 font-mono">{cancellationRate}%</p>
          <p className="text-[11px] text-rose-300 mt-1">كشف وإلغاء مبكر قبل الشحن</p>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-purple-800/40">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-400">نسبة التسليم (Delivery Rate)</span>
            <Truck className="w-4 h-4 text-sky-400" />
          </div>
          <p className="text-3xl font-black text-sky-400 font-mono">{deliveryRate}%</p>
          <p className="text-[11px] text-slate-400 mt-1">من إجمالي الطلبات المشحونة</p>
        </div>

        <div className="glass-panel p-5 rounded-2xl border border-purple-800/40">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-slate-400">نسبة المرتجع (Return Rate)</span>
            <RotateCcw className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-3xl font-black text-amber-300 font-mono">{returnRate}%</p>
          <p className="text-[11px] text-emerald-400 mt-1">منخفضة جداً بفضل التأكيد المسبق</p>
        </div>

      </div>

      {/* Revenue & Volume Chart Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <div className="lg:col-span-8 glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">تطور المبيعات المؤكدة (Revenue Trend)</h2>
            <span className="font-mono text-emerald-400 font-bold text-sm">
              إجمالي: {kpis.revenue.toLocaleString()} DH
            </span>
          </div>

          <div className="h-56 flex items-end justify-between gap-4 pt-8 pb-2 border-b border-purple-900/40">
            {[
              { label: 'الأسبوع 1', rev: 4500, orders: 110 },
              { label: 'الأسبوع 2', rev: 5900, orders: 145 },
              { label: 'الأسبوع 3', rev: 6100, orders: 155 },
              { label: 'الأسبوع 4', rev: 6887, orders: 189 },
            ].map((wk, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                <span className="font-mono text-[11px] text-emerald-300">{wk.rev} DH</span>
                <div 
                  style={{ height: `${(wk.rev / 7000) * 100}%` }}
                  className="w-full max-w-[48px] bg-gradient-to-t from-purple-600 to-emerald-400 rounded-t-lg transition-all"
                ></div>
                <span className="text-xs text-slate-400">{wk.label}</span>
              </div>
            ))}
          </div>

          <p className="text-xs text-slate-400">
            تزايد مستمر في نسبة التأكيد بنسبة +23% منذ ربط أتمتة واتساب التلقائية والذكاء الاصطناعي.
          </p>
        </div>

        <div className="lg:col-span-4 glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4">
          <h2 className="text-base font-bold text-white">أهم مدن التوصيل</h2>
          <div className="space-y-3 text-xs">
            {[
              { city: 'الدار البيضاء', percent: 42, count: 251 },
              { city: 'الرباط وسلا', percent: 22, count: 132 },
              { city: 'مراكش', percent: 14, count: 84 },
              { city: 'طنجة وتطوان', percent: 12, count: 72 },
              { city: 'فاس ومكناس', percent: 10, count: 60 }
            ].map((c, i) => (
              <div key={i}>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>{c.city}</span>
                  <span className="font-mono font-bold text-purple-300">{c.count} طلب ({c.percent}%)</span>
                </div>
                <div className="w-full h-2 bg-purple-950 rounded-full overflow-hidden">
                  <div className="h-full bg-purple-500 rounded-full" style={{ width: `${c.percent}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
