import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Settings as SettingsIcon, 
  User, 
  Store, 
  Bell, 
  Shield, 
  Globe, 
  Save, 
  Check, 
  Lock
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { user, setUser, language, setLanguage, showToast, t } = useApp();

  const [name, setName] = useState(user?.name || 'ياسين العلمي');
  const [storeName, setStoreName] = useState(user?.storeName || 'بوتيك الأناقة المغربية');
  const [email, setEmail] = useState(user?.email || 'contact@marocfashion.ma');
  const [phone, setPhone] = useState(user?.phone || '+212670112233');
  const [notifyOnConfirm, setNotifyOnConfirm] = useState(true);
  const [notifyOnCancel, setNotifyOnCancel] = useState(true);
  const [notifyOnLowCredit, setNotifyOnLowCredit] = useState(true);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (user) {
      setUser({ ...user, name, storeName, email, phone });
      showToast('تم حفظ بيانات الحساب بنجاح ✅', 'success');
    }
  };

  return (
    <div className="space-y-6 text-right">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>إعدادات الحساب والمتجر (Settings)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            إدارة الملف الشخصي، تفضيلات التنبيهات، والأمان.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Profile Details Form */}
        <div className="md:col-span-7 glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-purple-900/40">
            <User className="w-4 h-4 text-purple-400" />
            <h2 className="text-sm font-bold text-white">بيانات التاجر والمتجر</h2>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">الاسم الكامل</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم المتجر الأساسي</label>
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">البريد الإلكتروني</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">رقم الهاتف للاتصال والواتساب</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white font-mono"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold shadow-md shadow-purple-600/30 transition-all flex items-center gap-1.5"
              >
                <Save className="w-3.5 h-3.5" />
                <span>حفظ التعديلات</span>
              </button>
            </div>
          </form>
        </div>

        {/* Notifications & Language */}
        <div className="md:col-span-5 space-y-6">
          
          {/* Notification toggles */}
          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-3.5 text-xs">
            <div className="flex items-center gap-2 pb-3 border-b border-purple-900/40">
              <Bell className="w-4 h-4 text-purple-400" />
              <h2 className="text-sm font-bold text-white">تفضيلات الإشعارات</h2>
            </div>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-300">إشعار عند تأكيد طلب جديد بالـ AI</span>
              <input
                type="checkbox"
                checked={notifyOnConfirm}
                onChange={(e) => setNotifyOnConfirm(e.target.checked)}
                className="w-4 h-4 accent-purple-500"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-300">إشعار عند إلغاء طلب من طرف العميل</span>
              <input
                type="checkbox"
                checked={notifyOnCancel}
                onChange={(e) => setNotifyOnCancel(e.target.checked)}
                className="w-4 h-4 accent-purple-500"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <span className="text-slate-300">تنبيه عند انخفاض رصيد المحفظة عن 50 DH</span>
              <input
                type="checkbox"
                checked={notifyOnLowCredit}
                onChange={(e) => setNotifyOnLowCredit(e.target.checked)}
                className="w-4 h-4 accent-purple-500"
              />
            </label>
          </div>

          {/* Language Switch */}
          <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-3.5 text-xs">
            <div className="flex items-center gap-2 pb-3 border-b border-purple-900/40">
              <Globe className="w-4 h-4 text-purple-400" />
              <h2 className="text-sm font-bold text-white">لغة واجهة النظام</h2>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setLanguage('ar')}
                className={`py-2 px-3 rounded-xl font-bold transition-all ${
                  language === 'ar' ? 'bg-purple-600 text-white' : 'bg-purple-950/60 text-slate-300 hover:text-white'
                }`}
              >
                العربية (RTL)
              </button>

              <button
                type="button"
                onClick={() => setLanguage('fr')}
                className={`py-2 px-3 rounded-xl font-bold transition-all ${
                  language === 'fr' ? 'bg-purple-600 text-white' : 'bg-purple-950/60 text-slate-300 hover:text-white'
                }`}
              >
                Français
              </button>

              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`py-2 px-3 rounded-xl font-bold transition-all ${
                  language === 'en' ? 'bg-purple-600 text-white' : 'bg-purple-950/60 text-slate-300 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
