import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { 
  Bot, 
  MessageSquare, 
  Clock, 
  ShieldCheck, 
  Send, 
  Sparkles, 
  Check, 
  Save, 
  RefreshCw, 
  AlertCircle,
  Zap,
  Sliders,
  HelpCircle,
  Copy
} from 'lucide-react';

export const WhatsAppAutomationView: React.FC = () => {
  const { t, showToast } = useApp();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Settings State
  const [automationSettings, setAutomationSettings] = useState({
    autoSendConfirmation: true,
    firstReminderDelayMinutes: 15,
    enableSecondReminder: true,
    secondReminderDelayMinutes: 120,
    maxAttempts: 2,
    autoCancelAfterHours: 24,
    aiAutoConfirmation: true,
    aiAutoCancellation: true,
    aiSensitivity: 'BALANCED'
  });

  const [whatsappConfig, setWhatsappConfig] = useState({
    phoneNumberId: '109847291823741',
    wabaId: '827364519283746',
    accessToken: 'EAAG...CONFIRMFLOW_META_TOKEN',
    verifyToken: 'confirmflow_meta_verify_2026',
    businessPhoneNumber: '+212611223344',
    isConnected: true,
    provider: 'META_CLOUD_API'
  });

  // AI Interactive Sandbox Test
  const [testText, setTestText] = useState('واخا صافي ناضي صيفطوه ليا غدا ان شاء الله');
  const [testResult, setTestResult] = useState<any>(null);
  const [isTestingAI, setIsTestingAI] = useState(false);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const res = await api.getSettings();
      if (res.automation) setAutomationSettings(res.automation);
      if (res.whatsapp) setWhatsappConfig(res.whatsapp);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSaveSettings = async () => {
    setSaving(true);
    try {
      await api.updateSettings({
        automation: automationSettings,
        whatsapp: whatsappConfig
      });
      showToast('تم حفظ إعدادات الأتمتة وواتساب بنجاح ✅', 'success');
    } catch (e) {
      showToast('فشل حفظ الإعدادات', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleTestAIClick = async (customText?: string) => {
    const textToTest = customText || testText;
    if (!textToTest.trim()) return;

    setIsTestingAI(true);
    try {
      const res = await api.classifyText(textToTest);
      if (res.success && res.classification) {
        setTestResult(res.classification);
      }
    } catch (e) {
      showToast('تعذر تحليل النص', 'error');
    } finally {
      setIsTestingAI(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    showToast(`تم نسخ ${label} بنجاح`, 'success');
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>أتمتة واتساب والذكاء الاصطناعي</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
              Meta Cloud API
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            إعدادات الإرسال الفوري، التذكيرات الذكية (Follow-ups)، وتدريب معالجة الدارجة المغربية.
          </p>
        </div>

        <button
          onClick={handleSaveSettings}
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-600/30 cursor-pointer disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}</span>
        </button>
      </div>

      {/* Main 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Automation Timing & AI Rules */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Follow-up Timing Settings */}
          <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 space-y-4 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/30">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-white">جدولة رسائل التأكيد والمتابعة (Follow-up)</h2>
              </div>
              <span className="text-[11px] text-purple-300">أوتوماتيكي 24/7</span>
            </div>

            <div className="space-y-4 text-xs">
              <label className="flex items-center justify-between p-3 rounded-xl bg-purple-950/40 border border-purple-800/30 cursor-pointer">
                <div>
                  <p className="font-semibold text-white">إرسال رسالة التأكيد فور تسجيل الطلب</p>
                  <p className="text-[11px] text-slate-400">إرسال تلقائي فوري بمجرد استقبال الطلب عبر Webhook</p>
                </div>
                <input
                  type="checkbox"
                  checked={automationSettings.autoSendConfirmation}
                  onChange={(e) => setAutomationSettings({ ...automationSettings, autoSendConfirmation: e.target.checked })}
                  className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
                />
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                  <label className="block text-slate-300 font-semibold mb-1">وقت التذكير الأول (Follow-up 1)</label>
                  <select
                    value={automationSettings.firstReminderDelayMinutes}
                    onChange={(e) => setAutomationSettings({ ...automationSettings, firstReminderDelayMinutes: Number(e.target.value) })}
                    className="w-full bg-[#130d2a] border border-purple-800/50 rounded-lg p-2 text-white text-xs focus:outline-none"
                  >
                    <option value={15}>بعد 15 دقيقة (موصى به)</option>
                    <option value={30}>بعد 30 دقيقة</option>
                    <option value={60}>بعد ساعة واحدة</option>
                    <option value={120}>بعد ساعتين</option>
                  </select>
                </div>

                <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                  <label className="block text-slate-300 font-semibold mb-1">وقت التذكير الثاني (Follow-up 2)</label>
                  <select
                    value={automationSettings.secondReminderDelayMinutes}
                    onChange={(e) => setAutomationSettings({ ...automationSettings, secondReminderDelayMinutes: Number(e.target.value) })}
                    className="w-full bg-[#130d2a] border border-purple-800/50 rounded-lg p-2 text-white text-xs focus:outline-none"
                  >
                    <option value={120}>بعد ساعتين</option>
                    <option value={240}>بعد 4 ساعات</option>
                    <option value={720}>بعد 12 ساعة</option>
                    <option value={1440}>في اليوم التالي (24 ساعة)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                  <label className="block text-slate-300 font-semibold mb-1">أقصى عدد محاولات تذكير</label>
                  <select
                    value={automationSettings.maxAttempts}
                    onChange={(e) => setAutomationSettings({ ...automationSettings, maxAttempts: Number(e.target.value) })}
                    className="w-full bg-[#130d2a] border border-purple-800/50 rounded-lg p-2 text-white text-xs focus:outline-none"
                  >
                    <option value={1}>محاولة واحدة فقط</option>
                    <option value={2}>محاولتان (الأفضل تجربة للمستخدم)</option>
                    <option value={3}>3 محاولات</option>
                  </select>
                </div>

                <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                  <label className="block text-slate-300 font-semibold mb-1">إلغاء الطلب تلقائياً إذا لم يرد</label>
                  <select
                    value={automationSettings.autoCancelAfterHours}
                    onChange={(e) => setAutomationSettings({ ...automationSettings, autoCancelAfterHours: Number(e.target.value) })}
                    className="w-full bg-[#130d2a] border border-purple-800/50 rounded-lg p-2 text-white text-xs focus:outline-none"
                  >
                    <option value={24}>بعد 24 ساعة (لتفادي شحنات وهمية)</option>
                    <option value={48}>بعد 48 ساعة</option>
                    <option value={72}>بعد 3 أيام</option>
                    <option value={0}>تعطيل الإلغاء التلقائي</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* AI Response Engine Settings */}
          <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 space-y-4 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/30">
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-white">محرك الذكاء الاصطناعي لفهم ردود الزبائن (AI NLP)</h2>
              </div>
              <span className="text-[11px] text-emerald-400 font-mono">Gemini 3.8-Flash</span>
            </div>

            <div className="space-y-3 text-xs">
              <label className="flex items-center justify-between p-3 rounded-xl bg-purple-950/40 border border-purple-800/30 cursor-pointer">
                <div>
                  <p className="font-semibold text-white">تأكيد الطلب التلقائي عند موافقة العميل</p>
                  <p className="text-[11px] text-slate-400">تحديث حالة الطلب إلى CONFIRMED فوراً دون الحاجة لموافقة بشرية</p>
                </div>
                <input
                  type="checkbox"
                  checked={automationSettings.aiAutoConfirmation}
                  onChange={(e) => setAutomationSettings({ ...automationSettings, aiAutoConfirmation: e.target.checked })}
                  className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-purple-950/40 border border-purple-800/30 cursor-pointer">
                <div>
                  <p className="font-semibold text-white">إلغاء الطلب التلقائي عند رغبة العميل</p>
                  <p className="text-[11px] text-slate-400">تحديث الحالة إلى CANCELLED لتفادي مصاريف الشحن والتجهيز</p>
                </div>
                <input
                  type="checkbox"
                  checked={automationSettings.aiAutoCancellation}
                  onChange={(e) => setAutomationSettings({ ...automationSettings, aiAutoCancellation: e.target.checked })}
                  className="w-4 h-4 accent-purple-500 rounded cursor-pointer"
                />
              </label>

              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                <label className="block text-slate-300 font-semibold mb-1">مستوى حساسية الذكاء الاصطناعي (Sensitivity)</label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {(['STRICT', 'BALANCED', 'HIGH'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setAutomationSettings({ ...automationSettings, aiSensitivity: mode })}
                      className={`py-2 px-2 rounded-lg text-center font-bold text-xs transition-colors ${
                        automationSettings.aiSensitivity === mode
                          ? 'bg-purple-600 text-white'
                          : 'bg-purple-950 text-slate-400 hover:text-white'
                      }`}
                    >
                      {mode === 'STRICT' ? 'صارم (أمان عالي)' : mode === 'BALANCED' ? 'متوازن (موصى به)' : 'مرن (تأكيد سريع)'}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: AI Live Testing Sandbox & Meta API Credentials */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* AI Sandbox Interactive Test */}
          <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 space-y-4 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/30">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <h2 className="text-sm font-bold text-white">حقل اختبار الذكاء الاصطناعي المباشر</h2>
              </div>
              <span className="text-[10px] text-purple-300 font-mono">Sandbox</span>
            </div>

            <p className="text-xs text-slate-400">
              اكتب أي رد بالدارجة المغربية أو الفرنسية لمعاينة كيف يفسره النظام في أجزاء من الثانية:
            </p>

            <div className="space-y-2">
              <textarea
                rows={3}
                value={testText}
                onChange={(e) => setTestText(e.target.value)}
                placeholder="اكتب رد العميل هنا..."
                className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 leading-relaxed"
              />

              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    const t = 'صافي ناضي صيفطوه ليا';
                    setTestText(t);
                    handleTestAIClick(t);
                  }}
                  className="px-2 py-1 bg-purple-900/40 hover:bg-purple-800 text-[10px] text-purple-200 rounded-lg transition-colors"
                >
                  "صافي ناضي صيفطوه"
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const t = 'لا سمحليا لقيتو عند واحد اخر ما بقيتش بغيتو';
                    setTestText(t);
                    handleTestAIClick(t);
                  }}
                  className="px-2 py-1 bg-rose-950/40 hover:bg-rose-900 text-[10px] text-rose-300 rounded-lg transition-colors"
                >
                  "ما بقيتش بغيتو"
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const t = 'شحال التوصيل لمراكش وفوقاش يوصل؟';
                    setTestText(t);
                    handleTestAIClick(t);
                  }}
                  className="px-2 py-1 bg-amber-950/40 hover:bg-amber-900 text-[10px] text-amber-300 rounded-lg transition-colors"
                >
                  "شحال التوصيل؟"
                </button>
              </div>

              <button
                type="button"
                onClick={() => handleTestAIClick()}
                disabled={isTestingAI || !testText.trim()}
                className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5"
              >
                <Bot className="w-4 h-4" />
                <span>{isTestingAI ? 'جاري التحليل بالذكاء الاصطناعي...' : 'تحليل الرد واختباره'}</span>
              </button>
            </div>

            {/* Test Result Display */}
            {testResult && (
              <div className="p-4 rounded-xl bg-purple-950/60 border border-purple-800/50 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">النية المستنتجة:</span>
                  <span className={`font-bold px-2.5 py-0.5 rounded-md ${
                    testResult.intent === 'CONFIRMED'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : testResult.intent === 'CANCELLED'
                      ? 'bg-rose-950 text-rose-400 border border-rose-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}>
                    {testResult.intent === 'CONFIRMED' ? 'تأكيد الطلب ✅' : testResult.intent === 'CANCELLED' ? 'إلغاء الطلب ❌' : 'يحتاج مراجعة ⚠️'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">نسبة الثقة (Confidence):</span>
                  <span className="font-mono text-white font-bold">{Math.round(testResult.confidence * 100)}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">اللهجة / اللغة:</span>
                  <span className="text-purple-300 font-semibold">{testResult.language}</span>
                </div>
                <div className="pt-2 border-t border-purple-900/40">
                  <p className="text-[11px] text-slate-400 font-semibold">تفسير المحرك:</p>
                  <p className="text-slate-200 mt-0.5 leading-relaxed">{testResult.reason}</p>
                </div>
              </div>
            )}
          </div>

          {/* Meta Cloud API Integration Credentials */}
          <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 space-y-3.5 text-right">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/30">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-bold text-white">إعدادات Meta WhatsApp API الرسمية</h2>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-bold border border-emerald-800">
                متصل وجاهز
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Phone Number ID</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={whatsappConfig.phoneNumberId}
                    onChange={(e) => setWhatsappConfig({ ...whatsappConfig, phoneNumberId: e.target.value })}
                    className="flex-1 bg-purple-950/50 border border-purple-800/40 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none"
                  />
                  <button
                    onClick={() => copyToClipboard(whatsappConfig.phoneNumberId, 'Phone Number ID')}
                    className="p-2 bg-purple-900/50 hover:bg-purple-800 text-slate-300 rounded-xl"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">WhatsApp Business Account ID (WABA)</label>
                <input
                  type="text"
                  value={whatsappConfig.wabaId}
                  onChange={(e) => setWhatsappConfig({ ...whatsappConfig, wabaId: e.target.value })}
                  className="w-full bg-purple-950/50 border border-purple-800/40 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Webhook Verify Token</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={whatsappConfig.verifyToken}
                    className="flex-1 bg-purple-950/50 border border-purple-800/40 rounded-xl px-3 py-2 text-purple-300 font-mono text-xs focus:outline-none"
                  />
                  <button
                    onClick={() => copyToClipboard(whatsappConfig.verifyToken, 'Verify Token')}
                    className="p-2 bg-purple-900/50 hover:bg-purple-800 text-slate-300 rounded-xl"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-900/30 text-[11px] text-slate-400">
                <span className="font-semibold text-slate-300">رابط Webhook المخصص لميتا:</span>
                <p className="font-mono text-purple-300 mt-1 truncate">https://your-domain.com/api/webhooks/whatsapp</p>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
