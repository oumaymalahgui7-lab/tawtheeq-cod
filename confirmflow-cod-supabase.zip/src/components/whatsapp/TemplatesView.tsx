import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { MessageTemplate } from '../../types';
import { 
  FileText, 
  Save, 
  Sparkles, 
  Smartphone, 
  Plus, 
  Check, 
  Eye, 
  RotateCcw,
  Languages
} from 'lucide-react';

export const TemplatesView: React.FC = () => {
  const { t, showToast } = useApp();

  const [templates, setTemplates] = useState<MessageTemplate[]>([
    {
      id: 'tmpl_1',
      name: 'رسالة التأكيد الفورية (الدارجة / العربية)',
      type: 'CONFIRMATION',
      language: 'darija',
      content: `السلام عليكم {{customer_name}} 👋\n\nتوصلنا بطلبك من متجر {{store_name}}.\n\n📦 المنتج: {{product}}\n🔢 الكمية: {{quantity}}\n💰 المبلغ الإجمالي: {{price}} DH (الدفع عند الاستلام)\n📍 عنوان التوصيل: {{city}} - {{address}}\n\nهل ترغب في تأكيد شحن طلبك؟ اضغط على الزر أدناه 👇`,
      buttons: [
        { text: '✅ نعم، أكّد الطلب', action: 'CONFIRM' },
        { text: '❌ إلغاء الطلب', action: 'CANCEL' }
      ],
      isActive: true,
    },
    {
      id: 'tmpl_2',
      name: 'تذكير أولي بعد 15 دقيقة (Follow-up 1)',
      type: 'REMINDER_1',
      language: 'darija',
      content: `مرحبًا {{customer_name}} 👋\nما زلنا في انتظار تأكيد طلبك {{order_id}} من {{store_name}} حتى نقوم بتجهيزه وإرساله مع شركة التوصيل 🚚.\n\nالمرجو الرد لتأكيد طلبيتك قبل نفاد المخزون.`,
      buttons: [
        { text: '✅ تأكيد الآن', action: 'CONFIRM' },
        { text: '❌ إلغاء', action: 'CANCEL' }
      ],
      isActive: true,
    },
    {
      id: 'tmpl_3',
      name: 'إشعار تسليم الطلب لشركة الشحن',
      type: 'SHIPPED',
      language: 'ar',
      content: `أهلاً {{customer_name}} 📦\nتم تسليم طلبك رقم {{order_id}} لشركة التوصيل وسيتصل بك الموزع اليوم أو غداً.\nالمبلغ المطلوب عند الاستلام: {{price}} DH.\nشكراً لثقتكم بمتجرنا {{store_name}}!`,
      buttons: [],
      isActive: true,
    }
  ]);

  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('tmpl_1');
  const [saving, setSaving] = useState(false);

  const selectedTemplate = templates.find(t => t.id === selectedTemplateId) || templates[0];

  const availableVariables = [
    { key: '{{customer_name}}', desc: 'اسم العميل' },
    { key: '{{product}}', desc: 'اسم المنتج' },
    { key: '{{quantity}}', desc: 'الكمية' },
    { key: '{{price}}', desc: 'المبلغ الإجمالي' },
    { key: '{{city}}', desc: 'المدينة' },
    { key: '{{address}}', desc: 'العنوان' },
    { key: '{{store_name}}', desc: 'اسم المتجر' },
    { key: '{{order_id}}', desc: 'رقم الطلب' },
  ];

  const handleInsertVariable = (variable: string) => {
    setTemplates(prev => prev.map(tmpl => {
      if (tmpl.id === selectedTemplateId) {
        return {
          ...tmpl,
          content: tmpl.content + ' ' + variable
        };
      }
      return tmpl;
    }));
  };

  const handleContentChange = (newContent: string) => {
    setTemplates(prev => prev.map(tmpl => {
      if (tmpl.id === selectedTemplateId) {
        return { ...tmpl, content: newContent };
      }
      return tmpl;
    }));
  };

  const handleSaveTemplates = async () => {
    setSaving(true);
    try {
      await api.updateSettings({ templates });
      showToast('تم حفظ قوالب رسائل الواتساب بنجاح ✅', 'success');
    } catch (e) {
      showToast('فشل حفظ القوالب', 'error');
    } finally {
      setSaving(false);
    }
  };

  // Preview formatted text with realistic dummy data
  const renderPreviewContent = (text: string) => {
    return text
      .replace(/{{customer_name}}/g, 'أمين السبتي')
      .replace(/{{store_name}}/g, 'بوتيك الأناقة المغربية')
      .replace(/{{product}}/g, 'قفطان مغربي عصري')
      .replace(/{{quantity}}/g, '1')
      .replace(/{{price}}/g, '534')
      .replace(/{{city}}/g, 'الدار البيضاء')
      .replace(/{{address}}/g, 'حي المعاريف، زنقة 14')
      .replace(/{{order_id}}/g, 'ORD-5991');
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>قوالب رسائل واتساب (Message Templates)</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-900/60 text-purple-300 font-mono">
              Meta Approved
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            خصص رسائل التأكيد، التذكيرات، وبوالص الشحن باستخدام المتغيرات الديناميكية مع معاينة حية في الوقت الفعلي.
          </p>
        </div>

        <button
          onClick={handleSaveTemplates}
          disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-600/30 cursor-pointer disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'جاري الحفظ...' : 'حفظ القوالب'}</span>
        </button>
      </div>

      {/* 2-Column Layout: Editor + Mobile Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Template Selection and Textarea Editor */}
        <div className="lg:col-span-7 space-y-5 text-right">
          
          {/* Template Selection Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {templates.map(tmpl => (
              <button
                key={tmpl.id}
                onClick={() => setSelectedTemplateId(tmpl.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedTemplateId === tmpl.id
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                    : 'bg-purple-950/50 text-slate-300 hover:bg-purple-900/50 border border-purple-800/40'
                }`}
              >
                {tmpl.name}
              </button>
            ))}
          </div>

          {/* Editor Container */}
          <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                عنوان القالب
              </label>
              <input
                type="text"
                value={selectedTemplate.name}
                onChange={(e) => {
                  const val = e.target.value;
                  setTemplates(prev => prev.map(t => t.id === selectedTemplateId ? { ...t, name: val } : t));
                }}
                className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white text-xs font-semibold focus:outline-none focus:border-purple-500"
              />
            </div>

            {/* Variable Pills to Click & Insert */}
            <div>
              <p className="text-xs font-semibold text-slate-400 mb-2">
                انقر على أي متغير لإضافته في نص الرسالة:
              </p>
              <div className="flex flex-wrap gap-1.5">
                {availableVariables.map((v) => (
                  <button
                    key={v.key}
                    type="button"
                    onClick={() => handleInsertVariable(v.key)}
                    className="px-2.5 py-1 rounded-lg bg-purple-900/40 hover:bg-purple-800/70 border border-purple-700/50 text-purple-200 text-[11px] font-mono transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <span>{v.key}</span>
                    <span className="text-[10px] text-slate-400">({v.desc})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Message Body */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                نص الرسالة (Message Content)
              </label>
              <textarea
                rows={9}
                value={selectedTemplate.content}
                onChange={(e) => handleContentChange(e.target.value)}
                className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl p-3 text-white text-xs leading-relaxed focus:outline-none focus:border-purple-500 font-sans"
              />
            </div>

            {/* Interactive Action Buttons */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">
                الأزرار التفاعلية المرفقة (Quick Reply Buttons)
              </label>
              <div className="space-y-2">
                {selectedTemplate.buttons.map((btn, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="w-6 text-center text-slate-500 font-mono text-xs">{idx + 1}</span>
                    <input
                      type="text"
                      value={btn.text}
                      onChange={(e) => {
                        const newText = e.target.value;
                        setTemplates(prev => prev.map(t => {
                          if (t.id === selectedTemplateId) {
                            const newBtns = [...t.buttons];
                            newBtns[idx].text = newText;
                            return { ...t, buttons: newBtns };
                          }
                          return t;
                        }));
                      }}
                      className="flex-1 bg-purple-950/40 border border-purple-800/40 rounded-lg px-3 py-1.5 text-xs text-white"
                    />
                    <span className="text-[10px] px-2 py-1 rounded bg-black/40 text-purple-300 font-mono">
                      {btn.action}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

        {/* Right Column: Live Mobile Frame WhatsApp Preview */}
        <div className="lg:col-span-5 flex justify-center">
          <div className="w-full max-w-[340px] rounded-[36px] bg-[#0c0819] border-4 border-purple-900/60 shadow-2xl p-4 text-right">
            
            {/* Phone Speaker Notch */}
            <div className="w-24 h-4 bg-slate-900 rounded-full mx-auto mb-3"></div>

            {/* WhatsApp Header */}
            <div className="flex items-center gap-2 pb-3 border-b border-purple-900/40 mb-3">
              <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold text-xs">
                W
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-white truncate">بوتيك الأناقة المغربية</p>
                <p className="text-[10px] text-emerald-400">حساب تجاري موثق ✓</p>
              </div>
            </div>

            {/* Chat Area */}
            <div className="space-y-3 min-h-[360px] flex flex-col justify-end">
              <div className="bg-[#191136] border border-purple-800/40 rounded-2xl rounded-tr-none p-3.5 text-right text-xs leading-relaxed shadow-sm">
                <p className="whitespace-pre-line text-slate-100">
                  {renderPreviewContent(selectedTemplate.content)}
                </p>

                {/* Buttons in WhatsApp */}
                {selectedTemplate.buttons.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-purple-900/40 space-y-1.5">
                    {selectedTemplate.buttons.map((btn, idx) => (
                      <div
                        key={idx}
                        className="py-1.5 px-2 bg-purple-900/40 border border-purple-700/30 text-purple-200 rounded-lg text-center font-bold text-[11px]"
                      >
                        {btn.text}
                      </div>
                    ))}
                  </div>
                )}

                <span className="text-[9px] text-slate-500 block text-left mt-2 font-mono">14:40 ✓✓</span>
              </div>
            </div>

            <div className="mt-4 pt-2 border-t border-purple-900/30 text-center">
              <span className="text-[10px] text-slate-500">معاينة حية كما ستصل لهاتف العميل</span>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
