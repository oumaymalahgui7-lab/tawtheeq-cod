import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { SubscriptionPlan, SystemLog, User } from '../../types';
import { 
  ShieldAlert, 
  Users, 
  Store, 
  ShoppingBag, 
  DollarSign, 
  Sliders, 
  Terminal, 
  Check, 
  Save, 
  Sparkles, 
  AlertTriangle,
  RefreshCw,
  Edit2
} from 'lucide-react';

export const AdminView: React.FC = () => {
  const { showToast } = useApp();

  const [loading, setLoading] = useState(true);
  const [adminData, setAdminData] = useState<any>(null);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [isSavingPlans, setIsSavingPlans] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState<'users' | 'plans' | 'logs'>('users');

  const loadAdminData = async () => {
    try {
      setLoading(true);
      const res = await api.getAdminOverview();
      setAdminData(res);
      setPlans(res.plans || []);
    } catch (e) {
      console.error(e);
      showToast('تعذر تحميل بيانات الإدارة', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  const handleSavePlans = async () => {
    setIsSavingPlans(true);
    try {
      const res = await api.updatePlans(plans);
      if (res.success) {
        showToast('تم تحديث خطط الاشتراك والأسعار بنجاح ✅', 'success');
      }
    } catch (e) {
      showToast('فشل حفظ أسعار الخطط', 'error');
    } finally {
      setIsSavingPlans(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>لوحة تحكم المشرف (Super Admin)</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-300 font-mono border border-rose-800">
              Admin Access
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            إدارة التجار، الخطط والأسعار الديناميكية، مراقبة سجلات الخوادم والـ Webhooks.
          </p>
        </div>

        <button
          onClick={loadAdminData}
          className="flex items-center gap-1.5 px-3 py-2 bg-purple-950/60 hover:bg-purple-900 text-purple-200 text-xs font-semibold rounded-xl border border-purple-800/40 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>تحديث السجلات</span>
        </button>
      </div>

      {/* Admin Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-right">
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
          <span className="text-xs text-slate-400">إجمالي التجار المسجلين</span>
          <p className="text-2xl font-black text-white font-mono mt-1">{adminData?.usersCount || 2}</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
          <span className="text-xs text-slate-400">المتاجر المتصلة</span>
          <p className="text-2xl font-black text-purple-300 font-mono mt-1">{adminData?.storesCount || 2}</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
          <span className="text-xs text-slate-400">إجمالي طلبات النظام</span>
          <p className="text-2xl font-black text-emerald-400 font-mono mt-1">{adminData?.ordersCount || 6}</p>
        </div>
        <div className="glass-panel p-4 rounded-2xl border border-purple-800/40">
          <span className="text-xs text-slate-400">حالة خوادم Webhooks</span>
          <p className="text-sm font-black text-emerald-400 mt-2 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            100% مستقرة
          </p>
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="flex items-center gap-2 border-b border-purple-900/30 pb-3 text-xs">
        <button
          onClick={() => setActiveAdminTab('users')}
          className={`px-4 py-2 rounded-xl font-bold transition-colors ${
            activeAdminTab === 'users' ? 'bg-purple-600 text-white' : 'bg-purple-950/40 text-slate-400 hover:text-white'
          }`}
        >
          قائمة المستخدمين والتجار ({adminData?.users?.length || 0})
        </button>

        <button
          onClick={() => setActiveAdminTab('plans')}
          className={`px-4 py-2 rounded-xl font-bold transition-colors ${
            activeAdminTab === 'plans' ? 'bg-purple-600 text-white' : 'bg-purple-950/40 text-slate-400 hover:text-white'
          }`}
        >
          إدارة الخطط والأسعار (Dynamic Plans)
        </button>

        <button
          onClick={() => setActiveAdminTab('logs')}
          className={`px-4 py-2 rounded-xl font-bold transition-colors ${
            activeAdminTab === 'logs' ? 'bg-purple-600 text-white' : 'bg-purple-950/40 text-slate-400 hover:text-white'
          }`}
        >
          سجلات الأخطاء والنظام (System Logs)
        </button>
      </div>

      {/* Tab 1: Users */}
      {activeAdminTab === 'users' && (
        <div className="glass-panel rounded-2xl border border-purple-800/40 overflow-hidden text-right">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-purple-900/40 bg-purple-950/40 text-slate-400 font-semibold">
                <th className="py-3 pr-4">الاسم والمتجر</th>
                <th className="py-3">البريد والهاتف</th>
                <th className="py-3">الدور</th>
                <th className="py-3">الباقة</th>
                <th className="py-3">الرصيد المتبقي</th>
                <th className="py-3 pl-4 text-center">الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-900/20">
              {(adminData?.users || []).map((u: any) => (
                <tr key={u.id} className="hover:bg-purple-950/30">
                  <td className="py-3.5 pr-4 font-bold text-white">
                    <div>{u.name}</div>
                    <div className="text-[11px] text-purple-300 font-normal">{u.storeName}</div>
                  </td>
                  <td className="py-3.5 text-slate-300">
                    <div>{u.email}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{u.phone}</div>
                  </td>
                  <td className="py-3.5">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-purple-900/50 text-purple-200">
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3.5 text-slate-300 font-mono uppercase">{u.planId}</td>
                  <td className="py-3.5 font-mono font-bold text-emerald-400">{u.credits} DH</td>
                  <td className="py-3.5 pl-4 text-center">
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold">
                      نشط
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 2: Dynamic Plans Editor (Mandatory Requirement) */}
      {activeAdminTab === 'plans' && (
        <div className="glass-panel p-6 rounded-2xl border border-purple-800/40 space-y-6 text-right">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
            <div>
              <h2 className="text-base font-bold text-white">تعديل أسعار وحدود خطط الاشتراك</h2>
              <p className="text-xs text-slate-400">تحكم كامل بالأسعار والكوتا من لوحة الأدمن دون تعديل الكود البرمجي.</p>
            </div>
            <button
              onClick={handleSavePlans}
              disabled={isSavingPlans}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSavingPlans ? 'جاري الحفظ...' : 'حفظ الأسعار'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((p, idx) => (
              <div key={p.id} className="p-4 rounded-2xl bg-purple-950/40 border border-purple-800/40 space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-black text-white font-mono">{p.name}</h3>
                  <span className="text-xs text-purple-300">{p.nameAr}</span>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">السعر الشهري (DH)</label>
                  <input
                    type="number"
                    value={p.priceMonthly}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setPlans(prev => prev.map((pl, i) => i === idx ? { ...pl, priceMonthly: val } : pl));
                    }}
                    className="w-full bg-[#100a26] border border-purple-800/50 rounded-lg p-2 text-white font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">حد الطلبات الشهرية</label>
                  <input
                    type="number"
                    value={p.ordersLimit}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setPlans(prev => prev.map((pl, i) => i === idx ? { ...pl, ordersLimit: val } : pl));
                    }}
                    className="w-full bg-[#100a26] border border-purple-800/50 rounded-lg p-2 text-white font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">عدد المتاجر المسموحة</label>
                  <input
                    type="number"
                    value={p.storesLimit}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setPlans(prev => prev.map((pl, i) => i === idx ? { ...pl, storesLimit: val } : pl));
                    }}
                    className="w-full bg-[#100a26] border border-purple-800/50 rounded-lg p-2 text-white font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">تكلفة الرسالة الإضافية (DH)</label>
                  <input
                    type="number"
                    step="0.05"
                    value={p.costPerExtraMessage}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setPlans(prev => prev.map((pl, i) => i === idx ? { ...pl, costPerExtraMessage: val } : pl));
                    }}
                    className="w-full bg-[#100a26] border border-purple-800/50 rounded-lg p-2 text-white font-mono text-xs"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: System Logs */}
      {activeAdminTab === 'logs' && (
        <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 text-right space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
            <span className="font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-purple-400" />
              أحدث سجلات النظام وWebhooks وواتساب
            </span>
            <span className="text-[11px] text-slate-500">Live Stream</span>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
            {(adminData?.logs || []).map((log: any) => (
              <div key={log.id} className="p-3 rounded-xl bg-purple-950/40 border border-purple-900/30 flex items-start justify-between">
                <div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold mr-2 ${
                    log.level === 'ERROR' ? 'bg-rose-950 text-rose-400' : 'bg-purple-900/60 text-purple-300'
                  }`}>
                    {log.category}
                  </span>
                  <span className="text-slate-200">{log.message}</span>
                </div>
                <span className="text-[10px] text-slate-500 shrink-0 mr-4">
                  {new Date(log.createdAt).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
