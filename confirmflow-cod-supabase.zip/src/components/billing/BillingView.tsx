import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { CreditTransaction, SubscriptionPlan } from '../../types';
import { 
  CreditCard, 
  Zap, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Clock,
  DollarSign
} from 'lucide-react';

export const BillingView: React.FC = () => {
  const { user, setUser, t, showToast } = useApp();

  const [loading, setLoading] = useState(true);
  const [credits, setCredits] = useState(0);
  const [currentPlan, setCurrentPlan] = useState<SubscriptionPlan | null>(null);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [transactions, setTransactions] = useState<CreditTransaction[]>([]);
  const [isRechargeModalOpen, setIsRechargeModalOpen] = useState(false);
  const [rechargeAmount, setRechargeAmount] = useState(250);
  const [isProcessing, setIsProcessing] = useState(false);

  const loadBillingData = async () => {
    try {
      setLoading(true);
      const res = await api.getBilling();
      setCredits(res.credits);
      setCurrentPlan(res.currentPlan);
      setPlans(res.plans);
      setTransactions(res.transactions);
      if (user) {
        setUser({ ...user, credits: res.credits });
      }
    } catch (e) {
      console.error(e);
      showToast('تعذر تحميل بيانات الرصيد والاشتراك', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBillingData();
  }, []);

  const handleRecharge = async () => {
    if (rechargeAmount <= 0) return;
    setIsProcessing(true);
    try {
      const res = await api.rechargeCredits(rechargeAmount);
      if (res.success) {
        setCredits(res.balance);
        if (user) setUser({ ...user, credits: res.balance });
        setTransactions(prev => [res.transaction, ...prev]);
        showToast(`تم شحن ${rechargeAmount} درهم إلى محفظتك بنجاح ✅`, 'success');
        setIsRechargeModalOpen(false);
      }
    } catch (e) {
      showToast('فشل عملية الشحن', 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-purple-900/30">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <span>الرصيد والاشتراكات (Billing & Credits)</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 font-mono border border-emerald-800">
              رصيد نشط
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            إدارة رصيد رسائل واتساب، سجل العمليات، وترقية الباقات والخطط.
          </p>
        </div>

        <button
          onClick={() => setIsRechargeModalOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-purple-600/30 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>شحن رصيد إضافي</span>
        </button>
      </div>

      {/* Top Cards: Balance + Current Plan */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-right">
        
        {/* Credits Balance Card */}
        <div className="md:col-span-1 glass-panel p-6 rounded-3xl border border-purple-700/50 bg-gradient-to-br from-[#1b113d]/90 to-[#100a26]/90 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-300">الرصيد المتاح حالياً</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="my-2">
            <span className="text-4xl font-black text-amber-300 font-mono tabular-nums">{credits}</span>
            <span className="text-sm text-slate-300 mr-2 font-bold">درهم مغربي (DH)</span>
          </div>
          <p className="text-xs text-slate-400 mt-2">
            يكفي لإرسال حوالي <strong className="text-purple-300 font-mono">{Math.floor(credits / 0.40)}</strong> رسالة تأكيد ومتابعة.
          </p>

          <button
            onClick={() => setIsRechargeModalOpen(true)}
            className="mt-5 w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/30"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>شحن المحفظة الآن</span>
          </button>
        </div>

        {/* Current Plan Card */}
        <div className="md:col-span-2 glass-panel p-6 rounded-3xl border border-purple-800/40 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-3">
              <div>
                <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">الخطة الحالية</span>
                <h3 className="text-lg font-black text-white">{currentPlan?.name || 'PRO'} Plan</h3>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400 px-3 py-1 rounded-full bg-emerald-950 border border-emerald-800">
                {currentPlan?.priceMonthly || 399} DH / شهرياً
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center my-3">
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                <span className="text-[10px] text-slate-400">حد الطلبات</span>
                <p className="text-base font-bold text-white font-mono mt-0.5">{currentPlan?.ordersLimit || 600} طلب/شهر</p>
              </div>
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                <span className="text-[10px] text-slate-400">المتاجر المسموحة</span>
                <p className="text-base font-bold text-white font-mono mt-0.5">{currentPlan?.storesLimit || 3} متاجر</p>
              </div>
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                <span className="text-[10px] text-slate-400">رسائل متضمنة</span>
                <p className="text-base font-bold text-purple-300 font-mono mt-0.5">{currentPlan?.messagesIncluded || 1000} رسالة</p>
              </div>
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30">
                <span className="text-[10px] text-slate-400">تكلفة الرسالة الإضافية</span>
                <p className="text-base font-bold text-emerald-400 font-mono mt-0.5">{currentPlan?.costPerExtraMessage || 0.35} DH</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-purple-900/40 text-xs text-slate-400">
            <span>تاريخ التجديد القادم: <strong className="text-white font-mono">1 نوفمبر 2026</strong></span>
            <span className="text-purple-300 font-semibold">فاتورة إلكترونية معتمدة</span>
          </div>
        </div>

      </div>

      {/* Transactions Ledger */}
      <div className="glass-panel p-5 rounded-2xl border border-purple-800/40 text-right">
        <h2 className="text-base font-bold text-white mb-4">سجل العمليات والاستهلاك (Transaction History)</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-purple-900/40 text-slate-400 font-semibold">
                <th className="pb-3 pr-2">النوع</th>
                <th className="pb-3">البيان / الوصف</th>
                <th className="pb-3">المبلغ</th>
                <th className="pb-3">الرصيد بعد العملية</th>
                <th className="pb-3 pl-2">التاريخ والوقت</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-900/20">
              {transactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-purple-950/30 transition-colors">
                  <td className="py-3 pr-2">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      tx.type === 'TOPUP' ? 'bg-emerald-950 text-emerald-400' : 'bg-purple-950 text-purple-300'
                    }`}>
                      {tx.type === 'TOPUP' ? <ArrowDownLeft className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                      {tx.type === 'TOPUP' ? 'شحن رصيد' : 'استهلاك'}
                    </span>
                  </td>
                  <td className="py-3 font-medium text-white">{tx.description}</td>
                  <td className={`py-3 font-mono font-bold ${tx.type === 'TOPUP' ? 'text-emerald-400' : 'text-slate-300'}`}>
                    {tx.type === 'TOPUP' ? `+${tx.amount}` : `-${tx.amount}`} DH
                  </td>
                  <td className="py-3 font-mono text-purple-300 font-semibold">{tx.balanceAfter} DH</td>
                  <td className="py-3 pl-2 text-slate-400 font-mono text-[11px]">
                    {new Date(tx.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recharge Modal */}
      {isRechargeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#100a26] border border-purple-800/60 shadow-2xl p-6 text-right">
            
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/40 mb-4">
              <h2 className="text-base font-bold text-white">شحن رصيد الرسائل (Credit Top-up)</h2>
              <button
                onClick={() => setIsRechargeModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <p className="text-slate-300">
                اختر الباقة المناسبة لحجم طلباتك الشهرية. يتم تفعيل الرصيد فوراً في حسابك:
              </p>

              {/* Preset Packages */}
              <div className="grid grid-cols-2 gap-2.5">
                {[100, 250, 500, 1000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setRechargeAmount(amt)}
                    className={`p-3.5 rounded-2xl border text-center transition-all ${
                      rechargeAmount === amt
                        ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-600/40 font-bold'
                        : 'bg-purple-950/60 border-purple-800/40 text-slate-300 hover:bg-purple-900/40'
                    }`}
                  >
                    <p className="text-lg font-black font-mono">{amt} DH</p>
                    <p className="text-[10px] opacity-80 mt-0.5">~{Math.floor(amt / 0.40)} رسالة تأكيد</p>
                  </button>
                ))}
              </div>

              {/* Custom amount */}
              <div>
                <label className="block text-slate-400 mb-1 font-semibold">أو حدد مبلغاً مخصصاً (DH):</label>
                <input
                  type="number"
                  min="50"
                  step="50"
                  value={rechargeAmount}
                  onChange={(e) => setRechargeAmount(Number(e.target.value))}
                  className="w-full bg-purple-950/60 border border-purple-800/50 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              {/* Payment Methods */}
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/30 text-slate-300 space-y-1">
                <span className="font-semibold text-white block">طرق الدفع المدعومة:</span>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  ✓ بطاقة بنكية مغربية (CMI / Visa / Mastercard)<br />
                  ✓ تحويل بنكي مباشر (Wafacash / Cash Plus / Bank Transfer)
                </p>
              </div>

              <div className="pt-3 border-t border-purple-900/40 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRechargeModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-purple-950 hover:bg-purple-900 text-slate-300 text-xs font-semibold"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleRecharge}
                  disabled={isProcessing}
                  className="px-6 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 flex items-center gap-1.5"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>{isProcessing ? 'جاري المعالجة...' : `دفع وتفعيل ${rechargeAmount} DH`}</span>
                </button>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
