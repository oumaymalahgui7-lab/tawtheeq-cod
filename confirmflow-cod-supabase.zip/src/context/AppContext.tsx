import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Store, NotificationItem, Order } from '../types';
import { api } from '../services/api';
import { supabase } from '../lib/supabase';

export type Language = 'ar' | 'fr' | 'en';
export type ActiveTab =
  | 'landing'
  | 'dashboard'
  | 'orders'
  | 'customers'
  | 'stores'
  | 'whatsapp'
  | 'templates'
  | 'analytics'
  | 'billing'
  | 'admin'
  | 'settings'
  | 'docs';

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  authLoading: boolean;
  logout: () => Promise<void>;
  language: Language;
  setLanguage: (lang: Language) => void;
  dir: 'rtl' | 'ltr';
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  stores: Store[];
  activeStore: Store | null;
  setActiveStore: (store: Store) => void;
  notifications: NotificationItem[];
  unreadNotificationsCount: number;
  markNotificationsAsRead: () => void;
  selectedOrderId: string | null;
  setSelectedOrderId: (id: string | null) => void;
  toastMessage: { text: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (text: string, type?: 'success' | 'error' | 'info') => void;
  isOnboardingOpen: boolean;
  setIsOnboardingOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authMode: 'login' | 'signup' | 'forgot';
  setAuthMode: (mode: 'login' | 'signup' | 'forgot') => void;
  t: (key: string) => string;
  refreshData: () => void;
}

const translations: Record<Language, Record<string, string>> = {
  ar: {
    appName: 'توثيق COD',
    appTagline: 'أكد طلبات الدفع عند الاستلام COD بسهولة',
    navLanding: 'الرئيسية',
    navDashboard: 'لوحة التحكم',
    navOrders: 'إدارة الطلبات',
    navCustomers: 'سجل العملاء CRM',
    navStores: 'المتاجر والربط',
    navWhatsApp: 'أتمتة واتساب & AI',
    navTemplates: 'قوالب الرسائل',
    navAnalytics: 'التقارير والإحصائيات',
    navBilling: 'الرصيد والاشتراكات',
    navAdmin: 'لوحة الإدارة Super Admin',
    navSettings: 'الإعدادات',
    navDocs: 'دليل الاستخدام والربط',
    login: 'تسجيل الدخول',
    signup: 'إنشاء حساب جديد',
    logout: 'تسجيل الخروج',
    startNow: 'ابدأ الآن مجاناً',
    seeHowItWorks: 'شاهد كيف يعمل',
    totalOrders: 'إجمالي الطلبات',
    confirmed: 'الطلبات المؤكدة',
    cancelled: 'الطلبات الملغاة',
    confirmationRate: 'نسبة التأكيد',
    revenue: 'المبيعات والإيرادات',
    availableCredits: 'الرصيد المتاح',
    delivered: 'الطلبات المسلمة',
    returned: 'المرتجعات',
    needsReview: 'تحتاج مراجعة',
    pending: 'في انتظار التأكيد',
    currencyDh: 'درهم',
    filterToday: 'اليوم',
    filter7Days: 'آخر 7 أيام',
    filter30Days: 'آخر 30 يوم',
    filterMonth: 'هذا الشهر',
    actions: 'الإجراءات',
    searchPlaceholder: 'بحث برقم الطلب، اسم العميل، الهاتف، أو المدينة...',
    exportCsv: 'تصدير CSV',
    exportExcel: 'تصدير إكسل',
    exportPdf: 'طباعة البوليصة PDF',
    newOrder: '+ طلب يدوي جديد',
    simulateShopify: 'محاكاة طلب Shopify',
    liveSimulator: 'المحاكي التفاعلي المباشر',
    installPwa: 'تثبيت التطبيق على الهاتف',
    status_NEW: 'جديد',
    status_PENDING_CONFIRMATION: 'بانتظار التأكيد',
    status_CONFIRMED: 'مؤكد ✅',
    status_CANCELLED: 'ملغي ❌',
    status_NO_RESPONSE: 'لم يرد',
    status_SHIPPED: 'تم الشحن 🚚',
    status_DELIVERED: 'تم التسليم 💰',
    status_RETURNED: 'مرتجع ⚠️',
    status_NEEDS_REVIEW: 'يحتاج مراجعة ❓'
  },
  fr: {
    appName: 'Tawtheeq COD',
    appTagline: 'Confirmation des commandes COD via WhatsApp',
    navLanding: 'Accueil',
    navDashboard: 'Tableau de bord',
    navOrders: 'Commandes',
    navCustomers: 'Clients CRM',
    navStores: 'Boutiques & Intégrations',
    navWhatsApp: 'WhatsApp & IA',
    navTemplates: 'Modèles de messages',
    navAnalytics: 'Statistiques',
    navBilling: 'Crédits & Abonnements',
    navAdmin: 'Super Admin',
    navSettings: 'Paramètres',
    navDocs: 'Documentation API',
    login: 'Connexion',
    signup: 'Créer un compte',
    logout: 'Déconnexion',
    startNow: 'Commencer gratuitement',
    seeHowItWorks: 'Voir la démo',
    totalOrders: 'Total Commandes',
    confirmed: 'Confirmées',
    cancelled: 'Annulées',
    confirmationRate: 'Taux Confirmation',
    revenue: "Chiffre d'affaires",
    availableCredits: 'Crédits disponibles',
    delivered: 'Livrées',
    returned: 'Retours',
    needsReview: 'À Réviser',
    pending: 'En attente',
    currencyDh: 'DH',
    filterToday: "Aujourd'hui",
    filter7Days: '7 derniers jours',
    filter30Days: '30 derniers jours',
    filterMonth: 'Ce mois',
    actions: 'Actions',
    searchPlaceholder: 'Rechercher commande, client, tél, ville...',
    exportCsv: 'Exporter CSV',
    exportExcel: 'Exporter Excel',
    exportPdf: 'Bordereau PDF',
    newOrder: '+ Nouvelle Commande',
    simulateShopify: 'Simuler Commande Shopify',
    liveSimulator: 'Simulateur Interactif',
    installPwa: "Installer l'application",
    status_NEW: 'Nouveau',
    status_PENDING_CONFIRMATION: 'En attente',
    status_CONFIRMED: 'Confirmée ✅',
    status_CANCELLED: 'Annulée ❌',
    status_NO_RESPONSE: 'Sans réponse',
    status_SHIPPED: 'Expédiée 🚚',
    status_DELIVERED: 'Livrée 💰',
    status_RETURNED: 'Retournée ⚠️',
    status_NEEDS_REVIEW: 'À réviser ❓'
  },
  en: {
    appName: 'Tawtheeq COD',
    appTagline: 'Automated WhatsApp COD Order Confirmation',
    navLanding: 'Home',
    navDashboard: 'Dashboard',
    navOrders: 'Orders CRM',
    navCustomers: 'Customers',
    navStores: 'Stores & Webhooks',
    navWhatsApp: 'WhatsApp Automation & AI',
    navTemplates: 'Message Templates',
    navAnalytics: 'Analytics',
    navBilling: 'Credits & Billing',
    navAdmin: 'Super Admin',
    navSettings: 'Settings',
    navDocs: 'Documentation',
    login: 'Sign In',
    signup: 'Get Started',
    logout: 'Sign Out',
    startNow: 'Start Free Trial',
    seeHowItWorks: 'See How It Works',
    totalOrders: 'Total Orders',
    confirmed: 'Confirmed',
    cancelled: 'Cancelled',
    confirmationRate: 'Confirmation Rate',
    revenue: 'Revenue',
    availableCredits: 'Credits Available',
    delivered: 'Delivered',
    returned: 'Returned',
    needsReview: 'Needs Review',
    pending: 'Pending',
    currencyDh: 'DH',
    filterToday: 'Today',
    filter7Days: 'Last 7 Days',
    filter30Days: 'Last 30 Days',
    filterMonth: 'This Month',
    actions: 'Actions',
    searchPlaceholder: 'Search order ID, customer name, phone, city...',
    exportCsv: 'Export CSV',
    exportExcel: 'Export Excel',
    exportPdf: 'Print Packing Slip',
    newOrder: '+ New Manual Order',
    simulateShopify: 'Simulate Shopify Webhook',
    liveSimulator: 'Live Interactive Simulator',
    installPwa: 'Install App on Device',
    status_NEW: 'New',
    status_PENDING_CONFIRMATION: 'Pending Confirmation',
    status_CONFIRMED: 'Confirmed ✅',
    status_CANCELLED: 'Cancelled ❌',
    status_NO_RESPONSE: 'No Response',
    status_SHIPPED: 'Shipped 🚚',
    status_DELIVERED: 'Delivered 💰',
    status_RETURNED: 'Returned ⚠️',
    status_NEEDS_REVIEW: 'Needs Review ❓'
  }
};

function mapSupabaseUser(sbUser: any): User {
  const meta = sbUser?.user_metadata || {};
  return {
    id: sbUser.id,
    name: meta.full_name || meta.name || sbUser.email?.split('@')[0] || 'تاجر',
    email: sbUser.email || '',
    role: meta.role === 'ADMIN' ? 'ADMIN' : 'MERCHANT',
    storeName: meta.store_name || meta.storeName || 'متجري الإلكتروني',
    phone: meta.phone || sbUser.phone || '',
    planId: meta.plan_id || 'plan_pro',
    credits: 0,
    createdAt: sbUser.created_at || new Date().toISOString(),
    onboardingCompleted: Boolean(meta.onboarding_completed ?? true),
  };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  const [language, setLanguageState] = useState<Language>('ar');
  const [activeTab, setActiveTab] = useState<ActiveTab>('landing');
  const [stores, setStores] = useState<Store[]>([]);
  const [activeStore, setActiveStore] = useState<Store | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'forgot'>('login');

  const dir = language === 'ar' ? 'rtl' : 'ltr';

  // Synchronize document dir and lang
  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  };

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Real Supabase Auth session initialization & listener
  useEffect(() => {
    let isMounted = true;

    // 1. Load real session with getSession
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (error) {
        console.warn('Supabase getSession error:', error);
      }
      if (isMounted) {
        if (session?.user) {
          setUser(mapSupabaseUser(session.user));
        } else {
          setUser(null);
        }
        setAuthLoading(false);
      }
    }).catch((err) => {
      console.warn('Error loading auth session:', err);
      if (isMounted) setAuthLoading(false);
    });

    // 2. Listen to real session state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (isMounted) {
        if (session?.user) {
          setUser(mapSupabaseUser(session.user));
        } else {
          setUser(null);
        }
      }
    });

    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const logout = async () => {
    try {
      await supabase.auth.signOut();
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setUser(null);
      setActiveTab('landing');
      showToast('تم تسجيل الخروج بنجاح', 'info');
    }
  };

  const loadInitialData = async () => {
    try {
      const storesRes = await api.getStores();
      if (storesRes.stores && storesRes.stores.length > 0) {
        setStores(storesRes.stores);
        setActiveStore(storesRes.stores[0]);
      }
      const notifsRes = await api.getNotifications();
      if (notifsRes.notifications) {
        setNotifications(notifsRes.notifications);
      }
    } catch (e) {
      console.warn('Initial data load warning:', e);
    }
  };

  useEffect(() => {
    if (user) loadInitialData();
  }, [user?.id]);

  const markNotificationsAsRead = async () => {
    try {
      await api.markNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (e) {
      console.error(e);
    }
  };

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  const refreshData = () => {
    loadInitialData();
  };

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        authLoading,
        logout,
        language,
        setLanguage,
        dir,
        activeTab,
        setActiveTab,
        stores,
        activeStore,
        setActiveStore,
        notifications,
        unreadNotificationsCount,
        markNotificationsAsRead,
        selectedOrderId,
        setSelectedOrderId,
        toastMessage,
        showToast,
        isOnboardingOpen,
        setIsOnboardingOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authMode,
        setAuthMode,
        t,
        refreshData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
