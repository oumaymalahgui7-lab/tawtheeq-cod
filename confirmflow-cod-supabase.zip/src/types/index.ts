export type OrderStatus =
  | 'NEW'
  | 'PENDING_CONFIRMATION'
  | 'CONFIRMED'
  | 'CANCELLED'
  | 'NO_RESPONSE'
  | 'SHIPPED'
  | 'DELIVERED'
  | 'RETURNED'
  | 'NEEDS_REVIEW';

export type PlatformType = 'SHOPIFY' | 'WOOCOMMERCE' | 'YOUCAN' | 'CUSTOM_API';

export interface OrderItem {
  id: string;
  name: string;
  variant?: string;
  quantity: number;
  price: number;
  sku?: string;
  image?: string;
}

export interface WhatsAppMessage {
  id: string;
  orderId: string;
  direction: 'OUTBOUND' | 'INBOUND';
  type: 'CONFIRMATION' | 'REMINDER_1' | 'REMINDER_2' | 'REPLY' | 'SHIPPING' | 'MANUAL';
  body: string;
  timestamp: string;
  status: 'PENDING' | 'SENT' | 'DELIVERED' | 'READ' | 'FAILED';
  aiClassification?: {
    intent: 'CONFIRMED' | 'CANCELLED' | 'QUESTION' | 'ADDRESS_CHANGE' | 'UNKNOWN';
    confidence: number;
    language: 'darija' | 'arabic' | 'french' | 'mixed';
    reason: string;
    extractedNotes?: string;
  };
}

export interface OrderTimelineEvent {
  id: string;
  orderId: string;
  title: string;
  description: string;
  timestamp: string;
  type: 'CREATED' | 'WHATSAPP_SENT' | 'CUSTOMER_REPLIED' | 'CONFIRMED' | 'CANCELLED' | 'SHIPPED' | 'DELIVERED' | 'NOTE';
  actor?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  storeId: string;
  storeName: string;
  customerName: string;
  customerPhone: string;
  customerCity: string;
  customerAddress: string;
  items: OrderItem[];
  subtotal: number;
  shippingFee: number;
  totalPrice: number;
  currency: string;
  paymentMethod: 'COD';
  status: OrderStatus;
  source: PlatformType;
  notes?: string;
  whatsappMessageCount: number;
  createdAt: string;
  updatedAt: string;
  confirmedAt?: string;
  shippedAt?: string;
  deliveredAt?: string;
  cancelledAt?: string;
  messages: WhatsAppMessage[];
  timeline: OrderTimelineEvent[];
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  city: string;
  address: string;
  totalOrders: number;
  confirmedOrders: number;
  cancelledOrders: number;
  deliveredOrders: number;
  returnedOrders: number;
  totalSpent: number;
  currency: string;
  firstOrderAt: string;
  lastOrderAt: string;
}

export interface Store {
  id: string;
  name: string;
  domain: string;
  platform: PlatformType;
  currency: string;
  phone: string;
  logo?: string;
  isActive: boolean;
  webhookSecret: string;
  webhookUrl: string;
  apiKey?: string;
  createdAt: string;
  whatsappAccountId?: string;
}

export interface WhatsAppConfig {
  phoneNumberId: string;
  wabaId: string;
  accessToken: string;
  verifyToken: string;
  businessPhoneNumber: string;
  isConnected: boolean;
  provider: 'META_CLOUD_API' | 'EMBEDDED_SIGNUP';
}

export interface AutomationSettings {
  autoSendConfirmation: boolean;
  firstReminderDelayMinutes: number; // e.g. 15, 30, 60
  enableSecondReminder: boolean;
  secondReminderDelayMinutes: number; // e.g. 120
  maxAttempts: number;
  autoCancelAfterHours: number; // 0 to disable
  aiAutoConfirmation: boolean;
  aiAutoCancellation: boolean;
  aiSensitivity: 'HIGH' | 'BALANCED' | 'STRICT';
}

export interface MessageTemplate {
  id: string;
  name: string;
  type: 'CONFIRMATION' | 'REMINDER_1' | 'REMINDER_2' | 'CANCELLED' | 'SHIPPED';
  language: 'ar' | 'darija' | 'fr';
  content: string;
  buttons: { text: string; action: string }[];
  isActive: boolean;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  nameAr: string;
  priceMonthly: number; // in DH
  ordersLimit: number;
  storesLimit: number;
  messagesIncluded: number;
  costPerExtraMessage: number;
  features: string[];
  isPopular?: boolean;
}

export interface CreditTransaction {
  id: string;
  type: 'TOPUP' | 'DEDUCTION' | 'REFUND' | 'BONUS';
  amount: number; // in DH
  description: string;
  orderId?: string;
  balanceAfter: number;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'ORDER_NEW' | 'ORDER_CONFIRMED' | 'ORDER_CANCELLED' | 'LOW_CREDITS' | 'QUESTION' | 'WEBHOOK';
  orderId?: string;
  read: boolean;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'MERCHANT' | 'ADMIN';
  storeName: string;
  phone: string;
  planId: string;
  credits: number;
  createdAt: string;
  onboardingCompleted: boolean;
}

export interface SystemLog {
  id: string;
  level: 'INFO' | 'WARN' | 'ERROR';
  category: 'WEBHOOK' | 'WHATSAPP' | 'AI' | 'BILLING' | 'AUTH';
  message: string;
  payload?: any;
  createdAt: string;
}
