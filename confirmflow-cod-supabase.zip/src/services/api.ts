import { supabaseApi } from './supabaseApi';
import { Order, Customer, Store, SubscriptionPlan, CreditTransaction, NotificationItem, OrderStatus, SystemLog } from '../types';

const mockApi = {
  // Orders
  async getOrders(params?: { status?: string; search?: string; storeId?: string; page?: number; limit?: number }) {
    const query = new URLSearchParams();
    if (params?.status) query.append('status', params.status);
    if (params?.search) query.append('search', params.search);
    if (params?.storeId) query.append('storeId', params.storeId);
    if (params?.page) query.append('page', String(params.page));
    if (params?.limit) query.append('limit', String(params.limit));

    const res = await fetch(`/api/orders?${query.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch orders');
    return res.json() as Promise<{ orders: Order[]; pagination: any }>;
  },

  async getOrder(id: string) {
    const res = await fetch(`/api/orders/${id}`);
    if (!res.ok) throw new Error('Failed to fetch order');
    return res.json() as Promise<{ order: Order }>;
  },

  async createOrder(orderData: Partial<Order>) {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });
    if (!res.ok) throw new Error('Failed to create order');
    return res.json() as Promise<{ success: boolean; order: Order }>;
  },

  async updateOrderStatus(id: string, status: OrderStatus, note?: string) {
    const res = await fetch(`/api/orders/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note }),
    });
    if (!res.ok) throw new Error('Failed to update status');
    return res.json() as Promise<{ success: boolean; order: Order }>;
  },

  // WhatsApp simulation & NLP
  async simulateWhatsAppReply(orderId: string, replyText: string) {
    const res = await fetch('/api/whatsapp/simulate-reply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId, replyText }),
    });
    if (!res.ok) throw new Error('Failed to simulate WhatsApp reply');
    return res.json() as Promise<{ success: boolean; order: Order; classification: any; message: any }>;
  },

  async classifyText(text: string) {
    const res = await fetch('/api/ai/classify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
    if (!res.ok) throw new Error('Failed to classify text');
    return res.json() as Promise<{ success: boolean; classification: any; source: string }>;
  },

  // Webhook simulation for Shopify
  async simulateShopifyWebhook(payload: any) {
    const res = await fetch('/api/webhooks/shopify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Failed to trigger Shopify webhook');
    return res.json() as Promise<{ success: boolean; orderId: string; orderNumber: string }>;
  },

  // Customers
  async getCustomers(search?: string) {
    const query = search ? `?search=${encodeURIComponent(search)}` : '';
    const res = await fetch(`/api/customers${query}`);
    if (!res.ok) throw new Error('Failed to fetch customers');
    return res.json() as Promise<{ customers: Customer[] }>;
  },

  // Analytics
  async getAnalytics() {
    const res = await fetch('/api/analytics');
    if (!res.ok) throw new Error('Failed to fetch analytics');
    return res.json() as Promise<{
      kpis: {
        totalOrders: number;
        confirmed: number;
        cancelled: number;
        pending: number;
        delivered: number;
        returned: number;
        needsReview: number;
        confirmationRate: number;
        revenue: number;
        credits: number;
        currency: string;
      };
      chartData: Array<{ day: string; total: number; confirmed: number; cancelled: number; revenue: number }>;
      statusBreakdown: Record<string, number>;
    }>;
  },

  // Stores
  async getStores() {
    const res = await fetch('/api/stores');
    if (!res.ok) throw new Error('Failed to fetch stores');
    return res.json() as Promise<{ stores: Store[] }>;
  },

  async createStore(storeData: Partial<Store>) {
    const res = await fetch('/api/stores', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(storeData),
    });
    if (!res.ok) throw new Error('Failed to create store');
    return res.json() as Promise<{ success: boolean; store: Store }>;
  },

  // Billing
  async getBilling() {
    const res = await fetch('/api/billing');
    if (!res.ok) throw new Error('Failed to fetch billing info');
    return res.json() as Promise<{
      credits: number;
      currency: string;
      currentPlan: SubscriptionPlan;
      plans: SubscriptionPlan[];
      transactions: CreditTransaction[];
    }>;
  },

  async rechargeCredits(amount: number) {
    const res = await fetch('/api/billing/recharge', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount }),
    });
    if (!res.ok) throw new Error('Failed to recharge credits');
    return res.json() as Promise<{ success: boolean; balance: number; transaction: CreditTransaction }>;
  },

  // Settings
  async getSettings() {
    const res = await fetch('/api/settings');
    if (!res.ok) throw new Error('Failed to fetch settings');
    return res.json();
  },

  async updateSettings(settings: any) {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to save settings');
    return res.json();
  },

  // Notifications
  async getNotifications() {
    const res = await fetch('/api/notifications');
    if (!res.ok) throw new Error('Failed to fetch notifications');
    return res.json() as Promise<{ notifications: NotificationItem[] }>;
  },

  async markNotificationsRead() {
    const res = await fetch('/api/notifications/mark-read', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to mark notifications read');
    return res.json();
  },

  // Admin
  async getAdminOverview() {
    const res = await fetch('/api/admin/overview');
    if (!res.ok) throw new Error('Failed to fetch admin overview');
    return res.json() as Promise<{
      usersCount: number;
      storesCount: number;
      ordersCount: number;
      logs: SystemLog[];
      plans: SubscriptionPlan[];
      users: any[];
    }>;
  },

  async updatePlans(plans: SubscriptionPlan[]) {
    const res = await fetch('/api/admin/plans', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plans }),
    });
    if (!res.ok) throw new Error('Failed to update plans');
    return res.json();
  }
};

// Real Supabase data overrides the mock /api/* endpoints.
export const api = { ...mockApi, ...supabaseApi } as typeof mockApi;
