import { supabase } from '../lib/supabase';
import { Order, Store, NotificationItem, OrderStatus, PlatformType } from '../types';

// Real Supabase data layer. Overrides the mock /api/* endpoints in api.ts.
// All queries run with the logged-in user's session, so RLS decides what is visible.

const FUNCTION_URL = 'https://gmpnicjbbarcmpinzfyq.supabase.co/functions/v1/dynamic-service';

const PLATFORM_FROM_DB: Record<string, PlatformType> = {
  shopify: 'SHOPIFY',
  woocommerce: 'WOOCOMMERCE',
  youcan: 'YOUCAN',
  manual: 'CUSTOM_API',
};
const PLATFORM_TO_DB: Record<string, string> = {
  SHOPIFY: 'shopify',
  WOOCOMMERCE: 'woocommerce',
  YOUCAN: 'youcan',
  CUSTOM_API: 'manual',
};

const ORDER_SELECT =
  '*, customers(name, phone, city), stores(name), order_items(id, product_name, quantity, price), messages(id, order_id, direction, body, ai_label, created_at)';

function fail(error: any, message: string): never {
  if (error) console.error(error.message || error);
  throw new Error(message);
}

function mapStore(s: any): Store {
  return {
    id: s.id,
    name: s.name,
    domain: s.domain || '',
    platform: PLATFORM_FROM_DB[s.platform] || 'CUSTOM_API',
    currency: 'DH',
    phone: '',
    isActive: s.is_active,
    webhookSecret: s.webhook_secret,
    webhookUrl: `${FUNCTION_URL}?key=${s.webhook_secret}`,
    createdAt: s.created_at,
  };
}

function mapMessage(m: any) {
  return {
    id: m.id,
    orderId: m.order_id,
    direction: m.direction === 'in' ? 'INBOUND' : 'OUTBOUND',
    type: m.direction === 'in' ? 'REPLY' : 'CONFIRMATION',
    body: m.body,
    timestamp: m.created_at,
    status: 'SENT',
    aiClassification: m.ai_label
      ? { intent: m.ai_label, confidence: 0, language: 'mixed', reason: '' }
      : undefined,
  };
}

function mapOrder(o: any): Order {
  const items = (o.order_items || []).map((i: any) => ({
    id: i.id,
    name: i.product_name,
    quantity: i.quantity,
    price: Number(i.price),
  }));
  const subtotal = items.reduce((sum: number, i: any) => sum + i.price * i.quantity, 0);
  const total = Number(o.total);
  const messages = (o.messages || []).map(mapMessage);
  const timeline: any[] = [
    { id: `${o.id}-c`, orderId: o.id, title: 'تم إنشاء الطلب', description: '', timestamp: o.created_at, type: 'CREATED' },
  ];
  if (o.confirmed_at) timeline.push({ id: `${o.id}-ok`, orderId: o.id, title: 'تم التأكيد', description: '', timestamp: o.confirmed_at, type: 'CONFIRMED' });
  if (o.shipped_at) timeline.push({ id: `${o.id}-s`, orderId: o.id, title: 'تم الشحن', description: '', timestamp: o.shipped_at, type: 'SHIPPED' });
  if (o.delivered_at) timeline.push({ id: `${o.id}-d`, orderId: o.id, title: 'تم التسليم', description: '', timestamp: o.delivered_at, type: 'DELIVERED' });

  return {
    id: o.id,
    orderNumber: o.external_id,
    storeId: o.store_id,
    storeName: o.stores?.name || '',
    customerName: o.customers?.name || '',
    customerPhone: o.customers?.phone || '',
    customerCity: o.city || o.customers?.city || '',
    customerAddress: o.address || '',
    items,
    subtotal,
    shippingFee: Math.max(total - subtotal, 0),
    totalPrice: total,
    currency: 'DH',
    paymentMethod: 'COD',
    status: o.status,
    source: PLATFORM_FROM_DB[o.source] || 'CUSTOM_API',
    notes: o.notes || undefined,
    whatsappMessageCount: messages.length,
    createdAt: o.created_at,
    updatedAt: o.updated_at,
    confirmedAt: o.confirmed_at || undefined,
    shippedAt: o.shipped_at || undefined,
    deliveredAt: o.delivered_at || undefined,
    messages,
    timeline,
  } as Order;
}

async function postToFunction(storeId: string | undefined, payload: any) {
  const { data: stores, error } = await supabase
    .from('stores')
    .select('id, webhook_secret')
    .order('created_at');
  if (error || !stores || stores.length === 0) {
    throw new Error('أضف متجراً أولاً قبل إنشاء الطلبات.');
  }
  const store = stores.find((s: any) => s.id === storeId) || stores[0];
  const res = await fetch(`${FUNCTION_URL}?key=${encodeURIComponent(store.webhook_secret)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || 'تعذر إنشاء الطلب');
  return body;
}

export const supabaseApi = {
  async getStores() {
    const { data, error } = await supabase.from('stores').select('*').order('created_at');
    if (error) fail(error, 'تعذر تحميل المتاجر، يرجى المحاولة مرة أخرى.');
    return { stores: (data || []).map(mapStore) };
  },

  async createStore(storeData: Partial<Store>) {
    const { data: auth } = await supabase.auth.getUser();
    if (!auth.user) throw new Error('يرجى تسجيل الدخول أولاً.');
    const { data, error } = await supabase
      .from('stores')
      .insert({
        owner_id: auth.user.id,
        name: storeData.name,
        domain: storeData.domain || null,
        platform: PLATFORM_TO_DB[storeData.platform || 'CUSTOM_API'] || 'manual',
      })
      .select()
      .single();
    if (error) fail(error, 'تعذر إنشاء المتجر، يرجى المحاولة مرة أخرى.');
    return { success: true, store: mapStore(data) };
  },

  async getOrders(params?: { status?: string; search?: string; storeId?: string; page?: number; limit?: number }) {
    const limit = params?.limit || 20;
    const page = params?.page || 1;
    let q = supabase
      .from('orders')
      .select(ORDER_SELECT, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range((page - 1) * limit, page * limit - 1);
    if (params?.status && params.status !== 'ALL') q = q.eq('status', params.status);
    if (params?.storeId && params.storeId !== 'ALL') q = q.eq('store_id', params.storeId);
    if (params?.search) {
      const s = params.search.replace(/[%,()]/g, '');
      q = q.or(`external_id.ilike.%${s}%,city.ilike.%${s}%`);
    }
    const { data, error, count } = await q;
    if (error) fail(error, 'تعذر تحميل الطلبات، يرجى المحاولة مرة أخرى.');
    const total = count || 0;
    return {
      orders: (data || []).map(mapOrder),
      pagination: { total, page, pageSize: limit, totalPages: Math.max(Math.ceil(total / limit), 1) },
    };
  },

  async getOrder(id: string) {
    const { data, error } = await supabase.from('orders').select(ORDER_SELECT).eq('id', id).single();
    if (error) fail(error, 'تعذر تحميل الطلب.');
    return { order: mapOrder(data) };
  },

  async updateOrderStatus(id: string, status: OrderStatus, _note?: string) {
    const { error } = await supabase.from('orders').update({ status }).eq('id', id);
    if (error) fail(error, 'تعذر تغيير حالة الطلب، يرجى المحاولة مرة أخرى.');
    const { data } = await supabase.from('orders').select(ORDER_SELECT).eq('id', id).single();
    return { success: true, order: mapOrder(data) };
  },

  async createOrder(orderData: Partial<Order>) {
    const r = await postToFunction(orderData.storeId, {
      customer_name: orderData.customerName,
      phone: orderData.customerPhone,
      city: orderData.customerCity,
      address: orderData.customerAddress,
      items: (orderData.items || []).map((i) => ({ name: i.name, quantity: i.quantity, price: i.price })),
      total: orderData.totalPrice,
    });
    return { success: true, order: { id: r.orderId, orderNumber: r.orderNumber } as Order };
  },

  async simulateShopifyWebhook(payload: any) {
    const r = await postToFunction(undefined, payload);
    return { success: true, orderId: r.orderId, orderNumber: r.orderNumber };
  },

  async getAnalytics() {
    const since = new Date(Date.now() - 30 * 86400000).toISOString();
    const { data, error } = await supabase
      .from('orders')
      .select('status,total,created_at')
      .gte('created_at', since)
      .limit(5000);
    if (error) fail(error, 'تعذر تحميل الإحصائيات.');
    const rows = data || [];
    const count = (st: string) => rows.filter((r: any) => r.status === st).length;
    const confirmed = count('CONFIRMED') + count('SHIPPED') + count('DELIVERED');
    const decided = confirmed + count('CANCELLED') + count('NO_RESPONSE');
    const revenue = rows
      .filter((r: any) => r.status === 'DELIVERED')
      .reduce((sum: number, r: any) => sum + Number(r.total), 0);

    const days: Record<string, any> = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      days[d] = { day: d, total: 0, confirmed: 0, cancelled: 0, revenue: 0 };
    }
    rows.forEach((r: any) => {
      const d = String(r.created_at).slice(0, 10);
      if (!days[d]) return;
      days[d].total++;
      if (['CONFIRMED', 'SHIPPED', 'DELIVERED'].includes(r.status)) days[d].confirmed++;
      if (r.status === 'CANCELLED') days[d].cancelled++;
      if (r.status === 'DELIVERED') days[d].revenue += Number(r.total);
    });

    const { data: auth } = await supabase.auth.getUser();
    const { data: credit } = auth.user
      ? await supabase.from('credits').select('balance').eq('owner_id', auth.user.id).maybeSingle()
      : { data: null as any };

    const statusBreakdown: Record<string, number> = {};
    rows.forEach((r: any) => {
      statusBreakdown[r.status] = (statusBreakdown[r.status] || 0) + 1;
    });

    return {
      kpis: {
        totalOrders: rows.length,
        confirmed,
        cancelled: count('CANCELLED'),
        pending: count('NEW') + count('PENDING_CONFIRMATION'),
        delivered: count('DELIVERED'),
        returned: count('RETURNED'),
        needsReview: count('NEEDS_REVIEW'),
        confirmationRate: decided > 0 ? Math.round((confirmed / decided) * 100) : 0,
        revenue,
        credits: Number(credit?.balance ?? 0),
        currency: 'DH',
      },
      chartData: Object.values(days),
      statusBreakdown,
    };
  },

  async getNotifications() {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(30);
    if (error) fail(error, 'تعذر تحميل الإشعارات.');
    const notifications: NotificationItem[] = (data || []).map((n: any) => ({
      id: n.id,
      title: n.title,
      message: n.body || '',
      type: n.type,
      read: n.is_read,
      createdAt: n.created_at,
    }));
    return { notifications };
  },

  async markNotificationsRead() {
    const { error } = await supabase.from('notifications').update({ is_read: true }).eq('is_read', false);
    if (error) fail(error, 'تعذر تحديث الإشعارات.');
    return { success: true };
  },
};
