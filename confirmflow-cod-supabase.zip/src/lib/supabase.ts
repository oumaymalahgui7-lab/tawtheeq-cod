import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://gmpnicjbbarcmpinzfyq.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_KEY || 'sb_publishable_6nuxbV9MJ02DIYqYByLORQ_1_rAkNha';

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export function getArabicAuthErrorMessage(error: any): string {
  if (!error) return '';
  const message = (typeof error === 'string' ? error : error.message || error.error_description || '').toLowerCase();

  if (message.includes('invalid login credentials') || message.includes('invalid_grant')) {
    return 'البريد الإلكتروني أو كلمة المرور غير صحيحة.';
  }
  if (message.includes('user already registered') || message.includes('already exists')) {
    return 'هذا البريد الإلكتروني مسجل مسبقاً، يمكنك تسجيل الدخول مباشرة.';
  }
  if (message.includes('password should be at least') || message.includes('password is too short')) {
    return 'كلمة المرور يجب أن تتكون من 8 أحرف على الأقل.';
  }
  if (message.includes('email not confirmed')) {
    return 'يرجى تأكيد بريدك الإلكتروني من خلال الرابط المرسل إلى صندوق الوارد الخاص بك.';
  }
  if (message.includes('email rate limit') || message.includes('rate limit')) {
    return 'تم تجاوز الحد المسموح للطلبات مؤقتاً، يرجى الانتظار بضع دقائق والمحاولة مجدداً.';
  }
  if (message.includes('invalid email') || message.includes('unable to validate email address')) {
    return 'يرجى إدخال عنوان بريد إلكتروني صحيح.';
  }
  if (message.includes('user not found')) {
    return 'لا يوجد حساب مرتبط بهذا البريد الإلكتروني.';
  }
  if (message.includes('network') || message.includes('failed to fetch')) {
    return 'تعذر الاتصال بالخادم، يرجى التحقق من اتصال الإنترنت.';
  }
  if (message.includes('row-level security') || message.includes('permission denied')) {
    return 'ليس لديك صلاحية لتنفيذ هذا الإجراء.';
  }

  return error.message || 'حدث خطأ أثناء معالجة الطلب، يرجى المحاولة لاحقاً.';
}
