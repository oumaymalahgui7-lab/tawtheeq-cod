/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { LandingPage } from './components/landing/LandingPage';
import { DashboardView } from './components/dashboard/DashboardView';
import { OrdersView } from './components/orders/OrdersView';
import { CustomersView } from './components/customers/CustomersView';
import { StoresView } from './components/stores/StoresView';
import { WhatsAppAutomationView } from './components/whatsapp/WhatsAppAutomationView';
import { TemplatesView } from './components/whatsapp/TemplatesView';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { BillingView } from './components/billing/BillingView';
import { AdminView } from './components/admin/AdminView';
import { SettingsView } from './components/settings/SettingsView';
import { DocsView } from './components/docs/DocsView';
import { AuthModal } from './components/auth/AuthModal';
import { OnboardingWizard } from './components/onboarding/OnboardingWizard';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeTab, toastMessage } = useApp();

  // Register service worker for PWA
  useEffect(() => {
    if ('serviceWorker' in navigator && import.meta.env.PROD) {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('Service worker registration failed:', err);
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#090614] text-slate-100 flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      {/* Top Bar Navigation */}
      <Navbar />

      {/* Main Workspace Body */}
      {activeTab === 'landing' ? (
        <main className="flex-1">
          <LandingPage />
        </main>
      ) : (
        <div className="flex-1 max-w-7xl w-full mx-auto flex">
          {/* Dashboard Left/Right Sidebar */}
          <Sidebar />

          {/* Viewport Content Canvas */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-y-auto">
            {activeTab === 'dashboard' && <DashboardView />}
            {activeTab === 'orders' && <OrdersView />}
            {activeTab === 'customers' && <CustomersView />}
            {activeTab === 'stores' && <StoresView />}
            {activeTab === 'whatsapp' && <WhatsAppAutomationView />}
            {activeTab === 'templates' && <TemplatesView />}
            {activeTab === 'analytics' && <AnalyticsView />}
            {activeTab === 'billing' && <BillingView />}
            {activeTab === 'admin' && <AdminView />}
            {activeTab === 'settings' && <SettingsView />}
            {activeTab === 'docs' && <DocsView />}
          </main>
        </div>
      )}

      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 left-5 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#140e2b] border border-purple-600/60 shadow-2xl text-xs font-semibold text-white animate-fade-in-up">
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : toastMessage.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          ) : (
            <Info className="w-4 h-4 text-purple-400 shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Modals */}
      <AuthModal />
      <OnboardingWizard />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
